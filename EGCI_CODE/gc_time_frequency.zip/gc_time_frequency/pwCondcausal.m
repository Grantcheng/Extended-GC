function [pp,cohe,Fy2xz]=pwCondcausal(x,Nr,Nl,porder,fs,freq)
% Using Geweke's/Chen's method to compute the conditional granger causality 
%
%   x is a matrix whose every row is one variable's time series
%   Nr is the number of realizations, 
%   Nl is the length of every realization
%      If the time series are stationary long, just let Nr=1, Nl=length(x)
%   porder is the order of AR model
%   fs is sampling frequency
%   freq is a vector of frequencies of interest, usually freq=0:fs/2
%
%   pp is power spectrum
%   cohe is coherence between any two channels
%   Fy2xz is causality from y to x conditianl z
%        the order of Fx2y/Fy2x is 1 to 2:L, 2 to 3:L,....,L-1 to L.  That is,
%        1st column: 1&2; 2nd: 1&3; ...; (L-1)th: 1&L; ...; (L(L-1))th: (L-1)&L.

% Finished Sep 2012 by Grant Cheng

[L,N] = size(x); %L is the number of channels, N is the total points in every channel

%% ----------------------------------------------------------------------------------
%
% we will classify the whole variate into three vectors
% variate.�����Z�������Z����һ����������Z��ָARģ���в�����Э��������Z��ָ������
% X--is a vectors with k dimensions.
% Y--is a vectors with l dimensions.
% Z--is a vectors with m dimensions
%
%% ----------------------------------------------------------------------------------
% N_Var=k+l+m;
% cov(X,Y,Z)=matrix(3,3)---is N_Var X N_Var
% cov(X,X)---is k X k; cov(X,Y)---is k X l; cov(X,Z)---is k X m
% cov(Y,X)---is l X k; cov(Y,Y)---is l X l; cov(Y,Z)---is l X m
% cov(Z,X)---is m X k; cov(Z,Y)---is m X l; cov(Z,Z)---is m X m

% X_Dim=k;
% Y_Dim=l;
% Z_Dim=m;
k=1;l=1;m=L-2;
X=[];
 index = 0;
for i=1:L
    for j=1:L
    if i==j 
        continue; 
    end
     index = index + 1;
    X(1,:)=x(i,:);
    X(2,:)=x(j,:);
    X3_inx=setdiff(1:L,[i j]);
    X(3:L,:)=x(X3_inx,:);
    [A,Z] = armorf(X,Nr,Nl,porder);  %fitting AR model using my AKS's code
% C_XX=cov(X,X); C_XY=cov(X,Y);C_XZ=cov(X,Z);
    eval(['C' num2str(1) '=Z(1:k,1:k);']);
    eval(['C' num2str(2) '=Z(1:k,k+1:k+l);']);
    eval(['C' num2str(3) '=Z(1:k,k+l+1:end);']);
    
% C_YX=cov(Y,X); C_YY=cov(Y,Y);C_YZ=cov(Y,Z);
    eval(['C' num2str(4) '=Z(k+1:k+l,1:k);']);
    eval(['C' num2str(5) '=Z(k+1:k+l,k+1:k+l);']);
    eval(['C' num2str(6) '=Z(k+1:k+l,k+l+1:end);']);
    
% C_ZX=cov(Z,X); C_ZY=cov(Z,Y);C_ZZ=cov(Z,Z);
    eval(['C' num2str(7) '=Z(k+l+1:end,1:k);']);
    eval(['C' num2str(8) '=Z(k+l+1:end,k+1:k+l);']);
    eval(['C' num2str(9) '=Z(k+l+1:end,k+l+1:end);']);
    
% Normalization  P=P2*P1
Ik=eye(k);Il=eye(l);Im=eye(m);
P121=-C4*inv(C1);P131=-C7*inv(C1);
P1=[Ik zeros(k,l+m);P121 Il zeros(l,m);P131 zeros(m,l) Im];
P232=-(C8-C7*inv(C1)*C2)*inv((C5-C4*inv(C1)*C2));
P2=[Ik zeros(k,l+m);zeros(l,k) Il zeros(l,m);zeros(m,k) P232 Im];
P=P2*P1;
%% ----------------------------------------------------------------------------------

f_ind  = 0;
    for f  = freq
        f_ind = f_ind + 1;
        % Spectrum Matrix
        [S,H] = spectrum(A,Z,porder,f,fs); % H is non-normalization at this state.
        % HH(f) -- normalization H
        HH=H*inv(P);
        % go to get restricted regresions H_r, the transform function
         H_13=[HH(1:k,1:k) HH(1:k,k+l+1:end);HH(k+l+1:end,1:k) HH(k+l+1:end,k+l+1:end)];
         H_123=[HH(1:k,k+1:k+l);HH(k+l+1:end,k+1:k+l)];
         % H_r -- is restricted regressions
         H_r=inv(H_13)*H_123;   
         %Cov_r -- is the covariance of restricted regressions
         CC1=C1;                                   % CC_XX
         CC2=(P232*P121+P131)'*C1+P232'*C2+C3;       % CC_XZ
         CC3=(P232*P121+P131)*C1+P232*C4+C7;       % CC_ZX
         CC4=(P232*P121+P131)*(P232*P121+P131)'*C1+(P232*P121+P131)*P232'*C2+(P232*P121+P131)*C3+P232*(P232*P121+P131)'*C4+P232*P232'*C5+P232*C6+(P232*P121+P131)'*C7+P232'*C8+C9; % CC_ZZ
         CC5=P121'*C1+C2; % CC_XY
         CC6=(P232*P121+P131)*P121'*C1+(P232*P121+P131)*C2+P232*P121'*C4+P232*C5+P121'*C7+C8; % CC_ZY
         CC7= P121*P121'*C1+P121*C2+P121'*C4+C5;% CC_YY
         CC8=P121*C1+C4;% CC_YX
         CC9=P121*(P232*P121+P131)'*C1+P121*P232'*C2+P121*C3+(P232*P121+P131)'*C4+P232'*C5+C6; % CC_YZ
         %% -------The first 
%          Cov_r_1=[C1 C3;C7 C9];
%          Cov_r_2=H_r*[C2' C8'];
%          Cov_r_3=[C2;C8]*H_r';
%          Cov_r_4=C5*(H_r*H_r');
         %% ----- The second after revise
%          Cov_r_1=[CC1 CC2;CC3 CC4];
%          Cov_r_2=H_r*[CC5' CC6'];
%          Cov_r_3=[CC5;CC6]*H_r';
%          Cov_r_4=CC7*(H_r*H_r');

%         Modify the Eq.25 in Ref.[3];
         Cov_r_1=[CC1 CC2;CC3 CC4];
         Cov_r_2=H_r*[CC8 CC9];
         Cov_r_3=[CC5;CC6]*H_r';
         Cov_r_4=(H_r*CC7*H_r');

         %% ------------------------
         Cov_r=Cov_r_1+Cov_r_2+Cov_r_3+Cov_r_4;    
         % P_r -- is the normalization matrix of restricted regressions
         P_r=[Ik zeros(k,m);-Cov_r(1:k,k+1:end)'*inv(C1) Im];
         G_w=H_13/(P_r);% G_w -- is the G_whole
         G_w_e=zeros(L,L);
         G_w_e(1:k,1:k)=G_w(1:k,1:k); %G_w_e -- is the G_whole_expansion
         G_w_e(1:k,k+1:k+l)=zeros(k,l);
         G_w_e(1:k,k+l+1:end)=G_w(1:k,k+1:k+m);
         G_w_e(k+1:k+l,1:k)=zeros(l,k);
         G_w_e(k+1:k+l,k+1:k+l)=ones(l,l);
         G_w_e(k+1:k+l,k+l+1:end)=zeros(l,m);
         G_w_e(k+l+1:end,1:k)=G_w(k+1:end,1:k);
         G_w_e(k+l+1:end,k+1:k+l)=zeros(m,l);
         G_w_e(k+l+1:end,k+l+1:end)=G_w(k+1:end,k+1:end);
         Q=(G_w_e)\HH;
         Fy2xz(index,f_ind) = log(abs(det(Cov_r(1:k,1:k)))/abs(det(Q(1:k,1:k)*C1*Q(1:k,1:k)'))); %Geweke's original measure
    %%-----------------------------------------------------------------
        % Power spectrum (N.B.: this is the two-sided power spectrum. For 1-sided multiply S by 2).
        if(f_ind<=length(freq))
        pp(:,f_ind)   = real(diag(S)) .*2 ;
        
        % Coherence spectrum
        
        num              = abs(S).^2;
        denum            = repmat(diag(S),1,L) .* repmat(diag(S),1,L)';
        cohe(:,:,f_ind) = real( num ./ denum );
        end
    end

    end
end
