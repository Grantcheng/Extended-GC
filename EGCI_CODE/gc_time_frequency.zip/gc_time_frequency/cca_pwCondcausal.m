function [GW,GW_Gewek,COH,pp,waut,cons]=cca_pwCondcausal(X,Nr,Nl,nlags,Fs,freq, STATFLAG)
% -----------------------------------------------------------------------
%   FUNCTION: cca_pwCondcausal.m
%   PURPOSE:  perform spectralConditional Granger causality following
%             the method of Geweke - this function implements !
%             The algorithm is implement REF.2
%
%   INPUT:  X           -   nvar (rows) by nobs (cols) observation matrix
%           nlags       -   number of lags to include in model
%           Nr          -   # of realizations
%           Nl          -   length of each realization
%           Fs          -   sampling rate (Hz)
%           freq        -   vector of frequencies to analyze
%           STATFLAG    -   comput Durbin Watson / consistency (1) or not (0)
%
%   OUTPUT: GW          -   nvar * nvar * length(freq) spectral granger ---- algorithm_DingMZ 
%           GW_Gewek    -   nvar * nvar * length(freq) spectral granger --- algorithm_Gewek
%           COH         -   nvar * nvar * length(freq) coherence
%                           (power spectrum is along diagonal)
%           pp          -   power spectrum (as above, provided separately)
%           waut        -   Durbin Watson residual autocorrelation sig
%                           value
%           cons        -   MVAR model consistency (Ding et al 2000)
%
%   This function is due to Yonghong Chen (2003), AKS(2009) modified by Grant
%
%   NOTE:  statistical distribution for spectral granger is not known,
%   use surrogate data methods
%   NOTE:  this function is suitable for multitrial data
%
%   REF.0: Geweke, J. 1982 Measurement of linear dependence and feedback between 
%   multiple time series. Journal of the American Statistical Association 77, 304-313.  
%   REF.1: Ding, M., Chen, Y. & Bressler, S. L. 2006 Granger causality: Basic
%   theory and application to neuroscience. In Handbook of Time Series Analysis 
%   (ed. S. Schelter, M. Winterhalder & J. Timmer), pp. 438-460. Wienheim: Wiley.
%   REF.2: Geweke, J. 1984 Measures of conditional linear dependence and
%   feedback between time seies. Journal of the American Statistical Association 79, 907-915.
%
%   Grant Sep 08 2012
%   COPYRIGHT NOTICE AT BOTTOM
% -----------------------------------------------------------------------
if nargin<7,
    STATFLAG = 1;
end
[L,N]=size(X); %L is the number of channels, N is the total points in every channel
[pp,cohe,Fy2xz]=pwCondcausal(X,Nr,Nl,nlags,Fs,freq); %this function available from www.brain-smart.org
[pp,cohe,Fy2xz_gewek]=pwCondcausal_Gewek(X,Nr,Nl,nlags,Fs,freq);
% put into square matrix format 
GW = single(ones(L,L,length(freq)).*-999);  % causality_algorithm_Dingmingzhou
GW_Gewek = single(ones(L,L,length(freq)).*-999);  % causality_algorithm_Gewek
COH = single(ones(L,L,length(freq)).*-999); % coherence
ct = 1;
for i=1:L,
    for j=1:L,
        if i==j
       continue;  
        else
        GW(i,j,:) = single(Fy2xz(ct,:));  
        GW_Gewek(i,j,:) = single(Fy2xz_gewek(ct,:));
        ct = ct +1;
        end    
    end
end
COH = cohe;
for i=1:L,
    COH(i,i,:) = pp(i,:);    % set diagonal to power spectrum
end
COH = single(COH);
pp = single(pp);

% check residual autocorrelation and consistency
% if needed (see cca_mtrial_whitecon.m - part of function repeated here to 
% save an additional ARMORF regression step)
if STATFLAG,
    nvar = L; nobs = N;
    A = armorf_to_cca(X,nvar,Nr,Nl,nlags);
    startinx = 1;
    uu = []; xp = [];
    for i=1:Nr,
        endinx = startinx+Nl-1;
        if endinx>nobs,
            endinx = nobs;
        end
        XX = X(:,startinx:endinx);
        [u1,xp1] = cca_calc_resid(XX,A,Nl,nvar,nlags);
        uu = [uu ; u1];
        xp = [xp ; xp1];
        startinx=startinx+Nl;
    end
    for ii=1:nvar,
        waut(ii) = cca_whiteness(X,uu(:,ii));
    end
    cons = cca_consistency(X,xp);   % consistency check
else
    waut = -1;
    cons = -1;
end

% This file is copyright (C) Grant Cheng (2012)

