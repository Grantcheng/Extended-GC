Hi Grant


I have with me the codes for kernel GC, for those on partial conditioning I will come back to you later


2 toolboxes:

-Kernel causality last
-LOO_crossvalidation for choosing the model order

unzip these two toolboxes with the other MATLAB toolboxes and add them to your path.

you will find among others:


scripts:


test_KGC_KCL: run kernel causality on a simulated network of 5 nodes

test_biv_2n: test the two coupled maps

test_var_eps_1: modulation in time of the coupling parameter for the two coupled maps (contains calls to causality and correlation with sliding window)


accessory functions:

two_ccm (generate coupled maps with fixed coupling parameter)

two_ccm_vareps (generate coupled maps with modulated coupling parameter)



everything should be there, I don't have the possibility to test everything now, so please tell me if something is not clear or does not work.


Best wishes, and keep me updated on your analyses


daniele