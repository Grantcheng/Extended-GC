clear;clc
addpath 'Kernel Causality Last/';
addpath 'utilities/';
type='p';           %type of kernel ('p' for polynomial, 'g' for gaussian)
par=2;              %parameter of the model (order for polynomial kernel, or width for the gaussian kernel
N=2100;             %number of points of simulated time series
epstot=0:0.1:1;
m=2;
G=zeros(2,2,length(epstot));G1=G;
corrtot=zeros(1,length(epstot));
for ie=1:length(epstot)
     xx=example2(N,epstot(ie));              
                data=xx';            %data matrix must have the dimensions [n_points n_variables]
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                [np nv]=size(data); %number of observations (time points) and number of variables 
                G(:,:,ie)=causality(data,type,par,m);            %compute causality matrix
                G1(:,:,ie)=causality(data,type,1,m);            %compute causality matrix
                cc=corrcoef(data(:,1),data(:,2));
                corrtot(1,ie)=cc(1,2);
           
end
% for i=1:length(ltot)
%     figure;
%     subplot(3,1,1);plot(epstot,squeeze(G(1,2,:,i,:,1)),'-ob');hold on;plot(epstot,squeeze(G(2,1,:,:,:,1)),'-or')
%     legend('x \rightarrow y','y \rightarrow x');
%     title(strcat('\sigma = ',num2str(sigtot(1))));
%     subplot(3,1,2);plot(epstot,squeeze(G(1,2,:,i,:,2)),'-ob');hold on;plot(epstot,squeeze(G(2,1,:,:,:,2)),'-or')
%     title(strcat('\sigma = ',num2str(sigtot(2))));
%     subplot(3,1,3);plot(epstot,squeeze(G(1,2,:,i,:,3)),'-ob');hold on;plot(epstot,squeeze(G(2,1,:,:,:,3)),'-or')
%     title(strcat('\sigma = ',num2str(sigtot(3))));xlabel('\epsilon');
% end
figure;

subplot(2,2,1);plot(epstot,squeeze(G1(1,2,:)),'ro',epstot,squeeze(G1(2,1,:)),'bo');ylabel('causality 1->2, p=1')
legend('causality 1->2','causality 2->1')
subplot(2,2,2);plot(epstot,squeeze(G(1,2,:)),'ro',epstot,squeeze(G(2,1,:)),'bo');ylabel('causality 1->2, p=2')
legend('causality 1->2','causality 2->1')
subplot(2,2,3:4);plot(epstot,(corrtot(1,:)),'d');xlabel('\epsilon');ylabel('correlation')


