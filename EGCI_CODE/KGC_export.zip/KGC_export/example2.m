function X=example2(N,c)
settleTime = 5000;   % number of observations to allow dynamics to settle
N = N + settleTime;    
    X = cca_normrnd(0,1,2,N);   % 3 variables 
     W = zeros(2,N);
    for i=1:2,
        W(i,:) = normrnd(0,sqrt(1),1,N);
    end
    for i=3:N,
        X(1,i) = 3.4.*X(1,i-1).*(1-X(1,i-1).*X(1,i-1)).*exp(-X(1,i-1).*X(1,i-1)) + 0.8.*X(1,i-2)+W(1,i);
        X(2,i) = 3.4.*X(2,i-1).*(1-X(2,i-1).*X(2,i-1)).*exp(-X(2,i-1).*X(2,i-1))+0.5.*X(2,i-2)+c.*X(1,i-2)*X(1,i-2)+W(2,i);
    end
    X = X(:,settleTime+1:end);
end
