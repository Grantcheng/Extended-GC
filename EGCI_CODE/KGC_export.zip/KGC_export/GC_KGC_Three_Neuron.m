clear;clc
%%
GC_CAL_HOME = fileparts(mfilename('fullpath'));

addpath(GC_CAL_HOME);
addpath([GC_CAL_HOME,'/Kernel Causality Last']);

m=6;                %order of the model
tau=1;              %separation of the m points used for prediction (generally we leave it =1)
nt=1;               %starting point, normally always 1
delta=0;            %gap between training and test
type='p';           %type of kernel ('p' for polynomial, 'g' for gaussian)
par=2;              %parameter of the model (order for polynomial kernel, or width for the gaussian kernel
N=2000;             %number of points of simulated time series
settleTime=1000;    %settling time
%create a null distribution with randomized phases. this is not always
%necessary, since there is already the test on the coefficients, but it's good to have

disp('GC calculation package path added.');
disp(' ');
%%
epstot=[0 0.02 0.04 0.06 0.08 0.1 0.11 0.12 0.13 0.14 0.15 0.16];
Cases_choose=input('Which case choose: Case_1 = 1, Case_2 = 2, Case_3 = 3, Case_4 = 4, Case_6 = 6 ');
GC_Results_Save = zeros(3,3,12);
for ie=1:12
    C=epstot(ie);
    Couple_ie=C;
    display(['The Strength is : ' num2str(C)]);
  if Cases_choose==1
   if ie==1
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0/Solution/Three_HH_Solution0w1_0.28w2_0.282w3_0.29.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0/Solution/Three_HH_Solution1w1_0.28w2_0.282w3_0.29.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0/Solution/Three_HH_Solution2w1_0.28w2_0.282w3_0.29.txt');
      
   elseif ie==2
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.02/Solution/Three_HH_Solution0w1_0.28w2_0.282w3_0.29.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.02/Solution/Three_HH_Solution1w1_0.28w2_0.282w3_0.29.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.02/Solution/Three_HH_Solution2w1_0.28w2_0.282w3_0.29.txt');
    
    elseif ie==3
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.04/Solution/Three_HH_Solution0w1_0.28w2_0.282w3_0.29.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.04/Solution/Three_HH_Solution1w1_0.28w2_0.282w3_0.29.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.04/Solution/Three_HH_Solution2w1_0.28w2_0.282w3_0.29.txt');
    
    elseif ie==4
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.06/Solution/Three_HH_Solution0w1_0.28w2_0.282w3_0.29.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.06/Solution/Three_HH_Solution1w1_0.28w2_0.282w3_0.29.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.06/Solution/Three_HH_Solution2w1_0.28w2_0.282w3_0.29.txt');
    
    elseif ie==5
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.08/Solution/Three_HH_Solution0w1_0.28w2_0.282w3_0.29.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.08/Solution/Three_HH_Solution1w1_0.28w2_0.282w3_0.29.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.08/Solution/Three_HH_Solution2w1_0.28w2_0.282w3_0.29.txt');
    
    elseif ie==6
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.10/Solution/Three_HH_Solution0w1_0.28w2_0.282w3_0.29.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.10/Solution/Three_HH_Solution1w1_0.28w2_0.282w3_0.29.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.10/Solution/Three_HH_Solution2w1_0.28w2_0.282w3_0.29.txt');
     
    elseif ie==7
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.11/Solution/Three_HH_Solution0w1_0.28w2_0.282w3_0.29.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.11/Solution/Three_HH_Solution1w1_0.28w2_0.282w3_0.29.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.11/Solution/Three_HH_Solution2w1_0.28w2_0.282w3_0.29.txt');
     
    elseif ie==8
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.12/Solution/Three_HH_Solution0w1_0.28w2_0.282w3_0.29.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.12/Solution/Three_HH_Solution1w1_0.28w2_0.282w3_0.29.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.12/Solution/Three_HH_Solution2w1_0.28w2_0.282w3_0.29.txt');
        
    elseif ie==9
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.13/Solution/Three_HH_Solution0w1_0.28w2_0.282w3_0.29.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.13/Solution/Three_HH_Solution1w1_0.28w2_0.282w3_0.29.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.13/Solution/Three_HH_Solution2w1_0.28w2_0.282w3_0.29.txt');
    
    elseif ie==10
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.14/Solution/Three_HH_Solution0w1_0.28w2_0.282w3_0.29.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.14/Solution/Three_HH_Solution1w1_0.28w2_0.282w3_0.29.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.14/Solution/Three_HH_Solution2w1_0.28w2_0.282w3_0.29.txt');
           
    elseif ie==11
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.15/Solution/Three_HH_Solution0w1_0.28w2_0.282w3_0.29.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.15/Solution/Three_HH_Solution1w1_0.28w2_0.282w3_0.29.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.15/Solution/Three_HH_Solution2w1_0.28w2_0.282w3_0.29.txt');
        
    elseif ie==12
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.16/Solution/Three_HH_Solution0w1_0.28w2_0.282w3_0.29.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.16/Solution/Three_HH_Solution1w1_0.28w2_0.282w3_0.29.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig8_Case1/Couple=0.16/Solution/Three_HH_Solution2w1_0.28w2_0.282w3_0.29.txt');
   end
  elseif Cases_choose==2
      if ie==1
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
    
   elseif ie==2
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.02/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.02/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.02/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
    
    elseif ie==3
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.04/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.04/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.04/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
    
    elseif ie==4
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.06/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.06/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.06/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
    
    elseif ie==5
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.08/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.08/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.08/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
    
    elseif ie==6
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.10/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.10/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.10/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
         
    elseif ie==7
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.11/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.11/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.11/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
     
    elseif ie==8
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.12/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.12/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.12/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
        
    elseif ie==9
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.13/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.13/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.13/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
    
    elseif ie==10
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.14/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.14/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.14/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
        
    elseif ie==11
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.15/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.15/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.15/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
     
    elseif ie==12
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.16/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.16/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig6_Case2/Couple=0.16/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
      end
   elseif Cases_choose==3
       if ie==1
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt'); 
    
	elseif ie==2
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.02/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.02/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.02/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
	
    elseif ie==3
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.04/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.04/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.04/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
	
    elseif ie==4
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.06/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.06/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.06/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
	
    elseif ie==5
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.08/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.08/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.08/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
	
    elseif ie==6
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.10/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.10/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.10/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
         
    elseif ie==7
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.11/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.11/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.11/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
     
    elseif ie==8
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.12/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.12/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.12/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
        
    elseif ie==9
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.13/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.13/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.13/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
	
    elseif ie==10
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.14/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.14/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.14/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
        
    elseif ie==11
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.15/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.15/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.15/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
     
    elseif ie==12
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.16/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.16/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig7_Case3/Couple=0.16/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
      end       
    elseif Cases_choose==4
    if ie==1
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
	
    elseif ie==2
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.02/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.02/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.02/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
	
    elseif ie==3
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.04/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.04/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.04/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
	
    elseif ie==4
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.06/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.06/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.06/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
	
    elseif ie==5
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.08/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.08/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.08/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
	
    elseif ie==6
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.10/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.10/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.10/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
         
    elseif ie==7
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.11/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.11/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.11/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
     
    elseif ie==8
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.12/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.12/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.12/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
        
    elseif ie==9
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.13/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.13/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.13/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
	
    elseif ie==10
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.14/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.14/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.14/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
        
    elseif ie==11
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.15/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.15/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.15/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
     
    elseif ie==12
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.16/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.16/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig9_Case4/Couple=0.16/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
    end 
	
    elseif Cases_choose==6
    if ie==1
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
	
    elseif ie==2
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.02/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.02/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.02/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
	
    elseif ie==3
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.04/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.04/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.04/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
	
    elseif ie==4
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.06/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.06/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.06/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
	
    elseif ie==5
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.08/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.08/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.08/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
	
    elseif ie==6
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.10/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.10/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.10/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
	
    elseif ie==7
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.11/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.11/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.11/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
     
    elseif ie==8
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.12/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.12/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.12/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
        
    elseif ie==9
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.13/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.13/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.13/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
	
    elseif ie==10
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.14/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.14/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.14/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
        
    elseif ie==11
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.15/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.15/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.15/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
     
    elseif ie==12
    V1=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.16/Solution/Three_HH_Solution0w1_0.28w2_0.29w3_0.371.txt');
    V2=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.16/Solution/Three_HH_Solution1w1_0.28w2_0.29w3_0.371.txt');
    V3=load('D:/Research/NeuronScience/HH_GC_Three_Neurons_Code/EGCI/Causality_Paper_Data/Three_Neuron_Network/Fig10_Case6/Couple=0.16/Solution/Three_HH_Solution2w1_0.28w2_0.29w3_0.371.txt');
    end
  end
X=[V1; V2; V3];
len = length(V1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
N = N + settleTime;

r = sqrt(2);

X = X(:,settleTime+1:end);
data=X';            %data matrix must have the dimensions [n_points n_variables]
%NTimepoints=[NTimepoints;data];
%end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[np nv]=size(data); %number of observations (time points) and number of variables
n=np-1;             %endpoint
[GC_matrix]=causality(data,type,par,m);            %compute causality matrix
h0=figure('Visible','off');imagesc(GC_matrix);colorbar;
title('Kernel Causality  Network')
xlabel('to');ylabel('from')
set(gca,'XTick',[1:5])
set(gca,'YTick',[1:5])

GC_Results_Save(:,:,ie) = GC_matrix;

if Cases_choose==1
    print(h0,'-depsc2','-r300',['KGC_Fig8_Case1_',num2str(ie),'.eps']) 
    elseif Cases_choose==2
    print(h0,'-depsc2','-r300',['KGC_Fig6_Case2_',num2str(ie),'.eps'])   
    elseif Cases_choose==3  
    print(h0,'-depsc2','-r300',['KGC_Fig7_Case3_',num2str(ie),'.eps'])   
    elseif Cases_choose==4
    print(h0,'-depsc2','-r300',['KGC_Fig9_Case4_',num2str(ie),'.eps'])     
    elseif Cases_choose==6
    print(h0,'-depsc2','-r300',['KGC_Fig10_Case6_',num2str(ie),'.eps'])
end
end