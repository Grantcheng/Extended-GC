function r = cca_normrnd(mu,sigma,m,n);
r = randn(m,n) .* sigma + mu;


