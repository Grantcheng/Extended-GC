function a = setvalues(a, v)

%tstoolbox/@achse/setvalues
%   Syntax:
%     * a = setvalues(a, v)
%
% Copyright 1997-2001 DPI Goettingen, License http://www.physik3.gwdg.de/tstool/gpl.txt

a.values = v;
