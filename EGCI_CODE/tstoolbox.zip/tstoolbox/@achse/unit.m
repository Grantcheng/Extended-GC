function u = unit(a)

u = a.unit;
