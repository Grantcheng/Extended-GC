function d = delta(a)

d = a.delta;
