function display(c)

%tstoolbox/@core/display
%   Syntax:
%     * display(c)
%
%   Input Arguments:
%     * c - core object
%
% Copyright 1997-2001 DPI Goettingen, License http://www.physik3.gwdg.de/tstool/gpl.txt

disp(['  Dlens : ' num2str(c.dlens)])
