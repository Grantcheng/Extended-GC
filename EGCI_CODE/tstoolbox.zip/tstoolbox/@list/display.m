function display(l)

disp(char(l.data))

