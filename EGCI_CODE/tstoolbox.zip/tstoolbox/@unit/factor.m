function f =  factor(q)

%tstoolbox/@unit/factor
%   returns factor of unit q.
%
% Copyright 1997-2001 DPI Goettingen, License http://www.physik3.gwdg.de/tstool/gpl.txt

f = q.factor;
