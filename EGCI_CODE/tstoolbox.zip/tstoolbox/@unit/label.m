function l = label(u)

l = u.label;
