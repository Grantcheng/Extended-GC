%% Case_Type_Choose is : 0 - 280282290;  1 - 280290371;  2 - 280290371_2;  3 - 280290371_Q ;  4 - 280282290_Q;  5 - 280290371_2_Q
C=[0 0.02 0.04 0.06 0.08 0.1 0.11 0.12 0.13 0.14 0.15 0.16];
Taken_dim_0=[3.3842 7.2533 5.9101 4.9027 4.4330 4.1951 4.0890 4.0318 3.9574 3.9269 3.8979 3.8792];
Taken_dim_1=[3.3842 3.7649 4.3215 4.2195 4.1701 4.0327 4.0362 4.0316 3.9676 3.9462 3.9138 3.8892];
Taken_dim_2=[3.3842 5.4642 5.3840 5.0036 4.4032 4.1535 4.0730 3.9937 3.9448 3.9253 3.8928 3.8647];
Taken_dim_3=[3.3842 3.6562 3.8771 3.8962 3.8611 3.8950 3.8778 3.8607 3.7999 3.7913 3.8042 3.7593];
Taken_dim_4=[7.9279 7.9538 7.8967 7.7778 7.6861 7.6369 7.5713 7.5636 7.4797 7.4797 7.4817 7.4721];
Taken_dim_5=[5.5427 5.5772 5.4958 5.4959 5.4581 5.3833 5.4033 5.3868 5.3426 5.3426 5.3113 5.3307];

%% Figure
h0=figure;
clf;
plot(C,Taken_dim_0,'MarkerSize',10,'Marker','*','LineWidth',2,...
'Color',[0 0 1]);hold on
plot(C,Taken_dim_1,'MarkerSize',10,'Marker','*','LineWidth',2,...
'Color',[1 0 0]);hold on
plot(C,Taken_dim_2,'MarkerSize',18,'Marker','.','LineWidth',2,...
'Color',[1 1 0]);hold on
plot(C,Taken_dim_3,'MarkerSize',18,'Marker','.','LineWidth',2,...
'Color',[0 1 0]);
plot(C,Taken_dim_4,'MarkerSize',18,'Marker','.','LineWidth',2,...
'Color',[0 1 1]);hold on
plot(C,Taken_dim_5,'MarkerSize',18,'Marker','.','LineWidth',2,...
'Color',[1 0 1]);

% Legend 
hleg1 =legend('Case\_1','Case\_2','Case\_3','Case\_4','Case\_5','Case\_6','NorthWest');
set(hleg1,'Location','NorthEast') 
axis([0 0.16 3 8.0])
set(gca, 'XTick', 0:0.02:0.16);  
% set(gca, 'YTick',0:0.02:0.2);

% Create axis font size
set(gca,'FontName','Arial','FontSize',14)
% Create xlabel
xlabel({'S^C'},'FontSize',20,'FontName','Arial');
% Create ylabel
ylabel({'Taken\_Dim'},'FontSize',20,'FontName','Arial');
print(h0,'-depsc2','-r300','HH_Three_Neurons_Taken_Dim.eps')
