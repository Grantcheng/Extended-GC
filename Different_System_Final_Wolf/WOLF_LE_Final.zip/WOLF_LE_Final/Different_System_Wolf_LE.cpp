/*   Uesed for calculating the spectrum of Lyapunove exponents of any
     dimension from time series(wolf)
*/
#include <iostream>
#include <math.h>
#include <fstream>
#include <cstdlib>
#include <stdio.h>
#include <vector>
#include <sstream>
#include <iomanip>
#include <string>
#include <time.h>
#include <fftw3.h>
#include "Duffing_Equation.h"
#include "tau_const.h"
#include "HHconst.h"
#include "Lya_input.h"
#include "SHHfunction.h"
#include "THHfunciton.h"
#include "save.h"
#include "loop.h"
#include "neuron.h"
#include "datainput.h"
#include "poisson_input.h"
#include <algorithm>
using namespace std;


struct vector_v *poisson_input=NULL;
struct vector_v *poisson_input_ml=NULL;
struct neuron *neu=NULL;
long *initialseed_neuron=NULL;
double *last_input=NULL;
long* ran_iy=NULL;
long** ran_iv=NULL;
double last_time=0.0;
double time_evolution=0.0;
int iset=0;
double gset=0.0;
long initial_seed=0;
double Tstep = 0.0;
double Strength_Exinput = 0.0;
double Strength_Ininput = 0.0;
double Current_0 = 0.00;
double Current_1 = 0.00;
double chose_current_change;
double Rate_input = 0.0;
int Multi_FNN=1;

fftw_complex *out;
fftw_complex *out1;
fftw_complex *out2;
fftw_complex  *in;
fftw_complex  *in1;
fftw_complex  *in2;
fftw_plan p;
fftw_plan p1;
fftw_plan p2;

#define NN_0 1000001
#define Dim 1
double	*WhiteNoise;
double	*WhiteNoise_1;
double *y;
double *y2;
double *LE;
double *yy;
double *yy2;
double FNN_Threshold;
int *tau_mutual;
int *tau_mutual2;
double *Convengence_LE;
double **Classify_S_NS; // classify the local Le in Spike or Nonspike region
double *Local_LE;
double yy_0[]={0.1,0,0.1};
double yy_ML[]={0,0.414915,0.00001}; // v(0)=-60.855  w(0)=0.014915
double yy_ML_2[]={-60.855,0.014915,0.00001,0.00001};
double yy_FN[]={-1,1,0.00001};
double yy_hh[]={-65,0.05293248500000000,0.59612075400000000,0.31767691400000000,0.00001};
double yy_hh_2[]={-65,0.05293248500000000,0.59612075400000000,0.31767691400000000,0.00001,0.00001,0.00001};
int FCGS;
double Dt;
double Omega;
double amp1;
int Algorithm_Choose;
int which_parameter=0;
int Tau;
int Tau2;
int Perid;
int Caiyang;
int Caiyang_Length;
int Equation_Choose;
int DIM;
int DIM2;
int DIM_Give;
int Choice_HH_Ori=1;
int Anlge_Divid;
int DOS;
int Tau_M;
int Strength_Change;
int Evolve;
int Length_N;
int Chose_Max_Scalmax;
int Lyap;
int NN;
int Neuron_Type;
int mul_exp_Start;
int mul_exp_Final;
int Inverse_V1_V2=0;
int Sample_Step=1;
int f1_f2_assign=0; // 对第一个和第二个神经元进行外部正弦刺激的频率
int iter_num;
int iter_num1=0;
int iter_num2=0;
int choose_MI;
long num_in_ball=0;
int Evolve_Num;
int replacement_num=0;
int non_replacement_num=0;
clock_t start,finish;
double Sample_interval;
double duration;
double duration_data;
double duration_sort;
double duration_mutual;
double duration_FNN;
double duration_total=0.0;
int Max_num_Com_M;
int Difference_Frequence_LE_Classic;
int Compute_ISI=0;
int Choose_Rate_or_Strength=0;
int Multi_Experiments=0;
//4;  HH Embedding Dimension;
double Scalmin=0.00001,Scalmax=0.0000137924;
double Max_Scalmax;
double Anglmax;
int save_LLE_classic;
int Save_each_solution;
double Mean_white;
double Sigma_white;
double Omega_F_Sine;
double tau;
long *ran_iy_w;
long **ran_iv_w;
long *initialseed_neuron_w;
double m_std,h_std,n_std;
/*Scalmin and Scalmax are the lenth scales that we consider to be too small and too large;
  Anglmax is the maximum angular error to be accepted at replacement time;Evolv is a constant
  propagation time; Dt is the time between the data samples.*/

double Vector[Dim],temp[300];
vector<vector<double> > ISIout;
vector<vector<double> > ISI;
vector<vector<vector<double> > >ISI_HH;
int f_n;
int Chose_FNN_Dmax;
int choose_Sine_Poisson_SciF_SciW;
int Flage_sci_flat_white;
//*******************************************************************************************

struct node
{
     double num;
     int index;
};

bool cmp(node x,node y)
{
return x.num<y.num?true:false;
}

int cmp2(const void *a,const void *b)
{
   return (*(node *)a).num > (*(node *)b).num? 1: -1;
}

double Cal_Lenth(int p1,int p2,int dim,int tau) //Calculate the distance between p1 and p2
{                                               //dim is the dimension of reconstruction,
 double Lenth=0.0;                           //tau is the the time delay in the reconstruction.

 for(int i=0;i<dim;i++)
 {
  int t=i*tau;
  Lenth=Lenth+(y[p1+t]-y[p2+t])*(y[p1+t]-y[p2+t]);
 }

 return Lenth=sqrt(Lenth);
}

double Cal_Lenth_Multi(int p1,int p2,int dimx,int dimy,int taux,int tauy) //Calculate the distance between p1 and p2
{                                               //dim is the dimension of reconstruction,
 double Lenth=0.0;
 int t;                           //tau is the the time delay in the reconstruction.

 for(int i=0;i<dimx;i++)
 {
  t=i*taux;
  Lenth=Lenth+(y[p1+t]-y[p2+t])*(y[p1+t]-y[p2+t]);
 }
 for(int i=0;i<dimy;i++)
 {
  t=i*tauy;
  Lenth=Lenth+(y2[p1+t]-y2[p2+t])*(y2[p1+t]-y2[p2+t]);
 }

 return Lenth=sqrt(Lenth);
}

double Cal_Angle(int p1,int p2,int p3,int dim,int tau) //Calculate the angle between vector p1_p2 and p1_p3
{
 double Dot=0;

 for(int i=0;i<dim;i++)
 {
  int Temp1=p1+i*tau,Temp2=p2+i*tau,Temp3=p3+i*tau;
  Dot=Dot+(y[Temp1]-y[Temp2])*(y[Temp1]-y[Temp3]);
 }

 double L1=Cal_Lenth(p1,p2,dim,tau),L2=Cal_Lenth(p1,p3,dim,tau);

 double Temp=fabs(Dot/(L2*L1));
 if(Temp>1) Temp=1;
 double Angle=acos(Temp);
 return Angle;
}

double Cal_Angle_Multi(int p1,int p2,int p3,int dimx,int dimy,int taux,int tauy) //Calculate the angle between vector p1_p2 and p1_p3
{
 double Dot=0;
 int Temp1,Temp2,Temp3;

 for(int i=0;i<dimx;i++)
 {
  Temp1=p1+i*taux,Temp2=p2+i*taux,Temp3=p3+i*taux;
  Dot=Dot+(y[Temp1]-y[Temp2])*(y[Temp1]-y[Temp3]);
 }
  for(int i=0;i<dimy;i++)
 {
  Temp1=p1+i*tauy,Temp2=p2+i*tauy,Temp3=p3+i*tauy;
  Dot=Dot+(y2[Temp1]-y2[Temp2])*(y2[Temp1]-y2[Temp3]);
 }

 double L1=Cal_Lenth_Multi(p1,p2,dimx,dimy,taux,tauy),L2=Cal_Lenth_Multi(p1,p3,dimx,dimy,taux,tauy);

 double Temp=fabs(Dot/(L2*L1));
 if(Temp>1) Temp=1;
 double Angle=acos(Temp);
 return Angle;
}

//*******************************************************************************************
int main()
{
vector<double>Lomega;
vector<double> Distance_sort;
vector<int> Distance_index;
double distance_tmp_0;
int Position_P=0;
unsigned long length;
long corrlength=1024;
int class_Spike=0;
int class_NonSpike=0;
int Save_C;
double alpha,beta,gamma,force;
int Local_LE_Classic=0;
vector<vector<double> >Couple;
vector<double> amp;

int num_neuron;
num_neuron=NumNeuron;

cout<<"Convergence_Test_0 = "<<Convergence_Test_0<<endl;
//cout<<"Lorenze System "<<endl;


printf(" Whether choose Wolf algorithm or Classic algorithm:   0 ---Classic   1 --- Wolf  ");
cin>>Algorithm_Choose;

//string sys_name;
printf("please input the equation type:\n      0-- HH Equation \n      1-- Duffing Equation \n      2-- Lorenz Equation \n      3-- Rossler Equation \n      4-- Morris-Lecar \n      5-- Fitzhugh_Nagumo  ");
cin>>Equation_Choose;
//getline(cin,sys_name);
//cout<<sys_name<<endl;
cout<<endl;

     switch(Equation_Choose)
   {
     case 0:
     cout << "------------------------------------------------------------\n"
	<< "HH Equation "<<"\n";
     cout<< "------------------------------------------------------------"<<endl;
     break;
     case 1:
      FCGS=3;
cout << "------------------------------------------------------------\n"
	<< "Duffing Equation "<<"\n"
        <<"dx=y "<<"\n"
        <<"dy=alpha*x-beta*x^3-gamma*y+f*cos(z) "<<"\n"
        <<"dz=omega "<<"\n"
        << "Please input initial parameter of the system " << "\n\n";
cout<< "------------------------------------------------------------"<<endl;

printf("please input the initial value = alpha  ");
cin>>alpha;
printf("please input the initial value = beta  ");
cin>>beta;
printf("please input the initial value = gamma  ");
cin>>gamma;
printf("please input the initial value = force  ");
cin>>force;
       break;
     case 2:
        FCGS=3;
        cout << "------------------------------------------------------------\n"
	<<"            Lorenz Equation            "<<"\n"
        <<"            dx/dt=sigmma*(y-x)     "<<"\n"
        <<"            dy/dt=-x(r-z)-y      "<<"\n"
        <<"            dz/dt=xy-bz      "<<"\n"
        <<"    This Equation Parameter as follows: "<<"\n"
        <<"       sigmma=16.0    r=45.92     b=4.0   "<<"\n"
        << "Please input initial parameter of the system " << "\n\n";
    cout<< "------------------------------------------------------------"<<endl;
       break;
   case 3:
        FCGS=3;
        cout << "------------------------------------------------------------\n"
	<<"            Rollser Equation            "<<"\n"
        <<"            dx/dt=-(y+z)     "<<"\n"
        <<"            dy/dt=x+a*y      "<<"\n"
        <<"            dz/dt=b+z(x-c)      "<<"\n"
        <<"    This Equation Parameter as follows: "<<"\n"
        <<"       a=0.15    b=0.2     c=10.0   "<<"\n"
        << "Please input initial parameter of the system " << "\n\n";
    cout<< "------------------------------------------------------------"<<endl;
       break;

   case 4:
        FCGS=4;
  cout << "------------------------------------------------------------\n"
       <<"            Morris-Lecar Model           "<<"\n"
       <<"    dv/dt = ( I - gca*minf(V)*(V-Vca)-gk*w*(V-VK)-gl*(V-Vl)+s(t))/c    "<<"\n"
       <<"    dw/dt = phi*(winf(V)-w)/tauw(V)  "<<"\n"
       <<"    v(0)=-60.855 "<<"\n"
       <<"    w(0)=0.014915  "<<"\n"
       <<"    minf(v)=.5*(1+tanh((v-v1)/v2)) "<<"\n"
       <<"    winf(v)=.5*(1+tanh((v-v3)/v4)) "<<"\n"
       <<"    tauw(v)=1/cosh((v-v3)/(2*v4)) "<<"\n"
       <<"    param i=0,vk=-84,vl=-60,vca=120 "<<"\n"
       <<"    param gk=8,gl=2,c=20 "<<"\n"
       <<"    param v1=-1.2,v2=18 "<<"\n"
       <<"    v3=2,v4=30,phi=.04,gca=4.4  "<<"\n";
     cout<< "------------------------------------------------------------"<<endl;
       break;

case 5:
        FCGS=5;
      cout << "------------------------------------------------------------\n"
          <<"            Fitzhugh-Nagumo Model           "<<"\n"
          <<"    dv/dt = FN_c(-w+v-v^3/3+I(t))   "<<"\n"
          <<"    dw/dt = v-FN_b*w+FN_a "<<"\n"
          <<"    FN_a=0.7,FN_b=0.8,FN_c=10 "<<"\n";
       cout<< "------------------------------------------------------------"<<endl;
      break;
   }

printf("please input the initial value = NN  ");
cin>>NN;
printf("please input the initial value = Length_N  ");
cin>>Length_N;
printf("please input the initial value = Dt  ");
cin>>Dt;

printf(" Neuron_Type : 1 -- Single Neuron     2 -- Two Neuron  ");
cin>>Neuron_Type ;

if (Neuron_Type==2)
{
printf("Whether assign value to f1 and f2 in sine stimulus: 0-- No , Yes-- 1   ");
        cin>>f1_f2_assign;
}

printf("Use One or Multi Variable to FNN  :  ");
cin>>Multi_FNN;

//*************************************************************************
if(Algorithm_Choose==1)
{
    if(Neuron_Type==1)
    {
         printf("Choose Embedding Dimension type: 0-- FNN , others-- given   ");
	     cin>>DIM;
    }
    else if (Neuron_Type==2)
    {
        printf("Whether inverse V1 V2: 0-- No , Yes-- 1   ");
            cin>>Inverse_V1_V2;

        printf("Choose Embedding Dimension type: 0-- FNN , 1-- given   ");
        cin>>DIM_Give;
        if(DIM_Give==1)
         {
           printf("The First Variable Embedding Dimension is :    ");
           cin>>DIM;
           printf("The Second Variable Embedding Dimension is :    ");
           cin>>DIM2;
         }
    }

        if(DIM==0)
        {
         printf("The Threshold for FFN is:  ");
         cin>>FNN_Threshold;
         printf("Whether chose the FNN Dmax : No -- 0  Yes -- 1 ");
         cin>>Chose_FNN_Dmax;
        }

	printf("please input the initial value Tau: 0 -- Mutual Information , others -- given  "); // if set Tau=0, then it will automatic compute delay time as follows
	cin>>Tau;

       if(Tau==0)
        {
          printf("The max corrlength to MI algorithm is:  ");
          cin>>corrlength;
        }

	if (Neuron_Type==2)
	{
	    Tau2=Tau;
	}

    printf("Whether Only Obtain Time Delay and Embedding Dimension: 0-- No   1--Yes  ");
	cin>>Tau_M;

        if(Tau==0)
       {
	printf("Choose Mutual Information type: 0-- Old , 1-- New_Opentstool   ");
	cin>>choose_MI;
       }

       if (Tau_M==0)
       {
	if(Tau>0)
	{
		printf("please input the initial value = Perid  "); // if Tau=0, then automatic compute Perid corresponding to function
		cin>>Perid;
	}

	printf("please input the initial value = Evolve  ");
	cin>>Evolve;

	printf("Choose the radia of ball type: 0-- given , 1-- Chose_Max_Scalmax (ratio with attractor)   ");
	cin>>Chose_Max_Scalmax;

	if(Chose_Max_Scalmax==0)
	{
		printf("please input the initial value radius of ball = Max_Scalmax    ");
		cin>>Max_Scalmax;
	}


	printf("please input the initial value of angle = Anlge_Divid    ");
	cin>>Anlge_Divid;
	Anglmax=3.14159/Anlge_Divid;
       }
      else if (Tau_M==1)
      {
        Evolve=10;
        Anlge_Divid=18;
        Anglmax=3.14159/Anlge_Divid;
       }

}

//*************************************************************************
if (Equation_Choose==0)
{
printf("Choose the stimulus type : 1-- Sine , 2-- Poisson , 3-- SciF , 4-- SciW , 5--SciW+Sine  ");
cin>>choose_Sine_Poisson_SciF_SciW;
}

printf("Whether Compute System Lyapunov Exponent : 0-- Not , 1-- Yes  ");
cin>>Lyap;
if(Lyap==1)
{
printf("Whether only save Local_LE_Classic: 0 -- Not , 1 -- Yes  ");
cin>>Local_LE_Classic;
if (Local_LE_Classic==0)
{
   save_LLE_classic=0;
}
else if(Local_LE_Classic=1)
{
   save_LLE_classic=1;
}
}
//*************************************************************************

	printf("Whether Save Classify_S_NS, Wolf Local_LE: 0-- No   1--Yes  ");
	cin>>Save_C;

	printf(" Whether using Caiyang : 0 --Not ,  1-- Yes  ");
	cin>>Caiyang;

    if (Caiyang==1)
    {
        printf("The CaiYang Sample is =  ");
        cin>>Sample_interval;
        Sample_Step=Sample_interval/Dt;
    }

if(Algorithm_Choose==1)
{
     if (Caiyang==1)
    {
        cout<<"Sample_Step = "<<Sample_Step<<endl;
        cout<<"The Max Evolve_Num  is :"<<(Length_N/(Sample_Step*Evolve))<<endl;
        int  Length_N_1=Length_N/Sample_Step;
        cout<<"The Length of data is:  "<<Length_N_1<<endl;
	    printf("please input the initial value = Evolve_Num    ");
	    cin>>Evolve_Num;
     }
    else
   {
    cout<<"The Max Evolve_Num  is :"<<(Length_N/Evolve)<<endl;
	printf("please input the initial value = Evolve_Num    ");
	cin>>Evolve_Num;
   }

}
//*************************************************************************
Convengence_LE=new double[Evolve_Num];
Local_LE=new double[Evolve_Num];

switch(Equation_Choose)
{
case 0:
printf("The number of Experiments: 1-- One, 2-- Multiple  ");
cin>>Multi_Experiments;

printf("Choose HH Dynamics Stimulate type: 0-- Only One Omega , 1-- Different Omega  ");
cin>>DOS;

break;
case 2:
DOS=0;
break;
case 3:
DOS=0;
break;
case 4:
printf("Choose Morris Lecar Dynamics Stimulate type: 0-- Only One Omega , 1-- Different Omega  ");
cin>>DOS;
break;
case 5:
printf("Choose FitzHugh Nagumo Dynamics Stimulate type: 0-- Only One Omega , 1-- Different Omega  ");
cin>>DOS;
break;
}
//*************************************************************************
cout<< "End input initial parameter of the system " << "\n";
cout<< "------------------------------------------------------------"<<endl;

double Distance;
double Down_min;
double Up_max;
int Down_Position_old;
int number=0;
int min_point=1; //要求最小搜索到的点数
 string fname;
 int i=0;
vector<double>y_0;
vector<double>y_p_0;
//**************************************************************************************************8
double OmegaStart;
double OmegaFinal;
double Steph;
double f_2;
int Omega_num=0;
//int Omega_num_1;


if(DOS==1)
{
        switch(Equation_Choose)
	{
	    case 0:
            cout << "------------------------------------------------------------\n"
		 << "Compute HH Dynamics " << "\n"
		 << "   Use Different Omega Stimulate " << ".\n"
		 << "------------------------------------------------------------\n\n";

          switch(choose_Sine_Poisson_SciF_SciW)
          {
            case 1:
            cout<<"**************************"<<endl;
	    cout<<" Sine Input "<<endl;
	    cout<<"**************************"<<endl;
            printf(" Please input the initial value = OmegaStart  ");
	    cin>>OmegaStart;
    	    printf(" Please input the initial value = OmegaFinal  ");
	    cin>>OmegaFinal;
	    OmegaStart=OmegaStart*f0;
	    OmegaFinal=OmegaFinal*f0;
            printf("please input the initial value = Amp1    ");
	    cin>>amp1;
            break;
            case 2:
            #if POISSON_INPUT_USE
            cout<<"**************************"<<endl;
	    cout<<" Poisson Input "<<endl;
	    cout<<"**************************"<<endl;

	    cout<<"Change Rate_input Or Strength_Exinput : 1 = Rate_input  2 = Strength_Exinput "<<endl;
	    cin>>Choose_Rate_or_Strength;
            if (Choose_Rate_or_Strength==1)
              {
    	       printf(" Please input the initial value = Rate_input_Start  ");
	       cin>>OmegaStart;
    	       printf(" Please input the initial value = Rate_input_Final  ");
	       cin>>OmegaFinal;
              }
            else if (Choose_Rate_or_Strength==2)
              {
    	       printf(" Please input the initial value = Strength_ExinputStart  ");
	       cin>>OmegaStart;
    	       printf(" Please input the initial value = Strength_ExinputFinal  ");
	       cin>>OmegaFinal;
              }

	    OmegaStart=OmegaStart;
	    OmegaFinal=OmegaFinal;

  	    char inputfile[32];
  	    setglobals();
  	    sprintf(inputfile,"test2.txt");
 	    readinput(inputfile);

	    #endif
            break;
            case 3:
            initial_seed=20072007;
            cout<<"**************************"<<endl;
	    cout<<" Sci Paper Flate Current Input "<<endl;
	    cout<<"**************************"<<endl;

       	    printf(" Please input the initial value = Mean_White_Start  ");
	    cin>>OmegaStart;
    	    printf(" Please input the initial value = Mean_White_Final  ");
	    cin>>OmegaFinal;

	    OmegaStart=OmegaStart;
	    OmegaFinal=OmegaFinal;
            break;

            case 4:
            cout<<"**************************"<<endl;
	    cout<<" Sci Paper White Noise Input "<<endl;
	    cout<<"**************************"<<endl;
            printf("Which parameters want to change: 1-- Mean_White  2-- Sigma_white  3--tau ");
            cin>>which_parameter;
            if (which_parameter==1)
              {
    	        printf(" Please input the initial value = Mean_White_Start  ");
	        cin>>OmegaStart;
    	        printf(" Please input the initial value = Mean_White_Final  ");
	        cin>>OmegaFinal;

		 //printf("Please input the Mean_White:  ");
		// cin>>Mean_white;

	         printf("Please input the Sigma_White  ");
		 cin>>Sigma_white;

		 printf("Please input the filter of the tau  ");
		 cin>>tau;
               }
            else if (which_parameter==2)
              {
    	         printf(" Please input the initial value = Sigma_white_Start  ");
	         cin>>OmegaStart;
    	         printf(" Please input the initial value = Sigma_white_Final  ");
	         cin>>OmegaFinal;
		 printf("Please input the Mean_White:  ");
		 cin>>Mean_white;

	         //printf("Please input the Sigma_White  ");
		// cin>>Sigma_white;

		 printf("Please input the filter of the tau  ");
		 cin>>tau;
               }
           else if (which_parameter==3)
               {
    	         printf(" Please input the initial value = tau_Start  ");
	         cin>>OmegaStart;
    	         printf(" Please input the initial value = tau_Final  ");
	         cin>>OmegaFinal;
		 printf("Please input the Mean_White:  ");
		 cin>>Mean_white;

	         printf("Please input the Sigma_White  ");
		 cin>>Sigma_white;

		 // printf("Please input the filter of the tau  ");
	 	 //cin>>tau;
               }

            if(Multi_Experiments==1)
                   {
	                cout<<"**************************"<<endl;
	                cout<<" Sci Paper White Noise Input "<<endl;
	                cout<<"**************************"<<endl;
                        OmegaStart=OmegaStart;
	                OmegaFinal=OmegaFinal;
                        mul_exp_Start=1;
                        mul_exp_Final=1;

                   }
             else
                   {
                        int num_exp;
	                cout<<"**************************"<<endl;
	                cout<<" Sci Paper White Noise Input "<<endl;
	                cout<<"**************************"<<endl;
                        printf("How many experiments will run:    ");
                        cin>>num_exp;
                        mul_exp_Start=1;
	        	mul_exp_Final=num_exp;
                        OmegaStart=OmegaStart;
	                OmegaFinal=OmegaFinal;
                    }

            break;

            case 5:
            cout<<"**************************"<<endl;
	    cout<<" Sci Paper White Noise + Sine Input "<<endl;
	    cout<<"**************************"<<endl;
            printf("Which parameters want to change: 1-- Mean_White  2-- Sigma_white  3--tau  4-- Sine_F ");
            cin>>which_parameter;

            if (which_parameter==1)
              {
    	         printf(" Please input the initial value = Mean_White_Start  ");
	         cin>>OmegaStart;
    	         printf(" Please input the initial value = Mean_White_Final  ");
	         cin>>OmegaFinal;

	         printf("Please input the Sigma_White  ");
		 cin>>Sigma_white;

		 printf("Please input the filter of the tau  ");
		 cin>>tau;

	         printf("Please input the Sine_F  ");
		 cin>>Omega_F_Sine;
               }
            else if (which_parameter==2)
              {
    	         printf(" Please input the initial value = Sigma_white_Start  ");
	         cin>>OmegaStart;
    	         printf(" Please input the initial value = Sigma_white_Final  ");
	         cin>>OmegaFinal;

		 printf("Please input the Mean_White:  ");
		 cin>>Mean_white;

		 printf("Please input the filter of the tau  ");
		 cin>>tau;

	         printf("Please input the Sine_F  ");
		 cin>>Omega_F_Sine;
               }
            else if (which_parameter==3)
               {
    	         printf(" Please input the initial value = tau_Start  ");
	         cin>>OmegaStart;
    	         printf(" Please input the initial value = tau_Final  ");
	         cin>>OmegaFinal;

		 printf("Please input the Mean_White:  ");
		 cin>>Mean_white;

	         printf("Please input the Sigma_White  ");
		 cin>>Sigma_white;

	         printf("Please input the Sine_F  ");
		 cin>>Omega_F_Sine;
                }
            else if (which_parameter==4)
                 {
                 printf(" Please input the initial value =  Sine_F_Start  ");
	         cin>>OmegaStart;
    	         printf(" Please input the initial value =  Sine_F_Final  ");
	         cin>>OmegaFinal;

		 printf("Please input the Mean_White:  ");
		 cin>>Mean_white;

	         printf("Please input the Sigma_White  ");
		 cin>>Sigma_white;

		 printf("Please input the filter of the tau  ");
		 cin>>tau;
                 }

            if(Multi_Experiments==1)
                   {
	                cout<<"**************************"<<endl;
	                cout<<" Sci Paper White Noise + Sine Input "<<endl;
	                cout<<"**************************"<<endl;
                        OmegaStart=OmegaStart;
	                OmegaFinal=OmegaFinal;
                        mul_exp_Start=1;
                        mul_exp_Final=1;

                   }
             else
                   {
                        int num_exp;
	                cout<<"**************************"<<endl;
	                cout<<" Sci Paper White Noise + Sine Input "<<endl;
	                cout<<"**************************"<<endl;
                        printf("How many experiments will run:    ");
                        cin>>num_exp;
                        mul_exp_Start=1;
	        	mul_exp_Final=num_exp;
                        OmegaStart=OmegaStart;
	                OmegaFinal=OmegaFinal;
                    }

            break;
          }
//Omega_num_1=(int)((OmegaFinal-OmegaStart)/Steph+0.5);
//LE=(double *)malloc(Omega_num_1*sizeof(double));

	   printf("Whether only compute Lyapunov Exponent with different stimula frequence: 0 -- Not , 1 -- Yes  ");
	   cin>>Difference_Frequence_LE_Classic;

	   printf("Whether Save_each_solution: 0 -- Not , 1 -- Yes  ");
	   cin>>Save_each_solution;
	   break;
	   case 4:
            cout << "------------------------------------------------------------\n"
		 << "Compute Morris Lecar Dynamics " << "\n"
		 << "   Use Different Omega Stimulate " << ".\n"
		 << "------------------------------------------------------------\n\n";
	    printf(" Please input the initial value = OmegaStart  ");
	    cin>>OmegaStart;
            printf(" Please input the initial value = OmegaFinal  ");
	    cin>>OmegaFinal;

//OmegaStart=OmegaStart*f0;
//OmegaFinal=OmegaFinal*f0;


	     OmegaStart=OmegaStart;
	     OmegaFinal=OmegaFinal;
           if(Neuron_Type==1)
           {
	    printf("please input the initial value = Amp1    ");
	    cin>>amp1;
           }
	    printf("Whether only compute Lyapunov Exponent with different stimula frequence: 0 -- Not , 1 -- Yes  ");
	    cin>>Difference_Frequence_LE_Classic;

	     printf("Whether only compute ISI with different stimula frequence: 0 -- Not , 1 -- Yes  ");
	     cin>>Compute_ISI;

	     printf("Whether Save_each_solution: 0 -- Not , 1 -- Yes  ");
	     cin>>Save_each_solution;
	     break;

	     case 5:
	    cout << "------------------------------------------------------------\n"
		 << "Compute Fitzhugh Nagumo Dynamics " << "\n"
		 << "   Use Different Omega Stimulate " << ".\n"
		 << "------------------------------------------------------------\n\n";
	     printf(" Please input the initial value = OmegaStart  ");
	     cin>>OmegaStart;
             printf(" Please input the initial value = OmegaFinal  ");
             cin>>OmegaFinal;

//OmegaStart=OmegaStart*f0;
//OmegaFinal=OmegaFinal*f0;

	     OmegaStart=OmegaStart;
	     OmegaFinal=OmegaFinal;
           if(Neuron_Type==1)
           {
	      printf("please input the initial value = Amp1    ");
	      cin>>amp1;
            }
	      printf("Whether only compute Lyapunov Exponent with different stimula frequence, not compute the solutions of system: 0 -- Not , 1 -- Yes  ");
	      cin>>Difference_Frequence_LE_Classic;

	      printf("Whether only compute ISI with different stimula frequence: 0 -- Not , 1 -- Yes  ");
	      cin>>Compute_ISI;

	      printf("Whether Save_each_solution: 0 -- Not , 1 -- Yes  ");
	      cin>>Save_each_solution;
	      break;
	   }
}
else if(DOS==0)
{



          switch(Equation_Choose)
       {
          case 0:
            cout << "------------------------------------------------------------\n"
		 << "Compute HH Dynamics " << "\n"
		 << "   Use Only One Omega Stimulate " << ".\n"
		 << "------------------------------------------------------------\n\n";
	  if(choose_Sine_Poisson_SciF_SciW==3)
             {
   		 Flage_sci_flat_white=1;
                 printf("Please input the Mean_White:  ");
                 cin>>Mean_white;
             }
	  else if (choose_Sine_Poisson_SciF_SciW==4 || choose_Sine_Poisson_SciF_SciW==5)
	    {
 	          if(Multi_Experiments==1)
                 {
                   initial_seed=20072007;
                 }
                 else
                 {
                   initial_seed=time(NULL);
                 }
                 cout<<"initial_seed = "<<initial_seed<<endl;

                if(choose_Sine_Poisson_SciF_SciW==5)
                   {
                      Flage_sci_flat_white=3;
                   }
                else
                   {
                      Flage_sci_flat_white=2;
                   }

		 printf("Please input the Mean_White:  ");
		 cin>>Mean_white;

	         printf("Please input the Sigma_White  ");
		 cin>>Sigma_white;

		 printf("Please input the filter of the tau  ");
		 cin>>tau;

                 if(choose_Sine_Poisson_SciF_SciW==5)
                   {
	                 printf("Please input the Sine_F  ");
		         cin>>Omega_F_Sine;
                   }
	     }

             if(choose_Sine_Poisson_SciF_SciW==1||choose_Sine_Poisson_SciF_SciW==2)
               {
                   printf("please input the initial value = OmegaStart    ");
                   cin>>Omega;


                   if(Neuron_Type==2)
                    {
                        printf("Whether change the strength automatically: 0--Not   1--Yes ");
                        cin>>Strength_Change;

                        if(f1_f2_assign==1)
                         {
                             printf("please input the frequence of the stimulu on second neuron  = f_2    ");
                             cin>>f_2;
                         }
                    }
                }
             else if(choose_Sine_Poisson_SciF_SciW==3||choose_Sine_Poisson_SciF_SciW==4)
               {
                   if(Multi_Experiments==1)
                       {
                          Omega=Mean_white;
                       }
                  else
                       {
                         int mul_exp=1;
                         Omega=Mean_white;
                       }
               }

             else if(choose_Sine_Poisson_SciF_SciW==5)
               {

                   if(Multi_Experiments==1)
                       {
                          Omega=Omega_F_Sine;
                       }
                  else
                       {
                         int mul_exp=1;
                         Omega=Omega_F_Sine;
                       }
               }

            switch(choose_Sine_Poisson_SciF_SciW)
            {
              case 1:
                cout<<"**************************"<<endl;
                cout<<" Sine Input "<<endl;
                cout<<"**************************"<<endl;
                printf("please input the initial value = Amp1    ");
                cin>>amp1;
                OmegaStart=Omega*f0;
                OmegaFinal=Omega*f0;
                break;
              case 2:
                #if POISSON_INPUT_USE
                cout<<"*****************************"<<endl;
                cout<<" Running Poisson Input Now "<<endl;
                cout<<"*****************************"<<endl;
                char inputfile[32];
                setglobals();
                sprintf(inputfile,"test2.txt");
                readinput(inputfile);
                OmegaStart=Omega;
                OmegaFinal=Omega;
	        #endif
                break;
              case 3:
                cout<<"**************************"<<endl;
	        cout<<" Sci Paper Flate Current Input "<<endl;
	        cout<<"**************************"<<endl;
	        OmegaStart=Omega;
	        OmegaFinal=Omega;
                break;
              case 4:

                if(Multi_Experiments==1)
                   {
	                cout<<"**************************"<<endl;
	                cout<<" Sci Paper White Noise Input "<<endl;
	                cout<<"**************************"<<endl;
                        OmegaStart=Omega;
	        	OmegaFinal=Omega;
                        mul_exp_Start=1;
                        mul_exp_Final=1;

                   }
                else
                   {
                        int num_exp;
	                cout<<"**************************"<<endl;
	                cout<<" Sci Paper White Noise Input "<<endl;
	                cout<<"**************************"<<endl;
                        printf("How many experiments will run:    ");
                        cin>>num_exp;
                        mul_exp_Start=1;
	        	mul_exp_Final=num_exp;
                        OmegaStart=Omega;
	        	OmegaFinal=Omega;
                    }
                break;

              case 5:

                if(Multi_Experiments==1)
                   {
	                cout<<"**************************"<<endl;
	                cout<<" Sci Paper White Noise + Sine Input "<<endl;
	                cout<<"**************************"<<endl;
                        OmegaStart=Omega;
	        	OmegaFinal=Omega;
                        mul_exp_Start=1;
                        mul_exp_Final=1;

                   }
                else
                   {
                        int num_exp;
	                cout<<"**************************"<<endl;
	                cout<<" Sci Paper White Noise +Sine Input "<<endl;
	                cout<<"**************************"<<endl;
                        printf("How many experiments will run:    ");
                        cin>>num_exp;
                        mul_exp_Start=1;
	        	mul_exp_Final=num_exp;
                        OmegaStart=Omega;
	        	OmegaFinal=Omega;
                    }
                break;
            }
     break;
     case 1:
            cout << "------------------------------------------------------------\n"
		 << "Compute Duffing Dynamics " << "\n"
		 << "   Use Only One Omega Stimulate " << ".\n"
		 << "------------------------------------------------------------\n\n";
            printf("please input the initial value = OmegaStart    ");
            cin>>Omega;
            OmegaStart=Omega;
            OmegaFinal=Omega;
    break;

     case 2:
OmegaStart=1;
OmegaFinal=1;
break;

case 3:
OmegaStart=1;
OmegaFinal=1;
break;

case 4:
cout << "------------------------------------------------------------\n"
		 << "Compute Morris Lecar Dynamics " << "\n"
		 << "   Use Only One Omega Stimulate " << ".\n"
		 << "------------------------------------------------------------\n\n";
printf("please input the initial value = OmegaStart    ");
cin>>Omega;

printf("Whether scan current_0: 0-- Not   1--Yes   ");
cin>>chose_current_change;
if (chose_current_change==0)
{
OmegaStart=Omega;
OmegaFinal=Omega;
}
else if (chose_current_change==1)
{
printf("please input the initial value = Current_0_Start    ");
cin>>OmegaStart;
printf("please input the initial value = Current_0_Final    ");
cin>>OmegaFinal;
}


if(Neuron_Type==1)
 {
 printf("please input the initial value = Amp1    ");
 cin>>amp1;
 }

if (chose_current_change==0)
{
printf("please input the initial value = Current_0    ");
cin>>Current_0;
}
printf("please input the initial value = Current_1    ");
cin>>Current_1;


printf("Whether only compute ISI with one stimula frequence in Morris Lecar Dynamics: 0 -- Not , 1 -- Yes  ");
cin>>Compute_ISI;

printf("Whether Save_each_solution: 0 -- Not , 1 -- Yes  ");
cin>>Save_each_solution;
break;

case 5:
cout << "------------------------------------------------------------\n"
		 << "Compute Fitzhugh Nagumo Dynamics " << "\n"
		 << "   Use Only One Omega Stimulate " << ".\n"
		 << "------------------------------------------------------------\n\n";
printf("please input the initial value = OmegaStart    ");
cin>>Omega;
OmegaStart=Omega;
OmegaFinal=Omega;
if(Neuron_Type==1)
{
 printf("please input the initial value = Amp1    ");
 cin>>amp1;
}

printf("Whether only compute ISI with one stimula frequence in Fitzhugh Nagumo Dynamics: 0 -- Not , 1 -- Yes  ");
cin>>Compute_ISI;

printf("Whether Save_each_solution: 0 -- Not , 1 -- Yes  ");
cin>>Save_each_solution;
break;

}
//LE=(double *)malloc(sizeof(double));
}
// obtain each solution of HH system equation

//***************************************************************************************//
 switch(Equation_Choose)
   {
          case 0:
       if(Neuron_Type==1)
	  {
          	 for (int i=0;i<5;i++)
		  {
		       y_0.push_back(yy_hh[i]);
		  }
        }
        else if(Neuron_Type==2)
        {
                 //
                 for(int i_num=0;i_num<num_neuron;i_num++)
	          {
                       for (int i=0;i<7;i++)
			{
		       		y_0.push_back(yy_hh_2[i]);
                        }
	          }
//******************************** Couple
			ifstream   infile("Couple.txt");
		if   (   !   infile   )
		{
			cout   << "can 't   open   Couple.txt"<<endl;
			exit(   -1   );
		}
			vector<double>temp;
			string line;
			istringstream istr;
			double data;
			while(getline(infile,line))
			{
				istr.str(line);
				while(istr>>data)
			{
				temp.push_back(data);
			}
				Couple.push_back(temp);
				temp.clear();
				istr.clear();

			}
				infile.close();
                   cout   << "The Couple is: "<<endl;
			for(unsigned int i=0;i<Couple.size();i++)
				{
					for (vector<double>::iterator iter=Couple[i].begin();iter !=Couple[i].end();++iter)
						{
							cout<<*iter<<" ";
						}
							cout<<endl;
				}

//************************************************************* amp
			ifstream   ampfile("amp.txt");
			if   (   !   ampfile   )
			{
				cout   << "can 't   open   amp.txt"<<endl;
				exit(   -1   );
			}
				string line_amp;
				istringstream iamp;
				while(getline(ampfile,line_amp))
			{
				iamp.str(line_amp);
				while(iamp>>data)
			{
				amp.push_back(data);
			}
				iamp.clear();

			}
				ampfile.close();
                       cout   << "The amp is: "<<endl;
             for (vector<double>::iterator iter=amp.begin();iter !=amp.end();++iter)
		{
                		cout<<*iter<<" ";
		}
                     cout<<endl;
//*********************************************************************
           }
  	         break;
           case 1:
	for (int i=0;i<FCGS;i++)
	{
		y_0.push_back(yy_0[i]);
	}
    		break;

           case 2:
	for (int i=0;i<FCGS;i++)
	{
		y_0.push_back(yy_0[i]);
	}
       		break;

            case 3:
	for (int i=0;i<FCGS;i++)
	{
		y_0.push_back(yy_0[i]);
	}
     		 break;

           case 4:
       if(Neuron_Type==1)
	  {
	for (int i=0;i<3;i++)
	{
		y_0.push_back(yy_ML[i]);
	}
  	 }
        else if(Neuron_Type==2)
        {
//
                 for(int i_num=0;i_num<num_neuron;i_num++)
	          {
                       for (int i=0;i<4;i++)
			{
		       		y_0.push_back(yy_ML_2[i]);
                        }
	          }
//******************************** Couple
			ifstream   infile("Couple.txt");
		if   (   !   infile   )
		{
			cout   << "can 't   open   Couple.txt"<<endl;
			exit(   -1   );
		}
			vector<double>temp;
			string line;
			istringstream istr;
			double data;
			while(getline(infile,line))
			{
				istr.str(line);
				while(istr>>data)
			{
				temp.push_back(data);
			}
				Couple.push_back(temp);
				temp.clear();
				istr.clear();

			}
				infile.close();
                   cout   << "The Couple is: "<<endl;
			for(unsigned int i=0;i<Couple.size();i++)
				{
					for (vector<double>::iterator iter=Couple[i].begin();iter !=Couple[i].end();++iter)
						{
							cout<<*iter<<" ";
						}
							cout<<endl;
				}

//************************************************************* amp
			ifstream   ampfile("amp.txt");
			if   (   !   ampfile   )
			{
				cout   << "can 't   open   amp.txt"<<endl;
				exit(   -1   );
			}
				string line_amp;
				istringstream iamp;
				while(getline(ampfile,line_amp))
			{
				iamp.str(line_amp);
				while(iamp>>data)
			{
				amp.push_back(data);
			}
				iamp.clear();

			}
				ampfile.close();
                       cout   << "The amp is: "<<endl;
             for (vector<double>::iterator iter=amp.begin();iter !=amp.end();++iter)
		{
                		cout<<*iter<<" ";
		}
                     cout<<endl;
//*********************************************************************
        }
         break;

	   case 5:
	for (int i=0;i<3;i++)
	{
		y_0.push_back(yy_FN[i]);
	}
 		break;

}
//***************************************************************************************
if(Neuron_Type==1)
{
        Lomega.resize(1);
}
 else if(Neuron_Type==2)
{
	Lomega.resize(num_neuron);
}
//****************************************************************************************

switch(Equation_Choose)
{
case 0:
if(DOS==1)
  {
    if(choose_Sine_Poisson_SciF_SciW==3)
     {
  		Flage_sci_flat_white=1;
		cout<<"************************"<<endl;
                printf("Please input the Steph of Mean_White: ");
                cin>>Steph;
                cout<<" The Steph is "<<Steph<<endl;
                cout<<"************************"<<endl;


     }
    else if (choose_Sine_Poisson_SciF_SciW==4 || choose_Sine_Poisson_SciF_SciW==5)
     {
              if(choose_Sine_Poisson_SciF_SciW==5)
                  {Flage_sci_flat_white=3;}
              else if(choose_Sine_Poisson_SciF_SciW==4)
                  {Flage_sci_flat_white=2;}

		cout<<"************************"<<endl;

                switch(which_parameter)
              {
               case 1:
                printf("Please input the Steph of Mean_White: ");
                cin>>Steph;
                cout<<" The Steph is "<<Steph<<endl;
                cout<<"************************"<<endl;
               break;
              case 2:
                printf("Please input the Steph of Sigma_white: ");
                cin>>Steph;
                cout<<" The Steph is "<<Steph<<endl;
                cout<<"************************"<<endl;
               break;
              case 3:
                printf("Please input the Steph of tau: ");
                cin>>Steph;
                cout<<" The Steph is "<<Steph<<endl;
                cout<<"************************"<<endl;
               break;
              case 4:
                printf("Please input the Steph of Sin_F: ");
                cin>>Steph;
                cout<<" The Steph is "<<Steph<<endl;
                cout<<"************************"<<endl;
               break;
              }
      }
}

if(choose_Sine_Poisson_SciF_SciW==1)
{
   #if POISSON_INPUT_USE
    if(DOS==1)
   {
	if(Choose_Rate_or_Strength==1)
	  {
		cout<<"************************"<<endl;
                printf("Please input the Steph of Rate: ");
                cin>>Steph;
                cout<<" The Steph is "<<Steph;
                cout<<"************************"<<endl;
	  }
	else if(Choose_Rate_or_Strength==2)
	  {
  		//Steph=0.025;
                cout<<"************************"<<endl;
                printf("Please input the Steph of Force: ");
                cin>>Steph;
                cout<<" The Steph is "<<Steph;
                cout<<"************************"<<endl;
          }
   }
   else if(DOS==0)
   {
                Steph=0.001/3;

   }
#else
Steph=0.001/3;

#endif
}

if(choose_Sine_Poisson_SciF_SciW==3||choose_Sine_Poisson_SciF_SciW==4 || choose_Sine_Poisson_SciF_SciW==5)
{
	if(DOS==0)
	{
           if(Multi_Experiments==1)
             {
	        Steph=0.001/3;

	     }
           else
           {
                Steph=0.001/3;

             }
         }
}
break;

case 2:
Steph=0.0001;
break;
case 3:
Steph=0.0001;
break;
case 4:
if (chose_current_change==0)
{
Steph=0.01;
}
else if (chose_current_change==1)
{
printf("Please input the Steph of Current_0 Change: ");
cin>>Steph;
cout<<" The Steph is "<<Steph<<endl;
cout<<"************************"<<endl;
}
break;
case 5:
Steph=0.0001;
break;
}
//***************************************************************************************//
string ISI_fname;
string ISI_f_fname;
vector<string> fname_HH;
vector<double> f_hh;

if(Equation_Choose==4||Equation_Choose==5)
	{
//string ISI_fname="ISI("+double_to_str(3*OmegaStart)+"_"+double_to_str(3*OmegaFinal)+")";
#if POISSON_INPUT_USE
ISI_fname="ISI("+double_to_str(OmegaStart)+"_"+double_to_str(OmegaFinal)+")";
ISI_f_fname="ISI("+double_to_str(OmegaStart)+"_"+double_to_str(OmegaFinal)+")_f";
#else
  ISI_fname="ISI("+double_to_str(f0*OmegaStart)+"_"+double_to_str(f0*OmegaFinal)+")";
  ISI_f_fname="ISI("+double_to_str(f0*OmegaStart)+"_"+double_to_str(f0*OmegaFinal)+")_f";
#endif
}


if(Equation_Choose==0)
{
    if (Strength_Change==0)
     {
           for(int k=0;k<NumNeuron;k++)
              {
                 fname_HH.push_back("ISI("+double_to_str(f0*OmegaStart)+"_"+double_to_str(f0*OmegaFinal)+")");
               }
             ISI_f_fname="ISI("+double_to_str(f0*OmegaStart)+"_"+double_to_str(f0*OmegaFinal)+")_f";
     }
else if (Strength_Change==1)
    {
        for(int k=0;k<NumNeuron;k++)
              {
                 fname_HH.push_back("ISI_S("+double_to_str(f0*OmegaStart)+"_"+double_to_str(f0*OmegaFinal)+")");
               }
             ISI_f_fname="ISI_S("+double_to_str(f0*OmegaStart)+"_"+double_to_str(f0*OmegaFinal)+")_f";
    }
}

if(choose_Sine_Poisson_SciF_SciW==3||choose_Sine_Poisson_SciF_SciW==4||choose_Sine_Poisson_SciF_SciW==5)
       {
          cout<<"*******************"<<endl;
       }
else
       {
             mul_exp_Start=1;
             mul_exp_Final=1;
       }

if(Neuron_Type==2)
   {
      if (Strength_Change==1)
         {
          OmegaFinal=OmegaStart+10*Steph;
         }
    }

int ISI_ii=0;
clock_t start_ISI,finish_ISI;
vector<double>f_omega;

if(Neuron_Type==2)
   {
      if (Strength_Change==1)
         {
           f_n=(int)((OmegaFinal-OmegaStart)/Steph+0.5);
         }
         else if(Strength_Change==0)
         {
             f_n=1;
         }
   }

ISI.resize(f_n);


ISI_HH.resize(NumNeuron);
for(int k=0;k<NumNeuron;k++)
{
 ISI_HH[k].resize(f_n);
}
//******************************* Big Cycle **************************
for(double Omega_1=OmegaStart;Omega_1<=OmegaFinal;Omega_1=(Omega_1+Steph))
   {

        if(Equation_Choose==0)
          {
              if(Neuron_Type==2)
              {
                  if(Couple[1][0]>0.2) break;
              }
          }

if(Neuron_Type==2)
   {
      if (Strength_Change==1)
         {
          Omega_1=OmegaStart;
         }
    }

if (chose_current_change==1)
{
cout<<"*******************"<<endl;
Current_0=Omega_1;
Omega_1=Omega;

cout<<"Omega = "<<Omega<<endl;
cout<<"Current_0 = "<<Current_0<<endl;
}
//***************************************************************************
        length=0;
        yy=(double *)malloc(NN*sizeof(double));
        yy2=(double *)malloc(NN*sizeof(double));
        double *y1_0;
        double *y2_0;
        y1_0=(double *)malloc(Length_N*sizeof(double));
        y2_0=(double *)malloc(Length_N*sizeof(double));
//************************************************************************
       if(Equation_Choose==0||Equation_Choose==4||Equation_Choose==5)
	{

            if(Multi_Experiments==1)
           {
           	 if(choose_Sine_Poisson_SciF_SciW==4 || choose_Sine_Poisson_SciF_SciW==5)
                   {
                     initial_seed=20072007;
                     Multi_Experiments=0;
                   }
           }
           else if(Multi_Experiments==2)
           {
		if(choose_Sine_Poisson_SciF_SciW==4 || choose_Sine_Poisson_SciF_SciW==5)
                {
                   initial_seed=time(NULL);
                  cout<<"initial_seed = "<<initial_seed<<endl;
                }
           }

#if POISSON_INPUT_USE
if(choose_Sine_Poisson_SciF_SciW==3||choose_Sine_Poisson_SciF_SciW==4 || choose_Sine_Poisson_SciF_SciW==5)
{
Lomega[0]=Omega_1;
}
else
{
        Lomega[0]=Omega_1*f0;
}
#else
        Lomega[0]=Omega_1;
#endif
//***********************************************************
              if(Neuron_Type==1)
               {
                  cout<<"Now is run Single Neuron Solution "<<endl;
	        }
            else if(Neuron_Type==2)
               {
                   if(Equation_Choose==4)
                   {
                     for(int i_num=1;i_num<num_neuron;i_num++)
		       {
                          Lomega[i_num]=Omega_1;
		       }
                      cout<<"Now is run Two Neurons Solution "<<endl;
                   }
                   else
                       {
                          if(f1_f2_assign==1)
                            {
                                  for(int i_num=1;i_num<num_neuron;i_num++)
		                  {
                                    Lomega[i_num]=f_2*f0;
                                  }
                            }
                        else
                            {
                              for(int i_num=1;i_num<num_neuron;i_num++)
		               {
                                 Lomega[i_num]=0;
		               }
                            }

                        }
               }
        cout<<"Omega1=  "<<Lomega[0]<<endl;
        cout<<"Omega2=  "<<Lomega[1]<<endl;
//***********************************************************
}
      else
       {
	Lomega[0]=Omega_1;
	}
//************************************************************************
        start=clock();
//************************************************************************
if(Equation_Choose==0||Equation_Choose==4||Equation_Choose==5)
	{

if(choose_Sine_Poisson_SciF_SciW==3)
{
   Mean_white=Omega_1;

}
else if (choose_Sine_Poisson_SciF_SciW==4)
{

 switch(which_parameter)
             {
               case 1:
                 Mean_white=Omega_1;
               break;
               case 2:
                 Sigma_white=Omega_1;
               break;
               case 3:
                 tau=Omega_1;
               break;
              }
}
else if (choose_Sine_Poisson_SciF_SciW==5)
{
 switch(which_parameter)
             {
               case 1:
                 Mean_white=Omega_1;
               break;
               case 2:
                 Sigma_white=Omega_1;
               break;
               case 3:
                 tau=Omega_1;
               break;
               case 4:
                 Omega_F_Sine=Omega_1;
               break;
              }
}


 #if POISSON_INPUT_USE

    if(DOS==1)
{
  if (choose_Sine_Poisson_SciF_SciW==1)
  {
       if(Choose_Rate_or_Strength==1)
     {
       Rate_input=Omega_1;
     }
       else if(Choose_Rate_or_Strength==2)
     {
        Strength_Exinput=Omega_1;
     }
       for(int i_num=0;i_num<num_neuron;i_num++)
	{
  		neuron_destroy(neu[i_num]);
	}
       free(neu);
       neu=NULL;
       setglobals();

           while (!y_p_0.empty())
		{
			y_p_0.pop_back();
		}

 }
}

if (choose_Sine_Poisson_SciF_SciW==1)
{
   if(Choose_Rate_or_Strength==1)
     {
       cout<<"*******************************************************"<<endl;
       cout<<" Rate_input = "<<Rate_input<<endl;
       cout<<"*******************************************************"<<endl;
     }
   else if(Choose_Rate_or_Strength==2)
     {
       cout<<"*******************************************************"<<endl;
       cout<<" Strength_Exinput = "<<Strength_Exinput<<endl;
       cout<<"*******************************************************"<<endl;

      }
       input_initialization(y_0);
   for( int i_i = 0; i_i < num_neuron; i_i++ )
      {
          #if Autonomy_Use
             for(int i_p=0;i_p<9;i_p++)
               {
                   y_p_0.push_back(neu[i_i].value[i_p]);
               }
           #else
              for(int i_p=0;i_p<8;i_p++)
               {
                   y_p_0.push_back(neu[i_i].value[i_p]);
               }
	   #endif
      }
}
#endif
}

//*********************************************************
if(Neuron_Type==2)
   {
      if (Strength_Change==1)
         {
          Couple[1][0]=Couple[1][0]+0.001;
	      cout<<"Couple = "<<Couple[1][0]<<endl;
         }
    }

//**************** Compute System Laypunov exponent **********************
if (Lyap==1)
{
 cout << "------------------------------------------------------------\n"
		 << "Compute System Laypunov Exponent  " << "\n"
		 << "   Use Classic Algorithm " << ".\n"
		 << "------------------------------------------------------------\n\n";
 switch(Equation_Choose)
   {
     case 0:
     if(choose_Sine_Poisson_SciF_SciW==1 || choose_Sine_Poisson_SciF_SciW==2)
      {
        if(Neuron_Type==1)
         {
           #if POISSON_INPUT_USE
           LyaHH_Poisson(y_p_0, Lomega,Dt);
           #else
           LyaHH (y_0, Lomega);
           #endif
         }
       else if(Neuron_Type==2)
         {
           Mul_LyaHH(y_0, Lomega, Couple, amp);
         }
       }
     else
       {
           LyaHH_SCI(y_0,Lomega,Flage_sci_flat_white);
         if (choose_Sine_Poisson_SciF_SciW==4 || choose_Sine_Poisson_SciF_SciW==5)
          {
           free(WhiteNoise);
           WhiteNoise=NULL;
          }
       }
       break;
     case 1:
       Lya(y_0,Lomega,alpha,beta,gamma,force);
       break;
     case 2:
        Lya_Sys (y_0,Lomega,Equation_Choose);
       break;
     case 3:
        Lya_Sys (y_0,Lomega,Equation_Choose);
       break;
     case 4:
         if(Neuron_Type==1)
         {
           LyaML (y_0, Lomega);
         }
         else if(Neuron_Type==2)
          {
            Mul_LyaML(y_0, Lomega, Couple, amp);
          }
       break;
     case 5:
       LyaFN (y_0, Lomega);
       break;
   }
 }
//************************ Compute ISI *************************************
if(Compute_ISI==1)
{
    double duration_ISI;
    start_ISI=clock();
    f_omega.push_back(Lomega[0]);

    switch(Equation_Choose)
     {
       case 0:
       if(Neuron_Type==2)
            {
              ISIout=ISIJin2(NN-1,Dt,y_0,Lomega,Couple,amp,y1_0,y2_0,Length_N);
            if (Strength_Change==1)
              {
                 f_omega.push_back(Couple[1][0]);
              }
             }
            for (int k=0;k<NumNeuron;k++)
               {
                   ISI_HH[k][ISI_ii].resize(ISIout[k].size());
                   ISI_HH[k][ISI_ii]=ISIout[k];
                }
                   FREE_1(ISIout);
                   ISI_ii++;
      case 4:
       ISIout=Morris_Lecar_Solve(NN-1, y_0, Lomega,Dt, yy);
       if(ISIout[0].size()==0)
          {
            ISI[ISI_ii].resize(0);
           }
       else
          {
            ISI[ISI_ii].resize(ISIout[0].size());
          }
       ISI[ISI_ii]=ISIout[0];
       ISI_ii++;
       break;
      case 5:
       ISIout=Fitzhugh_Nagumo_Solve(NN-1, y_0, Lomega,Dt, yy);
       if(ISIout[0].size()==0)
        {
           ISI[ISI_ii].resize(0);
        }
       else
        {
           ISI[ISI_ii].resize(ISIout[0].size());
        }

           ISI[ISI_ii]=ISIout[0];
           ISI_ii++;
       break;
     }

       finish_ISI=clock();
       duration_ISI=(double)(finish_ISI-start_ISI)/CLOCKS_PER_SEC;
       printf(" %f seconds\n", duration);
}
else
{
//******************** Solve the ODE *****************************************
if(Difference_Frequence_LE_Classic==0)
{
//**************************
     switch(Equation_Choose)
       {
     case 1:
          if(Caiyang==1)
          {
          Perid=(2*pi/Omega_1)/Dt;
          cout<<"Perid is  "<<Perid<<endl;
          }
          else if(Caiyang==0)
          {
          // Dt=((2*pi/Omega))/(630);
           //Perid=631;
            Perid=2*pi/Omega_1;
          }
          break;
       }
//**************************
       if((Equation_Choose==4)||(Equation_Choose)==5)
{
       vector<vector<double> > ISIout;
       vector<vector<double> > ISI;
}
      switch(Equation_Choose)
   {
     case 0:
 if(choose_Sine_Poisson_SciF_SciW==1 || choose_Sine_Poisson_SciF_SciW==2)
  {
      if(Neuron_Type==1)
      {
       #if POISSON_INPUT_USE
       ISIJin(NN-1,Dt,y_p_0,Lomega,Couple,amp,yy);
       #else
       ISIJin(NN-1,Dt,y_0,Lomega,Couple,amp,yy);
       #endif
      }
     else if(Neuron_Type==2)
      {
        ISIout=ISIJin2(NN-1,Dt,y_0,Lomega,Couple,amp,y1_0,y2_0,Length_N);
        number=Length_N;
        if (Strength_Change==1)
         {
          f_omega.push_back(Couple[1][0]);
         }

      }
  }
else
  {
      HH_SCI_ISIJin(NN-1,Dt,Flage_sci_flat_white,y_0,Lomega,yy);
  }
       break;
     case 1:
       System_Solve(NN-1, y_0, Lomega, alpha, beta, gamma, force, yy);
       break;
     case 2:
       Lorenz_System_Solve(NN-1, y_0, Lomega,Dt, yy);
       break;
     case 3:
       Rossler_System_Solve(NN-1, y_0, Lomega,Dt, yy);
       break;
     case 4:
       if(Neuron_Type==1)
         {
          ISIout=Morris_Lecar_Solve(NN-1, y_0, Lomega,Dt, yy);
         }
       else if(Neuron_Type==2)
         {
           Morris_Lecar_Solve2(NN-1,Dt,y_0,Lomega,Couple,amp,y1_0,y2_0,Length_N);
           number=Length_N;
         }
        break;
     case 5:
       ISIout=Fitzhugh_Nagumo_Solve(NN-1, y_0, Lomega,Dt, yy);
       break;
   }
//******************* HH ISI *************************************
FREE_1(ISIout);
//**************************


//------------------每隔一个周期进行采样还是直接从解中得-------------------------------
//switch(Caiyang)
//{
 	//case 0:
   if (Equation_Choose==0)
     {
        if(choose_Sine_Poisson_SciF_SciW==3||choose_Sine_Poisson_SciF_SciW==4 ||choose_Sine_Poisson_SciF_SciW==5)
          {
                for(int hh=0;hh<Length_N;hh++)
	         {
  		         y1_0[hh]=yy[hh+10000];
		          number++;
	          }
          }
         else
          {
              if(Neuron_Type==1)
                {
	                 for(int hh=0;hh<Length_N;hh++)
	                   {
                          y1_0[hh]=yy[hh+1000000];
		                  number++;
	                   }
                }
          }
      }
      else if (Equation_Choose==4)
       {
           if(Neuron_Type==1)
            {
           for(int hh=0;hh<Length_N;hh++)
	           {
                  y1_0[number]=yy[hh+1000000];
		          number++;
	           }
            }
       }

       else
     {
         for(int hh=0;hh<Length_N;hh++)
	     {
  	     	y1_0[hh]=yy[hh+1000000];
	    	number++;
	      }
      }

	//break;
	/*
	case 1:
       for(int hh=0;hh<Length_N;hh+=Sample_Step)
	{
 		 y1_0[number]=yy[hh+1000000];
                 if(Neuron_Type==2)
                    {
                      y2_0[number]=yy2[hh+1000000];
                    }
		 number++;
	 }
		 break;

}*/
//**************************
//------------------------------------------------------------------------------
finish=clock();

free(yy);
free(yy2);
yy=NULL;
yy2=NULL;

y=(double *)malloc(number*sizeof(double));
y2=(double *)malloc(number*sizeof(double));

duration_data=(double)(finish-start)/CLOCKS_PER_SEC;
printf("Load data processing cost %f seconds\n",duration_data);

int N=number;

 if (N>NN) cout<<"Not enogh space for time series"<<endl;
 cout << "------------------------------------------------------------"<<endl;
 cout<<"N="<<N<<endl;
 Caiyang_Length=N;
 length=N;

//
if (chose_current_change==1)
{
Omega_1=Current_0;
}

if(Local_LE_Classic==1)
	{
  cout<<" Only Save The Local_LE_Classic， Not consider the Wolf algorithm  "<<endl;
     number=0;
	}
else if(Local_LE_Classic==0)
	{
double y_max=y1_0[0];
double y_min=y1_0[0];
double y2_max=y2_0[0];
double y2_min=y2_0[0];
double y_temp,y2_temp;
for(int hh=0;hh<number;hh++)
       {
           y_temp=y1_0[hh];
           y2_temp=y2_0[hh];
          if (y_temp>y_max)
              y_max=y_temp;

          if (y2_temp>y2_max)
             y2_max=y2_temp;

          if (y_temp<y_min)
             y_min=y_temp;

          if (y2_temp<y2_min)
              y2_min=y2_temp;

       }
if(Inverse_V1_V2==0)
{
 for(int hh=0;hh<number;hh++)
       {
             y[hh]=(y1_0[hh]-y_min)/(y_max-y_min);
             y2[hh]=(y2_0[hh]-y2_min)/(y2_max-y2_min);
       }
}
else
{
 for(int hh=0;hh<number;hh++)
       {
             y2[hh]=(y1_0[hh]-y_min)/(y_max-y_min);
             y[hh]=(y2_0[hh]-y2_min)/(y2_max-y2_min);
       }
}
free(y1_0);
free(y2_0);
y1_0=NULL;
y2_0=NULL;

// fin.close();
//******************** Obtain TAU ***************************************
if(Algorithm_Choose==1)
{
	if (Tau==0)
	{
		cout << "------------------------------------------------------------\n"
			 << "Compute Delay Time " << "\n"
			 << "   Use Mutual Infomation Algorithm " << ".\n"
			 << "------------------------------------------------------------\n\n";
		double *y_tau;
		y_tau=(double *)malloc(N*sizeof(double));
                double *y_tau2;
		y_tau2=(double *)malloc(N*sizeof(double));

		tau_mutual=(int*)malloc(sizeof(int));
        tau_mutual2=(int*)malloc(sizeof(int));

                node *rr=(node *)malloc(N*sizeof(node));
                node *rr2=(node *)malloc(N*sizeof(node));
	if (NULL==tau_mutual)
		{
			exit(1);
		}

	cout<<"Now is running Mutual Information "<<endl;
	start=clock();

	if (choose_MI==0)
	//Mutual_Function (double *pdata,int * tau,unsigned long length,long corrlength);
		{
  		 cout<<"Now is running old Mutual Information algorithm  "<<endl;
  		 ///do{
                    Mutual_Function (y,tau_mutual,length,corrlength);
                   // }while(*tau_mutual<0);
		}
	else if(choose_MI==1)
		//The new mutual information from opentstool
		{
   			 for (int j=0;j<N;j++)
 			 {
  	  			 rr[j].num=y[j];
   	 			 rr[j].index=j;
  			 }
  				 sort(rr,rr+N,cmp);
    		 cout<<"Now is running New_Opentstool Mutual Information algorithm  "<<endl;
   	 for (int i_tau=0;i_tau<N;i_tau++)
         	 	 {
    		    		 y_tau[rr[i_tau].index]=(double)i_tau/N;
     	         	 }
  		 Mutual_Function_opentstool(y_tau,tau_mutual,length,corrlength);

		}

	free(rr);
        rr=NULL;

      	Tau=*tau_mutual;
        cout<<"The First Time Series Tau = "<<Tau<<endl;

        if(Neuron_Type==2)
          {
             if (choose_MI==0)
	//Mutual_Function (double *pdata,int * tau,unsigned long length,long corrlength);
		{
  		 cout<<"Now is running old Mutual Information algorithm  "<<endl;
  		 ///do{
                    Mutual_Function (y2,tau_mutual2,length,corrlength);
                   // }while(*tau_mutual<0);
		}
	else if(choose_MI==1)
		//The new mutual information from opentstool
		{

   			 for (int j=0;j<N;j++)
 			 {
  	  			 rr2[j].num=y2[j];
   	 			 rr2[j].index=j;
  			 }
  				 sort(rr2,rr2+N,cmp);
    		 cout<<"Now is running New_Opentstool Mutual Information algorithm  "<<endl;
   	 for (int i_tau=0;i_tau<N;i_tau++)
         	 	 {
    		    		 y_tau2[rr2[i_tau].index]=(double)i_tau/N;
     	         	 }
  		 Mutual_Function_opentstool(y_tau2,tau_mutual2,length,corrlength);

		}

            Tau2=*tau_mutual2;
            cout<<"The Second Time Series Tau2 = "<<Tau2<<endl;
          }

        finish=clock();
	duration_mutual=(double)(finish-start)/CLOCKS_PER_SEC;
	printf("Mutual information processing cost %f seconds\n",duration_mutual);

        free(rr2);
        rr2=NULL;
	free(tau_mutual);
        free(tau_mutual2);
	tau_mutual=NULL;
	tau_mutual=NULL;
    }
else
{
Tau2=Tau;
}
//***************************************************************************

//******************** Obtain Embedding dimension ***************************

if (DIM==0)
{
 cout << "------------------------------------------------------------\n"
		 << "Compute Embedding Dimension " << "\n"
		 << "   Use False Nearest Neighbor Algorithm " << ".\n"
		 << "------------------------------------------------------------\n\n";


 Max_num_Com_M=0;
 int d_max;

if(Chose_FNN_Dmax==1)
{
    printf("The Max Embedding Dimension for FFN is:  ");
    cin>>d_max;
}
else if(Chose_FNN_Dmax==0)
{
    d_max=15;
}
 double R_tol=15.0;
 double A_tol=2.0;
 int *Dim_FNN;

 if(Multi_FNN==2)
 {
 Dim_FNN=(int*)malloc(2*sizeof(int));
 }
 else if(Multi_FNN==1)
 {
 Dim_FNN=(int*)malloc(sizeof(int));
 }

 if (NULL== Dim_FNN)
  {
   exit(1);
  }
 cout<<"Now is running False Nearest Neighbor "<<endl;
 if (N>2000000)
 {Max_num_Com_M=2000000;}
 else
  {Max_num_Com_M=N;}


 start=clock();
 if(Multi_FNN==1)
 {
 FNN(y,Max_num_Com_M,Tau,d_max,R_tol,A_tol,Dim_FNN,DOS);
 DIM=*Dim_FNN;
 Dim_FNN[0]=0;
 if(Neuron_Type==2)
  {
     FNN(y2,Max_num_Com_M,Tau2,d_max,R_tol,A_tol,Dim_FNN,DOS);
     DIM2=*Dim_FNN;
  }
 }
 else if(Multi_FNN==2)
 {
 FNN_Multi(y,y2,Max_num_Com_M,Tau,Tau2,d_max,Dim_FNN);

 DIM=Dim_FNN[0];
 DIM2=Dim_FNN[1];

 }

 finish=clock();
 duration_FNN=(double)(finish-start)/CLOCKS_PER_SEC;
 printf("False Nearest Neighbor processing cost %f seconds\n",duration_FNN);
 cout<<"The First Time Series Tau = "<<Tau<<endl;
 cout<<"Embedding Dimension = "<<DIM<<".\n"
     << "------------------------------------------------------------\n\n";
if(Neuron_Type==2)
{
cout<<"The Second Time Series Tau2 = "<<Tau2<<endl;
cout<<"Embedding Dimension2 = "<<DIM2<<".\n"
     << "------------------------------------------------------------\n\n";
}
 free(Dim_FNN);
Dim_FNN=NULL;
}

if (Tau_M==1)
{
exit(1);
}

 switch(Equation_Choose)
     {
     case 0:
          Perid=Tau*(DIM-1);
          break;
     case 2:
          Perid=Tau*(DIM-1);
          break;
     case 3:
          Perid=Tau*(DIM-1);
          break;
     case 4:
          Perid=Tau*(DIM-1);
          break;
     case 5:
          Perid=Tau*(DIM-1);
          break;
     }
cout<<"Perid = "<<Perid<<endl;
//***************************************************************************
int flag=0;
int Point1=1;
int Point2[Dim];
int Point2_old[Dim];
int Point2_tmp[Dim];
int *Position;
node *r1=NULL;
int Ball_num1=0;
double Angle;
int Its=0; /*Do not begin from Point1=0,for the Angle between point 0 and
           i,Point2[0] is 0.*/
double Dmin[Dim],Dmin_tmp[Dim],LyapE[Dim],Sum0[Dim],Sum1[Dim];
        /*Point2[Dim] is used for storing the Dim nearest neighbors in ascend order.Dmin[Dim]
          is used for storing the nearst distances relevant to  Point2[Dim]. */

 //N=N-Dim*Tau-Evolve;                  //Calculate usefull size of datafill
 if(Multi_FNN==1)
 {
   N=N-(DIM-1)*Tau;
 }
else if(Multi_FNN==2)
{
    if((N-(DIM-1)*Tau)<=(N-(DIM2-1)*Tau2))
    {
        N=N-(DIM-1)*Tau;
    }
    else
    {
        N=N-(DIM2-1)*Tau2;
    }
}

node *r=(node *)malloc(N*sizeof(node));
Position=(int *)malloc(N*sizeof(int));
Classify_S_NS=new double*[Evolve_Num];
for (int k=0;k<Evolve_Num;k++)
    {
       Classify_S_NS[k]=new double[2];// allocate Evolve_Num X 2 matrix; First column record point1; Second column record class;
    }
//cout<<"usefull size of data:"<<N<<endl;
 for(i=0;i<Dim;i++) {Sum0[i]=0.0;Sum1[i]=0.0;Vector[i]=0.0;LyapE[i]=0.0;}
//****************************************************************************
//**********initial trajectory and nearby three points*************************
for(i=0;i<Dim;i++) {Dmin[i]=1000;Point2[i]=0;Point2_old[i]=0;Point2_tmp[i]=0;} //initialize the tow parameters.
//********************* Initial sort V values ************************************************
start=clock();
for (int j=0;j<N;j++)
  {
     r[j].num=y[j];
     r[j].index=j;
   }
   sort(r,r+N,cmp);
//****** determine Max_Scalmax by the ratio of attractor scale *************

if(Chose_Max_Scalmax==1)
{
 cout<<" Now is running radia of ball "<<endl;
  Max_Scalmax=(r[N-1].num-r[0].num)*0.015;
  cout<<"Max_Scalmax =  "<<Max_Scalmax<<endl;
}

//***************************************************************************

  //qsort(r,N,sizeof(r[0]),cmp2);
for(int j=0;j<N;j++)
{
 Position[r[j].index]=j;
}
finish=clock();
duration_sort=(double)(finish-start)/CLOCKS_PER_SEC;
printf("sort data processing cost %f seconds\n",duration_sort);
//*************************************************************************
    Down_min=r[Position[Point1]].num-Max_Scalmax;
    Up_max=r[Position[Point1]].num+Max_Scalmax;
    Down_Position_old=Position[Point1];
    r1=(node *)malloc(N*sizeof(node)); // Bug??
    //r1=new node[N];
   if (NULL==r1)
{
exit(1);
}

for (int j=0;j<N;j++)
  {
     Distance=r[j].num;
     if (Distance<Down_min) continue;
     if(Distance>Up_max) break;
     if(r[j].index>N) continue;

     if(Multi_FNN==1)
     {
        r1[Ball_num1].num=Cal_Lenth(Point1,r[j].index,DIM,Tau);
     }
     else if(Multi_FNN==2)
     {
        r1[Ball_num1].num=Cal_Lenth_Multi(Point1,r[j].index,DIM,DIM2,Tau,Tau2);
     }

     r1[Ball_num1].index=r[j].index;
     Ball_num1++;
   }
   sort(r1,r1+(Ball_num1-1),cmp);
  //qsort(r1,(Ball_num1-1),sizeof(r1[0]),cmp2);

   for (int l=0;l<Ball_num1;l++)
    {
    Point2_tmp[0]=r1[l].index;
    if(fabs(Point2_tmp[0]-Point1)<Perid) continue;
    if (Point2_tmp[0]>(N-Evolve)) continue; //不在距离范围内跳过
    Dmin[0]=r1[l].num;
    Point2[0]=r1[l].index;
    break;
    }
 free(r1);
 //delete [] r1;
 r1=NULL;
 //**********The nearest pionts Point2[Dim] has been found********************
  cout<<"Point1=  "<<Point1<<endl;
  for(i=0;i<Dim;i++) {cout<<"Point2["<<i<<"]="<<Point2[i]<<endl;}
   Sum0[0]=Dmin[0];
    if(y[Point1]>20)
	{
            Classify_S_NS[Its][0]=y[Point1];
            Classify_S_NS[Its][1]=1;
            class_Spike++;
         }
    else if(y[Point1]<=20)
	{
            Classify_S_NS[Its][0]=y[Point1];
            Classify_S_NS[Its][1]=0;
            class_NonSpike++;
	}
  Point1=Point1+Evolve;
  Point2[0]=Point2[0]+Evolve;

  Point2_old[0]=Point2[0];

  if(Multi_FNN==1)
  {
    Sum1[0]=Cal_Lenth(Point1,Point2[0],DIM,Tau);
  }
  else if(Multi_FNN==2)
  {
      Sum1[0]=Cal_Lenth_Multi(Point1,Point2[0],DIM,DIM2,Tau,Tau2);
  }

  for(i=0;i<Dim;i++) {cout<<Sum0[i]<<'\t'<<Sum1[i]<<endl;}

   LyapE[0]=LyapE[0]+log(Sum1[0]/Sum0[0])/(Evolve*Dt*Sample_Step);
    Convengence_LE[Its]=LyapE[0];
   Local_LE[Its]=log(Sum1[0]/Sum0[0])/(Evolve*Dt*Sample_Step);
  Its++;

// **********这里是在找离参考轨道上一点最临近的点**********
//int num_in_ball; int replacement_num;int non_replacement_num;
iter_num=0;

start=clock();
 for (int n=1;n<Evolve_Num;n++)
 {
      iter_num++;
     // Point1=n;
   //********************find the first nearest point****************************
    int point_num = 0  ; // &&在指定距离范围内找到的候选相点的个数
    double cos_sita = 0.0  ;// %夹角余弦的比较初值---要求一定是锐角


//*********************************************************************
r1=(node *)malloc(N*sizeof(node));
 if (NULL==r1)
{
exit(1);
}
Down_min=r[Position[Point1]].num-Max_Scalmax;
Up_max=r[Position[Point1]].num+Max_Scalmax;
Down_Position_old=Position[Point1];

//************First method, but slower*****************
/*
for (int j=0;j<N;j++)
  {
     Distance=r[j].num;
     if (Distance<Down_min) continue;
     if(Distance>Up_max) break;
     r1[Ball_num1].num=Cal_Lenth(Point1,r[j].index,DIM,Tau);
     r1[Ball_num1].index=r[j].index;
     Ball_num1++;
   }
 */
//******************************************************

//*******Second method, want to increase speed**********
while(1)
{
    flag=0;
    if(Multi_FNN==1)
    {
       distance_tmp_0=Cal_Lenth(Point1,Point2[0],DIM,Tau);
    }
    else if(Multi_FNN==2)
    {
        distance_tmp_0=Cal_Lenth_Multi(Point1,Point2[0],DIM,DIM2,Tau,Tau2);
    }

    if(distance_tmp_0<Max_Scalmax) {flag=0;point_num = 1;Dmin[0]=distance_tmp_0;break;}
    Position_P=Down_Position_old;Ball_num1=0;
while(1)
{
     if(Position_P>N) break;
     Distance=r[Position_P].num;
     if(Distance>Up_max) break;
     if(r[Position_P].index>N){Position_P++; continue;}

     if(Multi_FNN==1)
     {
        distance_tmp_0=Cal_Lenth(Point1,r[Position_P].index,DIM,Tau);
     }
     else if(Multi_FNN==2)
     {
         distance_tmp_0=Cal_Lenth_Multi(Point1,r[Position_P].index,DIM,DIM2,Tau,Tau2);
     }

     if(distance_tmp_0>Max_Scalmax){Position_P++; continue;}
     r1[Ball_num1].num=distance_tmp_0;
     r1[Ball_num1].index=r[Position_P].index;
     Ball_num1++;
     Position_P++;

}
    Position_P=Down_Position_old-1;
while(1)
{
     if(Position_P<0) break;
     Distance=r[Position_P].num;
     if (Distance<Down_min) break;
     if(r[Position_P].index>N) {Position_P--;continue;}
     //cout<<Ball_num1<<endl;
     //cout<<r[Position_P].index<<endl;

     if(Multi_FNN==1)
     {
         distance_tmp_0=Cal_Lenth(Point1,r[Position_P].index,DIM,Tau);
     }
     if(Multi_FNN==2)
     {
         distance_tmp_0=Cal_Lenth_Multi(Point1,r[Position_P].index,DIM,DIM2,Tau,Tau2);
     }

     if(distance_tmp_0>Max_Scalmax){Position_P--; continue;}
     r1[Ball_num1].num=distance_tmp_0;
     r1[Ball_num1].index=r[Position_P].index;
     Ball_num1++;
     if(Position_P==0) break;
     Position_P--;

}

Position_P=0;
//******************************************************
   sort(r1,r1+(Ball_num1-1),cmp);
 //qsort(r1,(Ball_num1-1),sizeof(r1[0]),cmp2);
point_num = 0;
break;}
  /* Distance_sort.resize(Ball_num1-1);
  Distance_index.resize(Ball_num1-1);
   for (int l=0;l<(Ball_num1-1);l++)
    {
    Distance_sort[l]=r1[l].num;
    Distance_index[l]=r1[l].index;
    }
*/

//*********************************************************************
  while (point_num<1)
{
    iter_num1=0;
   // search point
 for (int j=1;j<(Ball_num1-1);j++)
 {
     Dmin_tmp[0]=r1[j].num;
     Point2_tmp[0]=r1[j].index;
     if(fabs(Point2_tmp[0]-Point1)<Perid) continue;
     if (Point2_tmp[0]>(N-Evolve)) continue; //不在距离范围内跳过
    // compute the smallest distance
      iter_num1++;

      if(Multi_FNN==1)
      {
           Angle=Cal_Angle(Point1,Point2_tmp[0],Point2_old[0],DIM,Tau); //计算夹角余弦及比较
      }
      else if(Multi_FNN==2)
      {
           Angle=Cal_Angle_Multi(Point1,Point2_tmp[0],Point2_old[0],DIM,DIM2,Tau,Tau2); //计算夹角余弦及比较
      }

    if(Angle>Anglmax) continue; //the angle between ith point all Point2[Dim-1]s and the ith point isn't 0.
    if (cos(Angle)>cos_sita) //新夹角小于过去已找到的相点的夹角，保留
      {
         cos_sita=cos(Angle);
         Point2[0]=Point2_tmp[0];
         Dmin[0]=Dmin_tmp[0];
         point_num=point_num+1;
         flag=1;
       } //end? if (cos(Angle)>cos_sita)

  }
   num_in_ball+=iter_num1;
  if (point_num<min_point)
  {
    flag=0;
    Dmin[0]=Sum1[0]; //addition
    break;
  }

 } //?end while(point_num == 0)

if(flag==1)
{
    replacement_num+=1;
}
 else if(flag==0)
{
    non_replacement_num+=1;
}
free(r1);
r1=NULL;
number=0;
  //**********The nearest pionts Point2[Dim] has been found********************
  //cout<<"Point1="<<Point1<<endl;
  //for(i=0;i<Dim;i++) {cout<<"Point2["<<i<<"]="<<Point2[i]<<endl;}
  Sum0[0]=Dmin[0];

     if(Multi_FNN==1)
      {
           Angle=Cal_Angle(Point1,Point2[0],Point2_old[0],DIM,Tau); //计算夹角余弦及比较
      }
      else if(Multi_FNN==2)
      {
           Angle=Cal_Angle_Multi(Point1,Point2[0],Point2_old[0],DIM,DIM2,Tau,Tau2); //计算夹角余弦及比较
      }

  Point1=Point1+Evolve;
  Point2[0]=Point2[0]+Evolve;
  Point2_old[0]=Point2[0];
  if(Point1>N-1) break;

  if(Multi_FNN==1)
  {
      Sum1[0]=Cal_Lenth(Point1,Point2[0],DIM,Tau);
  }
   else if(Multi_FNN==2)
  {
      Sum1[0]=Cal_Lenth_Multi(Point1,Point2[0],DIM,DIM2,Tau,Tau2);
  }

  if((Sum1[0]>1e-10)&&(Sum0[0]>1e-10))
   {
    //cout<<Sum0[0]<<'\t'<<Sum1[0]<<endl;
    //cout<<Angle<<endl;
    LyapE[0]=LyapE[0]+log(Sum1[0]/Sum0[0])/(Evolve*Dt*Sample_Step);
    if(y[Point1-Evolve]>20)
	    {
     	       Classify_S_NS[Its][0]=y[Point1];
    	       Classify_S_NS[Its][1]=1;
               class_Spike++;
	    }
       else if(y[Point1-Evolve]<=20)
 	    {
               Classify_S_NS[Its][0]=y[Point1];
               Classify_S_NS[Its][1]=0;
               class_NonSpike++;
            }
	Its++;
     Local_LE[Its-1]=log(Sum1[0]/Sum0[0])/(Evolve*Dt*Sample_Step);
     Convengence_LE[Its-1]=LyapE[0]/Its;
    }
  if((iter_num%500000)==0)
   {cout<<"Point1="<<Point1<<endl;
    for(i=0;i<Dim;i++) {cout<<"Point2["<<i<<"]="<<Point2[i]<<endl;
    cout<<Sum0[0]<<'\t'<<Sum1[0]<<endl;
    cout<<Angle<<endl;}
     }
 }

free(y);
y=NULL;
free(Position);
Position=NULL;
free(r);
r=NULL;
LyapE[0]=LyapE[0]/(Its);
//***********************************
if(DOS==1)
{
ofstream outfile("file_out_LE.txt",ios::app);

if(!outfile)
{
cout<<"File couldn't open\n";
 //return;
}
outfile<<setprecision(16)<<LyapE[0]<<"    "<<setprecision(16)<<Lomega[0]<<"    ";
outfile << endl;
outfile.close();
}
else if(DOS==0)
{
ofstream outfile("file_out_LE.txt",ios::app);

if(!outfile)
{
cout<<"File couldn't open\n";
 //return;
}
outfile<<setprecision(16)<<LyapE[0]<<"    "<<setprecision(16)<<Lomega[0]<<"    "<<setprecision(16)<<Length_N<<"    ";
outfile << endl;
outfile.close();
}
//-------------------------------------------
if(Save_C==1)
{
char *str_eig=(char *)malloc(256*sizeof(char));
if (str_eig==NULL)
{
  cout<<" can not allocate space! "<<endl;
  getchar();
}
ofstream eig_write;
switch(Equation_Choose)
{
case 0:
sprintf(str_eig,"Convergence/Convengence_LE_f_%f.txt",Lomega[0]);
eig_write.open(str_eig,ios::app);
if (eig_write.fail())
{
   cout<<"Error: open convergence file error!" <<endl;
   getchar();

}
for (unsigned int cl=0; cl<Its; cl++)
     {
	eig_write<<setprecision(16)<<Convengence_LE[cl]<<"    ";
     }
eig_write << endl;
break;

case 1:
sprintf(str_eig,"Convergence/Convengence_LE_%f_%f.txt",gamma,force);
eig_write.open(str_eig,ios::app);
if (eig_write.fail())
{
   cout<<"Error: open convergence file error!" <<endl;
   getchar();
   //return;
}
for (unsigned int cl=0; cl<Its; cl++)
     {
	eig_write<<setprecision(16)<<Convengence_LE[cl]<<"    ";
     }
eig_write << endl;
break;
}

eig_write.close();

//LE[Omega_num]=LyapE[0];
//***********************************
//-------------------------------------------
char *Localle=(char *)malloc(256*sizeof(char));
if (Localle==NULL)
{
  cout<<" can not allocate space! "<<endl;
  getchar();
}
ofstream local_write;
sprintf(Localle,"Local_LE/Local_LE_f_%f.txt",Lomega[0]);
local_write.open(Localle,ios::out);
if (local_write.fail())
{
   cout<<"Error: open Local_LE file error!" <<endl;
   getchar();
   //return;
}
for (unsigned int cl=0; cl<Its; cl++)
     {
	local_write<<setprecision(16)<<Local_LE[cl]<<"    ";
        local_write << endl;
     }

local_write.close();

//-------------------------------------------
char *Classify=(char *)malloc(256*sizeof(char));
if (Localle==NULL)
{
  cout<<" can not allocate space! "<<endl;
  getchar();
}
ofstream Classify_write;
sprintf(Classify,"Classify_S_NS/Classify_f_%f.txt",Lomega[0]);
Classify_write.open(Classify, ios::out);
if (Classify_write.fail())
{
   cout<<"Error: open Classify_S_NS file error!" <<endl;
   getchar();
   //return;
}
for (unsigned int cl=0; cl<Its; cl++)
     {
	Classify_write<<setprecision(16)<<Classify_S_NS[cl][0]<<"    "<<setprecision(16)<<Classify_S_NS[cl][1]<<"      ";
        Classify_write << endl;
     }

Classify_write.close();
}
//***********************************
  delete [] Local_LE;
  Local_LE=NULL;
//***********************************
  delete [] Convengence_LE;
  Convengence_LE=NULL;
//***********************************
  for(int k=0;k<Evolve_Num;k++)
    {
    delete[] Classify_S_NS[k];
    Classify_S_NS[k]=NULL;
    }
    delete[] Classify_S_NS;
    Classify_S_NS=NULL;
//***********************************
cout<<endl;
cout<<endl;
if(Neuron_Type==1)
{cout<<"This is the Single Neuron Solution "<<endl;}
else if(Neuron_Type==2)
{
    cout<<"This is the Two Neurons Solution "<<endl;
    //output the relationship with those neurons
    cout   << "The Couple is: "<<endl;
			for(unsigned int i=0;i<Couple.size();i++)
				{
					for (vector<double>::iterator iter=Couple[i].begin();iter !=Couple[i].end();++iter)
						{
							cout<<*iter<<" ";
						}
							cout<<endl;
				}
     // output the amp in neuron stimulus
     cout   << "The amp is: "<<endl;
             for (vector<double>::iterator iter=amp.begin();iter !=amp.end();++iter)
		{
                		cout<<*iter<<" ";
		}
                     cout<<endl;

}
cout<<"LyapE["<<0<<"]="<<LyapE[0]<<endl;
cout<<"Max_Scalmax= "<<Max_Scalmax<<endl;
cout<<"Length_N= "<<Length_N<<endl;
cout<<"DIM= "<<DIM<<endl;
cout<<"Tau= "<<Tau<<endl;
cout<<"Perid= "<<Perid<<endl;
cout<<"Evolve= "<<Evolve<<endl;
cout<<"Dt= "<<Dt<<endl;
cout<<"Evolve_Num= "<<Evolve_Num<<endl;
cout<<"Anglmax = "<<Anglmax<<endl;
cout<<"Average Points in ball= "<< (num_in_ball/iter_num)<<endl;
cout<<"Replacement number= "<<(replacement_num)<<endl;
cout<<"Non_Replacement number= "<<(non_replacement_num)<<endl;
cout<<"The radia of Ball is  "<<Max_Scalmax<<endl;
switch(Equation_Choose)
   {
case 0:
cout<<"HH_Solution_w1_"<<Lomega[0]<<"_0.txt"<<endl;
break;
case 4:
cout<<"Morris_Lecar_Solution_w1_"<<Lomega[0]<<"_0.txt"<<endl;
break;
   }
cout<<"The number in Spike region  "<<class_Spike<<endl;
cout<<"The number in Non-Spike region "<<class_NonSpike<<endl;

switch(Caiyang)
{
   case 0:
cout<<" It is not using Caiyang processing "<<endl;
   break;
   case 1:
cout<<" It is using Caiyang processing "<<endl;
cout<<"The CaiYang Sample is =  "<<Sample_interval<<endl;
cout<<"  The whole length after Caiyang N=  " <<Caiyang_Length<<endl;
         break;
}

if(Equation_Choose==1)
{

cout<<"alpha is  "<<alpha<<endl;
cout<<"beta is  "<<beta<<endl;
cout<<"gamma is  "<<gamma<<endl;
cout<<"force is  "<<force<<endl;

}
finish=clock();
duration=(double)(finish-start)/CLOCKS_PER_SEC;
duration_total=duration_total+duration;
if(Inverse_V1_V2==1)
{
cout<<"Inverse the V1 and V2 for compute the largest LE by wolf algorithm"<<endl;
}
printf("Load data processing cost %f seconds\n",duration_data);
printf("Mutual information processing cost %f seconds\n",duration_mutual);
printf("Embedding dimension processing cost %f seconds\n",duration_FNN);
printf("sort data processing cost %f seconds\n",duration_sort);
printf("Last step processing cost %f seconds\n",duration);
printf("Total processing cost %f seconds\n",(duration+duration_data+duration_mutual+duration_FNN+duration_sort));
Omega_num++;

    if(DOS==1)
      {
cout << "------------------------------------------------------------\n"
		 << "Compute HH Dynamics " << "\n"
		 << "   The Next Omega Stimulate " << ".\n"
		 << "------------------------------------------------------------\n\n";
Tau=0;
DIM=0;
      }
}
}
}
}
//************************ save ISI *************************************
if(Compute_ISI==1)
{
    switch(Equation_Choose)
{
    case 0:
    {
            if(Neuron_Type==2)
    {
        for (int k=0;k<NumNeuron;k++)
           {
             save(ISI_HH[k],fname_HH[k]);
            }
         save_f(f_omega,ISI_f_fname);
      }
      // Release Memory
      vector<vector<vector<double> > >ISI_HH_temp;
      vector<double>f_HH_temp;
      ISI_HH.swap(ISI_HH_temp);
      f_omega.swap(f_HH_temp);
      break;

    }

    case 4:
    {
         save(ISI,ISI_fname);
      save_f(f_omega,ISI_f_fname);
      // Release Memory
      vector<double>f_temp;
      vector<vector<double> > ISI_temp;
      ISI.swap(ISI_temp);
      f_omega.swap(f_temp);
      break;
    }

   case 5:
   {
            save(ISI,ISI_fname);
     save_f(f_omega,ISI_f_fname);
     // Release Memory
     vector<double>f5_temp;
     vector<vector<double> > ISI5_temp;
     ISI.swap(ISI5_temp);
     f_omega.swap(f5_temp);
     break;
   }

}
}
}// end Big Cycle??//-------------------------------------------------------------------------------------------

}

