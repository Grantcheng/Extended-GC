#include<iostream>
#include<cmath>
#include<stdio.h>
#include<math.h>
#include<fstream>
#include <cstdlib>
#include<vector>
#include<sstream>
#include<string>
#include<time.h>
#include<algorithm>
#include"HHconst.h"
#include "tau_const.h"

using namespace std;

double STD(double *pdata,int n);
void PhaSpaRecon(double *x,double ** &xn, int n ,int tau,int max_Dim);
void PhaSpaRecon2(double *x,double *x2,double ** &xn, int n ,int tau,int tau2,int mx_1,int my_1);
//***********************************************************************************************
struct node1
{
     double num;
     int index;
};
//***********************************************************************************************

bool cmp(node1 x,node1 y)
{
return x.num<y.num?true:false;
}

//***********************************************************************************************
double Cal_Lenth1(double *y,int p1,int p2,int dim,int tau) //Calculate the distance between p1 and p2
{                                               //dim is the dimension of reconstruction,
 double Lenth=0.0;                           //tau is the the time delay in the reconstruction.
 for(int i=0;i<=dim-1;i++)
 {
  int t=i*tau;
  Lenth=Lenth+(y[p1+t]-y[p2+t])*(y[p1+t]-y[p2+t]);
 }
 return Lenth=sqrt(Lenth);
}
//***********************************************************************************************

 int Len;
double **xn;
double **x1n;
double **x2n;

void FNN_Multi(double *pdata_1,double *pdata_2,int N_pdata,int tau,int tau2,int d_max,int *Dim_FNN)
{
  double **xn_d;
  double *xn_d1;
  double *xn_d2;
  int *ref;
  int *Count_FNN_1;
  double *R_D; //所对应的临近点对之间的距离
  double *R_D_1;
  double *R_D_2;
  double *dis_d1;
  double *dis_d2;
  double *e;
  double *E;
  double *E1;
  double **Em;
  int *index;// ref 所对应的临近点
  int N;
  N=N_pdata;
  int mx_1;
  int my_1;
  int count_fnn;
  double Temp_E;
  int ref_0;
  int index_0;

  Count_FNN_1=new int[d_max-1];
  E=new double[d_max-1];
  Em=new double*[d_max-1];

  for(int j=2;j<(d_max+1);j++)
   {
     count_fnn=0;
     Temp_E=0;

     Em[j-2]=new double[j-1];


     for(mx_1=1;mx_1<j;mx_1++)
     {
      my_1=j-mx_1;
      PhaSpaRecon2(pdata_1,pdata_2,xn,N,tau,tau2,mx_1,my_1);
      ref=new int[Len];
      index=new int[Len];
      dis_d1=new double[Len];
      dis_d2=new double[Len];
      R_D=new double[Len];
      R_D_1=new double[Len];
      R_D_2=new double[Len];
      xn_d=new double*[j];
      xn_d1=new double[Len];
      xn_d2=new double[Len];
      e=new double[Len];


      for (int k=0;k<j;k++)
       {
        xn_d[k]=new double[Len];
       }
    // xn_d 赋值
      for(int ii=0;ii<Len;ii++)
       {
         for(int jj=0;jj<j;jj++)
          {
           xn_d[jj][ii]=xn[ii][jj];
          }
       }

      for(int ii=0;ii<Len;ii++)
       {

         xn_d1[ii]=pdata_1[ii+mx_1*tau];
         xn_d2[ii]=pdata_2[ii+my_1*tau];
       }

// Search the nearest neighbors in d dimension. return index and R_D
//void SearchNN(double** dataPts,int *ref1,int nPts,int *index1,double *R_D,int dim);
//***
       SearchNN(xn_d,ref,Len,index,R_D,j); //R_D is near neighbor distances
//***************************************************************************************
  // ref and index corresponding to a pair of nearest point: index_pair=[ref,index]
  // compute distance between index_pair points after increase dimension from (d) to (d+1)


    for(int ii=0;ii<Len;ii++)
    {
        ref_0=ii;  // Reference Points
        index_0=index[ii]; // Nearest Neighbor Points corresponding to Reference Points
        dis_d1[ii]=fabs(xn_d1[ref_0]-xn_d1[index_0]);
        dis_d2[ii]=fabs(xn_d2[ref_0]-xn_d2[index_0]);
        R_D_1[ii]=sqrt(R_D[ii]*R_D[ii]+dis_d1[ii]*dis_d1[ii]);
        R_D_2[ii]=sqrt(R_D[ii]*R_D[ii]+dis_d2[ii]*dis_d2[ii]);
        e[ii]=(R_D_1[ii]+R_D_2[ii])/(2.0*R_D[ii]);
    }

    for(int ii=0;ii<Len;ii++)
    {
       Temp_E=Temp_E+e[ii];
    }
     Em[j-2][count_fnn]=Temp_E/Len;
     count_fnn++;
// Free the variable
      delete[] index;
      delete[] dis_d1;
      delete[] dis_d2;
      delete[] R_D;
      delete[] R_D_1;
      delete[] R_D_2;
      delete[] xn_d;
      delete[] xn_d1;
      delete[] xn_d2;
      delete[] e;
      e=NULL;

      // free xn
      for(int k=0;k<Len;k++)
       {
         delete[] xn[k];
         xn[k]=NULL;
       }
         delete[] xn;
         xn=NULL;
     } // small cycle

      Temp_E=0;
     for(int ii=0;ii<count_fnn;ii++)
     {
       Temp_E=Temp_E+Em[j-2][ii];
     }
     E[j-2]=Temp_E/count_fnn;
     Count_FNN_1[j-2]=count_fnn;

  }//??????end the FNN_Multi_Big_Cycle

    E1=new double[d_max-2];
    for(int ii=0;ii<d_max-2;ii++)
     {
         E1[ii]=E[ii+1]/E[ii];
         cout<<"The d_max is :"<<d_max<<endl;
         cout<<"The E1("<<ii<<") is : "<<E1[ii]<<endl;
     }

   double Results_Temp;
   int Embed;
    for(int ii=0;ii<d_max-2;ii++)
    {
         if((E1[ii+1]-E1[ii])<1e-3) // if E1[ii+1] no increase, then the dimension is ii+1+2=ii+3;
         {
             Results_Temp=Em[ii+1][0];
             Embed=1;
            for(int jj=1;jj<Count_FNN_1[ii+1];jj++)
            {
                if(Em[ii+1][jj]<Results_Temp)
                {
                   Results_Temp=Em[ii+1][jj];
                   Embed=jj+1;
                }

            }
             Dim_FNN[0]=Embed;
             Dim_FNN[1]=ii+3-Embed;
              break;
         }
    }
}





void FNN(double *pdata,int N_pdata,int tau,int d_max,double R_tol,double A_tol,int *Dim_FNN,int DOS)
{
  double * Percent; // Satisfy those two criterion
  double * Percent1; // Only satisfy with test1
  double * Percent2; // Only satisfy with test2
  double **xn_d;
  double *xn_d1;
  int *ref;
  double *dis_d1;
  int *index;// ref 所对应的临近点
  double *R_D; //所对应的临近点对之间的距离
  double *R_D_1;
  int ref_0;
  int index_0;
  int fnn_num=0;
  int fnn_num_1=0;
  int fnn_num_2=0;
  double test1;
  double test2;
  int choose;
  int N;
   N=N_pdata;
double R_A=STD(pdata,N);

 if(DOS==0)
  {
  //printf("Choose which search algorithm: 0-- Search ANN 1--Rough Algorithm  ");
  //cin>>choose;
    choose=0;
  }
else if(DOS==1)
   {choose=0;}
  cout<<"Using How Long Data to compute Embedding Dimension   "<<N<<endl;
  Percent=new double[d_max];
  Percent1=new double[d_max];
  Percent2=new double[d_max];

  /*
   xn=new double*[d_max];
    for (int k=0;k<d_max;k++)
    {
       xn[k]=new double[Len];
    }
 */

//**************************************************************************************************
  PhaSpaRecon(pdata,xn,N,tau,d_max); // A is the PhaSpaRecon return, record the reconstruct points;
//**************************************************************************************************
     ref=new int[Len];


  // Follows is False NN

  for(int j=1;j<(d_max);j++)
  {

     index=new int[Len];
     dis_d1=new double[Len];
     R_D=new double[Len];
     R_D_1=new double[Len];
     xn_d1=new double[Len];
     xn_d=new double*[j];
    for (int k=0;k<j;k++)
    {
       xn_d[k]=new double[Len];
    }
    // xn_d 赋值
   for(int ii=0;ii<Len;ii++)
  {
     for(int jj=0;jj<j;jj++)
     {
         xn_d[jj][ii]=xn[jj][ii];
     }
  }

// Search the nearest neighbors in d dimension. return index and R_D
//void SearchNN(double** dataPts,int *ref1,int nPts,int *index1,double *R_D1,int dim);
//************************************************************************************
   if (choose==0) // using ANN Lib
    {SearchNN(xn_d,ref,Len,index,R_D,j);}
   else if(choose==1) // Using rough algorithm--grant
    {
vector<vector<double> > Distance_sort;
vector<vector<int> > Distance_index;
vector<vector<double> > Distance_sort_tmp;
vector<vector<int> > Distance_index_tmp;
double distance;
double max_d=0;
double min_d=1.0e+100;


node1 *r=(node1 *)malloc(Len*sizeof(node1));
Distance_sort.resize(Len);
Distance_index.resize(Len);
Distance_sort_tmp.resize(Len);
Distance_index_tmp.resize(Len);
for (int k=0;k<Len;k++)
{
   Distance_sort[k].resize(Len);
   Distance_index[k].resize(Len);
   Distance_sort_tmp[k].resize(Len);
   Distance_index_tmp[k].resize(Len);
}


for (int p1=0;p1<(Len-1);p1++)
{  for ( int p2=p1+1;p2<Len;p2++)
  {
     distance=Cal_Lenth1(pdata,p1,p2,j,tau);
  //cout<<"distance="<<distance<<endl;
    if (max_d<distance){max_d=distance;}
    if (min_d>distance){min_d=distance;}

    Distance_sort_tmp[p1][p2]=distance;
    Distance_sort_tmp[p2][p1]=distance;
  }
  Distance_sort_tmp[p1][p1]=0;
}

 for (int pp=0;pp<Len;pp++)
{
for (int p=0;p<Len;p++)
    {
      r[p].num=Distance_sort_tmp[pp][p];
      r[p].index=p;
    }
   sort(r,r+Len,cmp);
}
  for (int l=0;l<Len;l++)
    {
     index[l]=r[l].num;
     R_D[l]=r[l].index;
    }
//*********************************************************
}

    //xn_d1 赋值
    for(int ii=0;ii<Len;ii++)
    {
        xn_d1[ii]=xn[j][ii];
    }

//***************************************************************************************
  //test

  /*
   double distance_min=10000;
   double distance_tmp;
   int distance_min_index;

   for (int ii=1;ii<Len;ii++)
    {
      distance_tmp=0;
    for(int ij=0;ij<j;ij++)
      {
         distance_tmp+=(xn[ij][ii]-xn[ij][0])*(xn[ij][ii]-xn[ij][0]);
         distance_tmp=sqrt(distance_tmp);
         if(distance_tmp<distance_min)
          {distance_min=distance_tmp;distance_min_index=ii;}
      }
    }
  */
//***************************************************************************************

  // ref and index corresponding to a pair of nearest point: index_pair=[ref,index]
  // compute distance between index_pair points after increase dimension from (d) to (d+1)
    for(int ii=0;ii<Len;ii++)
    {
        ref_0=ii;  // Reference Points
        index_0=index[ii]; // Nearest Neighbor Points corresponding to Reference Points
        dis_d1[ii]=fabs(xn_d1[ref_0]-xn_d1[index_0]);
        R_D_1[ii]=sqrt(R_D[ii]*R_D[ii]+dis_d1[ii]*dis_d1[ii]);
    }
 //test1 using to determin how many false nearest neighbors.
// test1>R_tol;
   for (int ii=0;ii<Len;ii++)
    {
        test1=dis_d1[ii]/R_D[ii];
        test2=R_D_1[ii]/R_A;
        if(test1>R_tol || test2>A_tol)
        {
            fnn_num++;
        }
        if(test1>R_tol)
        {
            fnn_num_1++;
        }
        if(test2>A_tol)
       {
           fnn_num_2++;
       }
    }

// Record Percent
    Percent[j-1]=(double)fnn_num/(double)Len;
    Percent1[j-1]=(double)fnn_num_1/(double)Len;
    Percent2[j-1]=(double)fnn_num_2/(double)Len;

 // reset fnn_num, fnn_num_1, fnn_num_2 to initial situation;
 fnn_num=0;
 fnn_num_1=0;
 fnn_num_2=0;
//release space
  for(int k=0;k<j;k++)
    {
    delete[] xn_d[k];
    xn_d[k]=NULL;
    }
    delete[] xn_d;
    xn_d=NULL;


  delete[] xn_d1;
  xn_d1=NULL;

  delete[] index;
  index=NULL;

  delete[] R_D;
  R_D=NULL;

  delete [] dis_d1;
  dis_d1=NULL;

  delete [] R_D_1;
  R_D_1=NULL;

//
  }
  // Obtain Embedding Dimension: Percnet>5%



cout<<"The Threshold for FNN is: "<<FNN_Threshold<<endl;
 for(int j=0;j<d_max;j++)
 {
    cout<<"The FNN Percents are: "<<Percent[j]<<endl;
  }

 for(int j=0;j<d_max;j++)
 {
     if (Percent[j]<FNN_Threshold) // The threshold is 0.008% of false nearest neighbors0.00008
      {
           Dim_FNN[0]=j+1;// because some times couldn't obtain exact dimension, the attractor is fold, so
                          // increase the dimension when percent reached condition. 1) Dim_FNN[0]=j+1 or 2)Dim_FNN[0]=j+2

           break;
      }
 }

  delete [] Percent;
  Percent=NULL;
  delete [] Percent1;
  Percent1=NULL;
  delete [] Percent2;
  Percent2=NULL;

  delete [] ref;
  ref=NULL;
// free xn
for(int k=0;k<d_max;k++)
{
    delete[] xn[k];
    xn[k]=NULL;
}
delete[] xn;
xn=NULL;
//
}


// STD--计算方差
double STD(double *x,int n)
{
    int i;
    double sum=0,s=0,ave;
    for(i=0;i<n;i++)
    {
        sum+=x[i];
    }
    ave=sum/n;
    for(i=0;i<n;i++)
    {s+=pow(x[i]-ave,2);}
    s=s/(double)n;
    return sqrt(s);
}

//Phase Space Reconstrute
void PhaSpaRecon(double *x,double ** &xn, int n ,int tau,int max_Dim)
{
    Len=n-(max_Dim-1)*tau;

    //double **A;
    xn=new double*[max_Dim];
    for (int j=0;j<max_Dim;j++)
    {
        xn[j]=new double[Len];
    }

   if(Len<1)
   {
        cout<<"err: delay time or the embedding dimension is too large! "<<endl;
   }
else
{
  for( int j=0;j<Len;j++)
  {
      for (int k=0;k<max_Dim;k++)
      {
          xn[k][j]=x[j+k*tau];
      }
  }
 }
}

void PhaSpaRecon2(double *x,double *x2,double ** &xn, int n ,int tau,int tau2,int mx_1,int my_1)
{
    int m_z;
    int Len0;
    int Len1;
    m_z=mx_1+my_1;
    Len0=n-(mx_1-1)*tau;
    Len1=n-(my_1-1)*tau2;
    if(Len0<Len1)
    {
        Len=Len0;
    }
    else
    {
        Len=Len1;
    }

    //double **A;
    xn=new double*[Len];

    for (int j=0;j<Len;j++)
    {
        xn[j]=new double[m_z];
    }

   if(Len<1)
   {
        cout<<"err: delay time or the embedding dimension is too large! "<<endl;
   }
else
{
  for( int j=0;j<Len;j++)
  {
      for (int k=0;k<mx_1;k++)
      {
        xn[j][k]=x[j+k*tau];
      }
     for (int k=0;k<my_1;k++)
      {
        xn[j][mx_1+k]=x2[j+k*tau2];
      }
  }
 }
}
