#ifndef _POISSON_INPUT_H_
#define _POISSON_INPUT_H_

// this is used for non-smooth conductance case, it describes the jump of
// conductanc G by the external Poisson spiketrain
void force_input(neuron *tempneu, int index_neuron);

// same as the above but for smoothed conductance case, it describes the jum
// of H by the external Poisson spike train
void force_inputR(neuron *tempneu, int index_neuron);

// this is used for non-smooth conductance case, it describes the evolution of
// conductance between two adjacedt cortical spikes
void conductance_decay(neuron *tempneu, int index_neuron, double subTstep);

// same as the above but for smoothed conductance case
void conductance_evolve(neuron *tempneu, int index_neuron, double subTstep);

// this is the Runge-Kutta algorithmn with RK4
void runge_kutta4(neuron *tempneu, int index_neuron, double subTstep,double t_evolution,vector<double> Omega,vector<double> &y,
		  void (*voltage_p_dt)(double t,vector<double> y,double gE, double gI,double &dv_dt),
	          void (*m_p_dt)(double t,double y_0, double y_1, double &dm_dt),
	          void (*h_p_dt)(double t,double y_0, double y_2, double &dh_dt),
	          void (*n_p_dt)(double t,double y_0, double y_3,double &dn_dt),
                  void (*q_p_dt)(double t,double Omega, double &dq_dt));
void runge_kutta4(neuron *tempneu, int index_neuron, double subTstep,double t_evolution,vector<double> Omega,vector<double> &y,
		  void (*voltage_p_non_dt)(double t,vector<double> y,double Omega_1,double gE, double gI,double &dv_dt),
	          void (*m_p_dt)(double t,double y_0, double y_1, double &dm_dt),
	          void (*h_p_dt)(double t,double y_0, double y_2, double &dh_dt),
	          void (*n_p_dt)(double t,double y_0, double y_3,double &dn_dt));
void runge_kutta4_whole(neuron *tempneu, int index_neuron, double subTstep,double t_evolution,vector<double> Omega,vector<double> &y,
		  void (*voltage_p_dt)(double t,vector<double> y,double gE, double gI,double &dv_dt),
	          void (*m_p_dt)(double t,double y_0, double y_1, double &dm_dt),
	          void (*h_p_dt)(double t,double y_0, double y_2, double &dh_dt),
	          void (*n_p_dt)(double t,double y_0, double y_3,double &dn_dt),
                  void (*q_p_dt)(double t,double Omega, double &dq_dt));
void runge_kutta4_whole(neuron *tempneu, int index_neuron, double subTstep,double t_evolution,vector<double> Omega,vector<double> &y,
		  void (*voltage_p_non_dt)(double t,vector<double> y,double Omega_1,double gE, double gI,double &dv_dt),
	          void (*m_p_dt)(double t,double y_0, double y_1, double &dm_dt),
	          void (*h_p_dt)(double t,double y_0, double y_2, double &dh_dt),
	          void (*n_p_dt)(double t,double y_0, double y_3,double &dn_dt));

void single_neuron_test(neuron *tempneu,int index_neuron,double begin_time,vector<double> Omega,vector<double> &y,
                             double end_time,int *begin_poisson_index);

void single_neuron_test_whole(neuron *tempneu,int index_neuron,double begin_time,vector<double> Omega,vector<double> &y,
                             double end_time,int *begin_poisson_index);

void Neuron_Solution(int N,double h,double begin_time,vector<double> Omega,vector<vector<double> >&y,vector<double> y_0);

void Neuron_Solution_whole(int N,double h,double begin_time,vector<double> Omega,vector<vector<double> >&y,vector<double> y_0);

void Neuron_Solution_ISIjin(int N,double h,double begin_time,vector<double> Omega,vector<vector<double> >&y,vector<double> y_0,int Flage);
#endif
