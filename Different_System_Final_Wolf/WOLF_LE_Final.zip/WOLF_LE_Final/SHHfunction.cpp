#include <cstdlib>
#include <vector>
#include <string>
#include <iostream>
#include<cmath>
#include<iomanip>
#include"HHconst.h"
#include"SHHfunction.h"

using namespace std;

    double v1;
	double alphan1,betan1,alpham1,betam1,alphah1,betah1;
/* void SHHF(int t,vector<double> y,double Omega,double amp1,double &dv_dt,double &dm_dt,double &dh_dt,double &dn_dt,double &dq_dt)
{
	double v;
	double alphan,betan,alpham,betam,alphah,betah;

	v=y[1]-e_vr;

	//n channel
	alphan=0.01*(10-v)/(exp((10-v)/10)-1);
	betan=0.125*exp(-v/80);

	//m channel
	alpham=0.1*(25-v)/(exp((25-v)/10)-1);
	betam=0.125*exp(-v/18);

	//h channel
	alphah=0.07*exp(-v/20);
	betah=1/(exp((30-v)/10)+1);
	// Five ODE
	dv_dt=(amp1+y[5])-(g_na_max*(pow(y[2],3))*y[3]*(y[1]-115) + g_k_max*(pow(y[4],4))*(y[1]+12) + g_l*(-10.6+y[1])); 
    dm_dt=(alpham-(alpham+betam)*y[2]);
    dh_dt=(alphah-(alphah+betah)*y[3]);
    dn_dt=(alphan-(alphan+betan)*y[4]);
    dq_dt=2*pi*Omega*cos(2*pi*Omega*t);
} */
	
void voltage_dt(double t,vector<double> y,double &dv_dt)
{
	//cout<<setprecision(16)<<y[4]<<endl;
	
	//system("pause");
	//cout<<"after fmod "<<y[4]<<endl;
dv_dt=(amp1+sin(2*pi*y[4]))-(g_na_max*(pow(y[1],3))*y[2]*(y[0]-115) + g_k_max*(pow(y[3],4))*(y[0]+12) + g_l*(-10.6+y[0])); 
}

void m_dt(double t,double y_0, double y_1, double &dm_dt)
{
	v1=y_0;
	//m channel
        alpham1=0.1*(25-v1)/(exp((25-v1)/10)-1);
	      
	betam1=4*exp(-v1/18);
	dm_dt=(alpham1-(alpham1+betam1)*y_1);
}

void h_dt(double t,double y_0, double y_2, double &dh_dt)
{
	v1=y_0;
	//h channel
	alphah1=0.07*exp(-v1/20);
	betah1=1/(exp((30-v1)/10)+1);

	dh_dt=(alphah1-(alphah1+betah1)*y_2);
}

void n_dt(double t,double y_0, double y_3,double &dn_dt)
	{
	v1=y_0;
	//n channel
	alphan1=0.01*(10-v1)/(exp((10-v1)/10)-1);
	
	betan1=0.125*exp(-v1/80);
	dn_dt=(alphan1-(alphan1+betan1)*y_3);

	}

void qq_dt(double t,double Omega, double &dqq_dt)
	{   
		dqq_dt=Omega;
	}
