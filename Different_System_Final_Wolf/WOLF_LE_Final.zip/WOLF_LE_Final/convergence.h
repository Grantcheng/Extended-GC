#ifndef _convergence_H_
#define _convergence_H_
#include <iostream>
#include <vector>
#include <string>
using namespace std;

void Convergence_2(vector<double> y_0,vector<double> Omega,double Tstart,double N_0,double h_0,vector<double> &y_convergence,
	double &T0_convergence,	vector<vector<double> >Couple,vector<double> amp,double Time);

void Convergence_1(vector<double> y_0,vector<double> Omega,double Tstart,double N_0,double h_0,vector<double> &y_convergence,
	double &T0_convergence,double Time);

void Convergence_P(vector<double> y_0,vector<double> Omega,double Tstart,double N_0,double h_0,vector<double> &y_convergence,
	double &T0_convergence,double Time);

void Convergence_Sci(vector<double> y_0,double Tstart,int N_0,double h_0,int Flage_sci_flat_white,vector<double> &y_convergence,
	double &T0_convergence,double Time) ;
#endif
