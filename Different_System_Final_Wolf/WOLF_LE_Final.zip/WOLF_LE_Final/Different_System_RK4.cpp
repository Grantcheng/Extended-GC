#include<iostream>
#include<math.h>
#include<cmath>
#include<iomanip>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include "HHconst.h"
#include "WhiteNoise.h"
#include "Convolutional.h"
//#include "Different_System_Const.h"
using namespace std;

void System_Duffing_RK4(vector<double> y0,vector<double> Omega,double t0,int iter,double h,double alpha,double beta,double gamma,double force,
        vector<vector<double> >  &y,vector<double>  &t,
        void (*x_dt)(double t,double y_2,double &dx_dt),
	void (*y_dt)(double t,double y_2, double y_1, double y_3,double alpha,double beta,double gamma,double force,double &dy_dt),
	void (*dqdt)(double t,double Omega, double &dq_dt))
{
	vector<double>  temp(3);
	vector<double>  k1(3);
	vector<double>  k2(3);
	vector<double>  k3(3);
	vector<double>  k4(3);
	double m11, m21, m31, m41;
	double m12, m22, m32, m42;
	double m13, m23, m33, m43;

	t.resize(iter+1);
	y.resize(iter+1);
	t[0]=t0;
	for (int j=1;j<iter+1;j++)
		{
			y[j].resize(3);// five solutions:v,m,n,h,q
		}

	y[0]=y0;// input the initial values y0 to the y

		for (int i=0; i<iter; i++)
		{
			if (y[i][2]>2*pi)
			y[i][2]=fmod(y[i][2],2*pi);
			// k1 = f(t(n), y(n))
			//(*x_dt)(double t,double y_2,double &dx_dt)
			(*x_dt)(t[i],y[i][1],m11);
			//(*y_dt)(double t,double y_2, double y_1, double alpha,double beta,double gamma,double force,double &dy_dt)
			(*y_dt)(t[i],y[i][1],y[i][0],y[i][2],alpha,beta,gamma,force,m12);
			//(*dqdt)(double t,double Omega, double &dq_dt)
	                (*dqdt)(t[i],Omega[0], m13);
			//assign the m11,m12,m13 to k1
			k1[0]=m11;
			k1[1]=m12;
			k1[2]=m13;


			// k2 = f(t(n)+h/2, y(n)+k1*h/2)


			temp[0]=0.5*h*k1[0]+y[i][0];
			temp[1]=0.5*h*k1[1]+y[i][1];
			temp[2]=0.5*h*k1[2]+y[i][2];

                        (*x_dt)((t[i]+0.5*h),temp[1],m21);
			(*y_dt)((t[i]+0.5*h),temp[1],temp[0],temp[2],alpha,beta,gamma,force,m22);
	                (*dqdt)((t[i]+0.5*h),Omega[0], m23);
			k2[0]=m21;
			k2[1]=m22;
			k2[2]=m23;

			// k3 = f(t(n)+h/2, y(n)+k2*h/2)
			temp[0]=0.5*h*k2[0]+y[i][0];
			temp[1]=0.5*h*k2[1]+y[i][1];
			temp[2]=0.5*h*k2[2]+y[i][2];

			(*x_dt)((t[i]+0.5*h),temp[1],m31);
			(*y_dt)((t[i]+0.5*h),temp[1],temp[0],temp[2],alpha,beta,gamma,force,m32);
	                (*dqdt)((t[i]+0.5*h),Omega[0], m33);
			k3[0]=m31;
			k3[1]=m32;
			k3[2]=m33;

			// k4 = f(t(n)+h, y(n)+k3*h)

			temp[0]=h*k3[0]+y[i][0];
			temp[1]=h*k3[1]+y[i][1];
			temp[2]=h*k3[2]+y[i][2];

			(*x_dt)((t[i]+h),temp[1],m41);
			(*y_dt)((t[i]+h),temp[1],temp[0],temp[2],alpha,beta,gamma,force,m42);
	                (*dqdt)((t[i]+h),Omega[0], m43);
			k4[0]=m41;
			k4[1]=m42;
			k4[2]=m43;
			//The solution value

			//y[i+1].push_back(y[i][0]+(h/6)*(k1[0]+2*k2[0]+2*k3[0]+k4[0]));
			//y[i+1].push_back(y[i][1]+(h/6)*(k1[1]+2*k2[1]+2*k3[1]+k4[1]));
			//y[i+1].push_back(y[i][2]+(h/6)*(k1[2]+2*k2[2]+2*k3[2]+k4[2]));
			//y[i+1].push_back(y[i][3]+(h/6)*(k1[3]+2*k2[3]+2*k3[3]+k4[3]));
			//y[i+1].push_back(y[i][4]+(h/6)*(k1[4]+2*k2[4]+2*k3[4]+k4[4]));

			y[i+1][0]=y[i][0]+(h/6)*(k1[0]+2*k2[0]+2*k3[0]+k4[0]);
			y[i+1][1]=y[i][1]+(h/6)*(k1[1]+2*k2[1]+2*k3[1]+k4[1]);
			y[i+1][2]=y[i][2]+(h/6)*(k1[2]+2*k2[2]+2*k3[2]+k4[2]);

			//updata t
            t[i+1]=t[i]+h;
		}
}



void System_Lorenz_RK4(vector<double> y0,vector<double> Omega,double t0,int iter,double h,vector<vector<double> >  &y,vector<double>  &t,
        void (*Lx_dt)(double t, vector<double> Ly, double &dx_dt),
	void (*Ly_dt)(double t, vector <double> Ly,double &dy_dt),
	void (*Lz_dt)(double t, vector<double> Ly, double &dz_dt))
{
	vector<double>  temp(3);
	vector<double>  k1(3);
	vector<double>  k2(3);
	vector<double>  k3(3);
	vector<double>  k4(3);
	double m11, m21, m31, m41;
	double m12, m22, m32, m42;
	double m13, m23, m33, m43;

	t.resize(iter+1);
	y.resize(iter+1);
	t[0]=t0;
	for (int j=1;j<iter+1;j++)
		{
			y[j].resize(3);// five solutions:v,m,n,h,q
		}

	y[0]=y0;// input the initial values y0 to the y

		for (int i=0; i<iter; i++)
		{

			// k1 = f(t(n), y(n))
			//(*x_dt)(double t,double y_2,double &dx_dt)
			(*Lx_dt)(t[i],y[i],m11);
			//(*y_dt)(double t,double y_2, double y_1, double alpha,double beta,double gamma,double force,double &dy_dt)
			(*Ly_dt)(t[i],y[i],m12);
			//(*dqdt)(double t,double Omega, double &dq_dt)
	                (*Lz_dt)(t[i],y[i],m13);
			//assign the m11,m12,m13 to k1
			k1[0]=m11;
			k1[1]=m12;
			k1[2]=m13;


			// k2 = f(t(n)+h/2, y(n)+k1*h/2)


			temp[0]=0.5*h*k1[0]+y[i][0];
			temp[1]=0.5*h*k1[1]+y[i][1];
			temp[2]=0.5*h*k1[2]+y[i][2];

                        (*Lx_dt)((t[i]+0.5*h),temp,m21);
			(*Ly_dt)((t[i]+0.5*h),temp,m22);
	                (*Lz_dt)((t[i]+0.5*h),temp,m23);
			k2[0]=m21;
			k2[1]=m22;
			k2[2]=m23;

			// k3 = f(t(n)+h/2, y(n)+k2*h/2)
			temp[0]=0.5*h*k2[0]+y[i][0];
			temp[1]=0.5*h*k2[1]+y[i][1];
			temp[2]=0.5*h*k2[2]+y[i][2];

			(*Lx_dt)((t[i]+0.5*h),temp,m31);
			(*Ly_dt)((t[i]+0.5*h),temp,m32);
	                (*Lz_dt)((t[i]+0.5*h),temp,m33);
			k3[0]=m31;
			k3[1]=m32;
			k3[2]=m33;

			// k4 = f(t(n)+h, y(n)+k3*h)

			temp[0]=h*k3[0]+y[i][0];
			temp[1]=h*k3[1]+y[i][1];
			temp[2]=h*k3[2]+y[i][2];

			(*Lx_dt)((t[i]+h),temp,m41);
			(*Ly_dt)((t[i]+h),temp,m42);
	                (*Lz_dt)((t[i]+h),temp,m43);
			k4[0]=m41;
			k4[1]=m42;
			k4[2]=m43;
			//The solution value

			//y[i+1].push_back(y[i][0]+(h/6)*(k1[0]+2*k2[0]+2*k3[0]+k4[0]));
			//y[i+1].push_back(y[i][1]+(h/6)*(k1[1]+2*k2[1]+2*k3[1]+k4[1]));
			//y[i+1].push_back(y[i][2]+(h/6)*(k1[2]+2*k2[2]+2*k3[2]+k4[2]));
			//y[i+1].push_back(y[i][3]+(h/6)*(k1[3]+2*k2[3]+2*k3[3]+k4[3]));
			//y[i+1].push_back(y[i][4]+(h/6)*(k1[4]+2*k2[4]+2*k3[4]+k4[4]));

			y[i+1][0]=y[i][0]+(h/6)*(k1[0]+2*k2[0]+2*k3[0]+k4[0]);
			y[i+1][1]=y[i][1]+(h/6)*(k1[1]+2*k2[1]+2*k3[1]+k4[1]);
			y[i+1][2]=y[i][2]+(h/6)*(k1[2]+2*k2[2]+2*k3[2]+k4[2]);

			//updata t
            t[i+1]=t[i]+h;
		}
}


void System_Rossler_RK4(vector<double> y0,vector<double> Omega,double t0,int iter,double h,vector<vector<double> >  &y,vector<double>  &t,
        void (*Rx_dt)(double t, vector<double> Ly, double &dx_dt),
	void (*Ry_dt)(double t, vector <double> Ly,double &dy_dt),
	void (*Rz_dt)(double t, vector<double> Ly, double &dz_dt))
{
	vector<double>  temp(3);
	vector<double>  k1(3);
	vector<double>  k2(3);
	vector<double>  k3(3);
	vector<double>  k4(3);
	double m11, m21, m31, m41;
	double m12, m22, m32, m42;
	double m13, m23, m33, m43;

	t.resize(iter+1);
	y.resize(iter+1);
	t[0]=t0;
	for (int j=1;j<iter+1;j++)
		{
			y[j].resize(3);// five solutions:v,m,n,h,q
		}

	y[0]=y0;// input the initial values y0 to the y

		for (int i=0; i<iter; i++)
		{

			// k1 = f(t(n), y(n))
			//(*x_dt)(double t,double y_2,double &dx_dt)
			(*Rx_dt)(t[i],y[i],m11);
			//(*y_dt)(double t,double y_2, double y_1, double alpha,double beta,double gamma,double force,double &dy_dt)
			(*Ry_dt)(t[i],y[i],m12);
			//(*dqdt)(double t,double Omega, double &dq_dt)
	                (*Rz_dt)(t[i],y[i],m13);
			//assign the m11,m12,m13 to k1
			k1[0]=m11;
			k1[1]=m12;
			k1[2]=m13;


			// k2 = f(t(n)+h/2, y(n)+k1*h/2)


			temp[0]=0.5*h*k1[0]+y[i][0];
			temp[1]=0.5*h*k1[1]+y[i][1];
			temp[2]=0.5*h*k1[2]+y[i][2];

                        (*Rx_dt)((t[i]+0.5*h),temp,m21);
			(*Ry_dt)((t[i]+0.5*h),temp,m22);
	                (*Rz_dt)((t[i]+0.5*h),temp,m23);
			k2[0]=m21;
			k2[1]=m22;
			k2[2]=m23;

			// k3 = f(t(n)+h/2, y(n)+k2*h/2)
			temp[0]=0.5*h*k2[0]+y[i][0];
			temp[1]=0.5*h*k2[1]+y[i][1];
			temp[2]=0.5*h*k2[2]+y[i][2];

			(*Rx_dt)((t[i]+0.5*h),temp,m31);
			(*Ry_dt)((t[i]+0.5*h),temp,m32);
	                (*Rz_dt)((t[i]+0.5*h),temp,m33);
			k3[0]=m31;
			k3[1]=m32;
			k3[2]=m33;

			// k4 = f(t(n)+h, y(n)+k3*h)

			temp[0]=h*k3[0]+y[i][0];
			temp[1]=h*k3[1]+y[i][1];
			temp[2]=h*k3[2]+y[i][2];

			(*Rx_dt)((t[i]+h),temp,m41);
			(*Ry_dt)((t[i]+h),temp,m42);
	                (*Rz_dt)((t[i]+h),temp,m43);
			k4[0]=m41;
			k4[1]=m42;
			k4[2]=m43;
			//The solution value

			//y[i+1].push_back(y[i][0]+(h/6)*(k1[0]+2*k2[0]+2*k3[0]+k4[0]));
			//y[i+1].push_back(y[i][1]+(h/6)*(k1[1]+2*k2[1]+2*k3[1]+k4[1]));
			//y[i+1].push_back(y[i][2]+(h/6)*(k1[2]+2*k2[2]+2*k3[2]+k4[2]));
			//y[i+1].push_back(y[i][3]+(h/6)*(k1[3]+2*k2[3]+2*k3[3]+k4[3]));
			//y[i+1].push_back(y[i][4]+(h/6)*(k1[4]+2*k2[4]+2*k3[4]+k4[4]));

			y[i+1][0]=y[i][0]+(h/6)*(k1[0]+2*k2[0]+2*k3[0]+k4[0]);
			y[i+1][1]=y[i][1]+(h/6)*(k1[1]+2*k2[1]+2*k3[1]+k4[1]);
			y[i+1][2]=y[i][2]+(h/6)*(k1[2]+2*k2[2]+2*k3[2]+k4[2]);

			//updata t
            t[i+1]=t[i]+h;
		}
}


void System_Morris_Lecar_RK4(vector<double> y0,vector<double> Omega,double t0,int iter,double h,vector<vector<double> >  &y,vector<double>  &t,
        void (*MLv_dt)(double t, vector<double> Ly,double Omega, double &dv_dt),
	void (*MLw_dt)(double t, vector <double> Ly,double Omega, double &dw_dt),
        void (*Mqq_dt)(double t,vector<double> ML_y,double Omega, double &Mqq_dt))
{
	vector<double>  temp(3);
	vector<double>  k1(3);
	vector<double>  k2(3);
	vector<double>  k3(3);
	vector<double>  k4(3);
	double m11, m21, m31, m41;
	double m12, m22, m32, m42;
	double m13, m23, m33, m43;

	t.resize(iter+1);
	y.resize(iter+1);
	t[0]=t0;
	for (int j=1;j<iter+1;j++)
		{
			y[j].resize(3);// five solutions:v,w,q
		}

	y[0]=y0;// input the initial values y0 to the y

		for (int i=0; i<iter; i++)
		{
			if (y[i][2]>1)
			y[i][2]=fmod(y[i][2],1);
			(*MLv_dt)(t[i],y[i],Omega[0],m11);
			(*MLw_dt)(t[i],y[i],Omega[0],m12);
			(*Mqq_dt)(t[i],y[i],Omega[0],m13);
			//assign the m11,m12,m13 to k1
			k1[0]=m11;
			k1[1]=m12;
			k1[2]=m13;


			// k2 = f(t(n)+h/2, y(n)+k1*h/2)


			temp[0]=0.5*h*k1[0]+y[i][0];
			temp[1]=0.5*h*k1[1]+y[i][1];
			temp[2]=0.5*h*k1[2]+y[i][2];

                        (*MLv_dt)((t[i]+0.5*h),temp,Omega[0],m21);
			(*MLw_dt)((t[i]+0.5*h),temp,Omega[0],m22);
	                (*Mqq_dt)((t[i]+0.5*h),y[i],Omega[0],m23);
			k2[0]=m21;
			k2[1]=m22;
			k2[2]=m23;

			// k3 = f(t(n)+h/2, y(n)+k2*h/2)
			temp[0]=0.5*h*k2[0]+y[i][0];
			temp[1]=0.5*h*k2[1]+y[i][1];
			temp[2]=0.5*h*k2[2]+y[i][2];

			(*MLv_dt)((t[i]+0.5*h),temp,Omega[0],m31);
			(*MLw_dt)((t[i]+0.5*h),temp,Omega[0],m32);
	                (*Mqq_dt)((t[i]+0.5*h),y[i],Omega[0],m33);
			k3[0]=m31;
			k3[1]=m32;
			k3[2]=m33;

			// k4 = f(t(n)+h, y(n)+k3*h)

			temp[0]=h*k3[0]+y[i][0];
			temp[1]=h*k3[1]+y[i][1];
			temp[2]=h*k3[2]+y[i][2];

			(*MLv_dt)((t[i]+h),temp,Omega[0],m41);
			(*MLw_dt)((t[i]+h),temp,Omega[0],m42);
	                (*Mqq_dt)((t[i]+h),y[i],Omega[0],m43);
			k4[0]=m41;
			k4[1]=m42;
			k4[2]=m43;
			//The solution value

			//y[i+1].push_back(y[i][0]+(h/6)*(k1[0]+2*k2[0]+2*k3[0]+k4[0]));
			//y[i+1].push_back(y[i][1]+(h/6)*(k1[1]+2*k2[1]+2*k3[1]+k4[1]));
			//y[i+1].push_back(y[i][2]+(h/6)*(k1[2]+2*k2[2]+2*k3[2]+k4[2]));
			//y[i+1].push_back(y[i][3]+(h/6)*(k1[3]+2*k2[3]+2*k3[3]+k4[3]));
			//y[i+1].push_back(y[i][4]+(h/6)*(k1[4]+2*k2[4]+2*k3[4]+k4[4]));

			y[i+1][0]=y[i][0]+(h/6)*(k1[0]+2*k2[0]+2*k3[0]+k4[0]);
			y[i+1][1]=y[i][1]+(h/6)*(k1[1]+2*k2[1]+2*k3[1]+k4[1]);
			y[i+1][2]=y[i][2]+(h/6)*(k1[2]+2*k2[2]+2*k3[2]+k4[2]);

			//updata t
            t[i+1]=t[i]+h;
		}
}



void MSystem_Morris_Lecar_RK4(vector<double> y0,vector<double> Omega,double t0,int iter,double h,vector<vector<double> >  &y,vector<double>  &t,
        vector<vector<double> >Couple,vector<double> amp,
        void (*MLv_mdt)(double t, vector<double> Ly, vector<double> amp,vector<double> Omega,vector<double>  &dv_dt),
	void (*MLw_mdt)(double t, vector <double> Ly,vector<double> Omega,vector<double>  &dw_dt),
        void (*MG1idt)(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt),
        void (*Mqq_mdt)(double t,vector<double> ML_y,vector<double> Omega, vector<double>  &Mqq_dt))
{

        int Dimension;
        Dimension=y0.size();
	vector<double>  temp(Dimension);
	vector<double>  k1(Dimension);
	vector<double>  k2(Dimension);
	vector<double>  k3(Dimension);
	vector<double>  k4(Dimension);
	vector<double> m11, m21, m31, m41;
	vector<double> m12, m22, m32, m42;
	vector<double> m13, m23, m33, m43;
	vector<double> m14, m24, m34, m44;
	m11.resize(NumNeuron);m21.resize(NumNeuron); m31.resize(NumNeuron); m41.resize(NumNeuron);
	m12.resize(NumNeuron);m22.resize(NumNeuron); m32.resize(NumNeuron); m42.resize(NumNeuron);
	m13.resize(NumNeuron);m23.resize(NumNeuron); m33.resize(NumNeuron); m43.resize(NumNeuron);
	m14.resize(NumNeuron);m24.resize(NumNeuron); m34.resize(NumNeuron); m44.resize(NumNeuron);

        t.resize(iter+1);
	y.resize(iter+1);// 7*NumNeuron solutions

	t[0]=t0;
	for (int j=1;j<iter+1;j++)
		{
			y[j].resize(Dimension);
		}

	y[0]=y0;// input the initial values y0 to the y

		for (int i=0; i<iter; i++)
		{
			for (int NumNeuronth=1;NumNeuronth<=NumNeuron;NumNeuronth++)
				{
					int y4=4*NumNeuronth-1;
					y[i][y4]=fmod(y[i][y4],1);
				}
			// k1 = f(t(n), y(n))
			(*MLv_mdt)(t[i],y[i],amp,Omega,m11);
			(*MLw_mdt)(t[i],y[i],Omega,m12);
	                (*MG1idt)(t[i],y[i],Couple,m13);
	                (*Mqq_mdt)(t[i],y[i],Omega, m14);

			//assign the m11,m12,m13,m14 to k1

				for(int j=0;j<NumNeuron;j++)
				{
					k1[4*j]=m11[j];
			    		k1[4*j+1]=m12[j];
			        	k1[4*j+2]=m13[j];
			        	k1[4*j+3]=m14[j];
				}


			// k2 = f(t(n)+h/2, y(n)+k1*h/2)

				for (int j=0;j<Dimension;j++)
				{

					temp[j]=0.5*h*k1[j]+y[i][j];
				}
				for (int NumNeuronth=1;NumNeuronth<=NumNeuron;NumNeuronth++)
					{
						int y4=4*NumNeuronth-1;
						temp[y4]=fmod(temp[y4],1);
					}
           	        (*MLv_mdt)((t[i]+0.5*h),temp,amp,Omega,m21);
			(*MLw_mdt)((t[i]+0.5*h),temp,Omega,m22);
			(*MG1idt)((t[i]+0.5*h),temp,Couple,m23);
	        	(*Mqq_mdt)((t[i]+0.5*h),y[i],Omega,m24);


			for(int j=0;j<NumNeuron;j++)
				{
					k2[4*j]=m21[j];
			        	k2[4*j+1]=m22[j];
			        	k2[4*j+2]=m23[j];
			        	k2[4*j+3]=m24[j];

				}


			// k3 = f(t(n)+h/2, y(n)+k2*h/2)

			for (int j=0;j<Dimension;j++)
				{

					temp[j]=0.5*h*k2[j]+y[i][j];
				}
			for (int NumNeuronth=1;NumNeuronth<=NumNeuron;NumNeuronth++)
					{
						int y4=4*NumNeuronth-1;
						temp[y4]=fmod(temp[y4],1);
					}
			(*MLv_mdt)((t[i]+0.5*h),temp,amp,Omega,m31);
			//(*dvdt)(double t,vector<double> y,vector<double> amp,vector<double> &dv_dt);
			(*MLw_mdt)((t[i]+0.5*h),temp,Omega,m32);
			//(*Gidt)(double t,vector<double> y,vector<double>  &Gi_dt)
	        	(*MG1idt)((t[i]+0.5*h),temp,Couple,m33);
			//(*G1idt)(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt)
	        	(*Mqq_mdt)((t[i]+0.5*h),y[i],Omega, m34);
			//(*qi_dt)(double t,vector<double> Omega,vector<double>  &dqi_dt)

			for(int j=0;j<NumNeuron;j++)
				{
			        k3[4*j]=m31[j];
			        k3[4*j+1]=m32[j];
			        k3[4*j+2]=m33[j];
			        k3[4*j+3]=m34[j];
				}

			for (int j=0;j<Dimension;j++)
				{

					temp[j]=h*k3[j]+y[i][j];
				}
			for (int NumNeuronth=1;NumNeuronth<=NumNeuron;NumNeuronth++)
					{
						int y4=4*NumNeuronth-1;
						temp[y4]=fmod(temp[y4],1);
					}
		    	(*MLv_mdt)((t[i]+h),temp,amp,Omega,m41);
			(*MLw_mdt)((t[i]+h),temp,Omega,m42);
			(*MG1idt)(t[i]+h,temp,Couple,m43);
	        	(*Mqq_mdt)((t[i]+h),y[i],Omega, m44);

			for(int j=0;j<NumNeuron;j++)
				{
					k4[4*j]=m41[j];
			        	k4[4*j+1]=m42[j];
			        	k4[4*j+2]=m43[j];
			        	k4[4*j+3]=m44[j];

				}

			//The solution value

			//y[i+1].push_back(y[i][0]+(h/6)*(k1[0]+2*k2[0]+2*k3[0]+k4[0]));
			//y[i+1].push_back(y[i][1]+(h/6)*(k1[1]+2*k2[1]+2*k3[1]+k4[1]));
			//y[i+1].push_back(y[i][2]+(h/6)*(k1[2]+2*k2[2]+2*k3[2]+k4[2]));
			//y[i+1].push_back(y[i][3]+(h/6)*(k1[3]+2*k2[3]+2*k3[3]+k4[3]));
			//y[i+1].push_back(y[i][4]+(h/6)*(k1[4]+2*k2[4]+2*k3[4]+k4[4]));

			for(int j=0;j<Dimension;j++)
			{
				y[i+1][j]=y[i][j]+(h/6)*(k1[j]+2*k2[j]+2*k3[j]+k4[j]);

			}
			//updata t
            t[i+1]=t[i]+h;
		}
}
//------------------------------------------------------------------------------------------------------------------------------------------------
void System_Fitzhugh_Nagumo_RK4(vector<double> y0,vector<double> Omega,double t0,int iter,double h,vector<vector<double> >  &y,vector<double>  &t,
        void (*FNv_dt)(double t, vector<double> FN_y, double &dv_dt),
	void (*FNw_dt)(double t, vector <double> FN_y,double &dw_dt),
        void (*Fqq_dt)(double t,double Omega, double &Fqq_dt))
{
	vector<double>  temp(3);
	vector<double>  k1(3);
	vector<double>  k2(3);
	vector<double>  k3(3);
	vector<double>  k4(3);
	double m11, m21, m31, m41;
	double m12, m22, m32, m42;
	double m13, m23, m33, m43;

	t.resize(iter+1);
	y.resize(iter+1);
	t[0]=t0;
	for (int j=1;j<iter+1;j++)
		{
			y[j].resize(3);// five solutions:v,w,q
		}

	y[0]=y0;// input the initial values y0 to the y

		for (int i=0; i<iter; i++)
		{
			if (y[i][2]>1)
			y[i][2]=fmod(y[i][2],1);
			// k1 = f(t(n), y(n))
			//(*x_dt)(double t,double y_2,double &dx_dt)
			(*FNv_dt)(t[i],y[i],m11);
			//(*y_dt)(double t,double y_2, double y_1, double alpha,double beta,double gamma,double force,double &dy_dt)
			(*FNw_dt)(t[i],y[i],m12);
			//(*dqdt)(double t,double Omega, double &dq_dt)
	                (*Fqq_dt)(t[i],Omega[0],m13);
			//assign the m11,m12,m13 to k1
			k1[0]=m11;
			k1[1]=m12;
			k1[2]=m13;


			// k2 = f(t(n)+h/2, y(n)+k1*h/2)


			temp[0]=0.5*h*k1[0]+y[i][0];
			temp[1]=0.5*h*k1[1]+y[i][1];
			temp[2]=0.5*h*k1[2]+y[i][2];

                        (*FNv_dt)((t[i]+0.5*h),temp,m21);
			(*FNw_dt)((t[i]+0.5*h),temp,m22);
	                (*Fqq_dt)((t[i]+0.5*h),Omega[0],m23);
			k2[0]=m21;
			k2[1]=m22;
			k2[2]=m23;

			// k3 = f(t(n)+h/2, y(n)+k2*h/2)
			temp[0]=0.5*h*k2[0]+y[i][0];
			temp[1]=0.5*h*k2[1]+y[i][1];
			temp[2]=0.5*h*k2[2]+y[i][2];

			(*FNv_dt)((t[i]+0.5*h),temp,m31);
			(*FNw_dt)((t[i]+0.5*h),temp,m32);
	                (*Fqq_dt)((t[i]+0.5*h),Omega[0],m33);
			k3[0]=m31;
			k3[1]=m32;
			k3[2]=m33;

			// k4 = f(t(n)+h, y(n)+k3*h)

			temp[0]=h*k3[0]+y[i][0];
			temp[1]=h*k3[1]+y[i][1];
			temp[2]=h*k3[2]+y[i][2];

			(*FNv_dt)((t[i]+h),temp,m41);
			(*FNw_dt)((t[i]+h),temp,m42);
	                (*Fqq_dt)((t[i]+h),Omega[0],m43);
			k4[0]=m41;
			k4[1]=m42;
			k4[2]=m43;
			//The solution value

			//y[i+1].push_back(y[i][0]+(h/6)*(k1[0]+2*k2[0]+2*k3[0]+k4[0]));
			//y[i+1].push_back(y[i][1]+(h/6)*(k1[1]+2*k2[1]+2*k3[1]+k4[1]));
			//y[i+1].push_back(y[i][2]+(h/6)*(k1[2]+2*k2[2]+2*k3[2]+k4[2]));
			//y[i+1].push_back(y[i][3]+(h/6)*(k1[3]+2*k2[3]+2*k3[3]+k4[3]));
			//y[i+1].push_back(y[i][4]+(h/6)*(k1[4]+2*k2[4]+2*k3[4]+k4[4]));

			y[i+1][0]=y[i][0]+(h/6)*(k1[0]+2*k2[0]+2*k3[0]+k4[0]);
			y[i+1][1]=y[i][1]+(h/6)*(k1[1]+2*k2[1]+2*k3[1]+k4[1]);
			y[i+1][2]=y[i][2]+(h/6)*(k1[2]+2*k2[2]+2*k3[2]+k4[2]);

			//updata t
            t[i+1]=t[i]+h;
		}
}


void HH_Sci_Flate_RK4(vector<double> y0,double t0,int iter,double h,vector<vector<double> >  &y,vector<double>  &t,double *Flate_Current,
        void (*voltage_sci_dt)(double t,vector<double> y,double Input,double &dv_dt),
	void (*m_sci_dt)(double t,double y_0, double y_1, double &dm_dt),
	void (*h_sci_dt)(double t,double y_0, double y_2, double &dh_dt),
	void (*n_sci_dt)(double t,double y_0, double y_3,double &dn_dt))
{
	vector<double>  temp(4);
	vector<double>  k1(4);
	vector<double>  k2(4);
	vector<double>  k3(4);
	vector<double>  k4(4);
	double m11, m21, m31, m41;
	double m12, m22, m32, m42;
	double m13, m23, m33, m43;
	double m14, m24, m34, m44;

	t.resize(iter+1);
	y.resize(iter+1);
	t[0]=t0;

	for (int j=0;j<iter+1;j++)
		{
			y[j].resize(4);// five solutions:v,m,n,h,q
		}

	y[0]=y0;// input the initial values y0 to the y
////////////////////////////////////////////////////////////////////////////////
		for (int i=0; i<iter; i++)
		{
			// k1 = f(t(n), y(n))
			//(*voltage_sci_dt)(double t,vector<double> y,double Input,double &dv_dt)
			(*voltage_sci_dt)(t[i],y[i],Flate_Current[2*i],m11);
			//(*dmdt)(double t,double y_0, double y_1, double &dm_dt)
			(*m_sci_dt)(t[i],y[i][0],y[i][1],m12);

			//void (*dhdt)(double t,double y_0, double y_2, double &dh_dt)
	                (*h_sci_dt)(t[i],y[i][0],y[i][2],m13);
			//(*dndt)(double t,double y_0, double y_3,double &dn_dt)
			(*n_sci_dt)(t[i],y[i][0],y[i][3],m14);


			//assign the m11,m12,m13,m14 to k1
			k1[0]=m11;
			k1[1]=m12;
			k1[2]=m13;
			k1[3]=m14;

			// k2 = f(t(n)+h/2, y(n)+k1*h/2)


			temp[0]=0.5*h*k1[0]+y[i][0];
			temp[1]=0.5*h*k1[1]+y[i][1];
			temp[2]=0.5*h*k1[2]+y[i][2];
			temp[3]=0.5*h*k1[3]+y[i][3];

                        (*voltage_sci_dt)((t[i]+0.5*h),temp,Flate_Current[2*i+1],m21);
			(*m_sci_dt)((t[i]+0.5*h),temp[0],temp[1],m22);
	                (*h_sci_dt)((t[i]+0.5*h),temp[0],temp[2],m23);
			(*n_sci_dt)((t[i]+0.5*h),temp[0],temp[3],m24);

			k2[0]=m21;
			k2[1]=m22;
			k2[2]=m23;
			k2[3]=m24;

			// k3 = f(t(n)+h/2, y(n)+k2*h/2)
			temp[0]=0.5*h*k2[0]+y[i][0];
			temp[1]=0.5*h*k2[1]+y[i][1];
			temp[2]=0.5*h*k2[2]+y[i][2];
			temp[3]=0.5*h*k2[3]+y[i][3];


			(*voltage_sci_dt)((t[i]+0.5*h),temp,Flate_Current[2*i+1],m31);
			(*m_sci_dt)((t[i]+0.5*h),temp[0],temp[1],m32);
	                (*h_sci_dt)((t[i]+0.5*h),temp[0],temp[2],m33);
			(*n_sci_dt)((t[i]+0.5*h),temp[0],temp[3],m34);

			k3[0]=m31;
			k3[1]=m32;
			k3[2]=m33;
			k3[3]=m34;


			// k4 = f(t(n)+h, y(n)+k3*h)

			temp[0]=h*k3[0]+y[i][0];
			temp[1]=h*k3[1]+y[i][1];
			temp[2]=h*k3[2]+y[i][2];
			temp[3]=h*k3[3]+y[i][3];


			(*voltage_sci_dt)((t[i]+h),temp,Flate_Current[2*i+2],m41);
			(*m_sci_dt)((t[i]+h),temp[0],temp[1],m42);
	                (*h_sci_dt)((t[i]+h),temp[0],temp[2],m43);
			(*n_sci_dt)((t[i]+h),temp[0],temp[3],m44);

			k4[0]=m41;
			k4[1]=m42;
			k4[2]=m43;
			k4[3]=m44;

			//The solution value

			//y[i+1].push_back(y[i][0]+(h/6)*(k1[0]+2*k2[0]+2*k3[0]+k4[0]));
			//y[i+1].push_back(y[i][1]+(h/6)*(k1[1]+2*k2[1]+2*k3[1]+k4[1]));
			//y[i+1].push_back(y[i][2]+(h/6)*(k1[2]+2*k2[2]+2*k3[2]+k4[2]));
			//y[i+1].push_back(y[i][3]+(h/6)*(k1[3]+2*k2[3]+2*k3[3]+k4[3]));
			//y[i+1].push_back(y[i][4]+(h/6)*(k1[4]+2*k2[4]+2*k3[4]+k4[4]));

			y[i+1][0]=y[i][0]+(h/6)*(k1[0]+2*k2[0]+2*k3[0]+k4[0]);
			y[i+1][1]=y[i][1]+(h/6)*(k1[1]+2*k2[1]+2*k3[1]+k4[1]);
			y[i+1][2]=y[i][2]+(h/6)*(k1[2]+2*k2[2]+2*k3[2]+k4[2]);
			y[i+1][3]=y[i][3]+(h/6)*(k1[3]+2*k2[3]+2*k3[3]+k4[3]);

			//updata t
            t[i+1]=t[i]+h;
		}
}


void ModfyHH_Sci_White_RK4(vector<double> y0,double t0,int iter,double h,vector<double> &y,double &t,struct array Lbq_WhiteNoise,
	void (*voltage_sci_dt)(double t,vector<double> y,double Input,double &dv_dt),
	void (*m_sci_dt)(double t,double y_0, double y_1, double &dm_dt),
	void (*h_sci_dt)(double t,double y_0, double y_2, double &dh_dt),
	void (*n_sci_dt)(double t,double y_0, double y_3,double &dn_dt))
{
	vector<double>  temp(4);
	vector<double>  k1(4);
	vector<double>  k2(4);
	vector<double>  k3(4);
	vector<double>  k4(4);
	double m11, m21, m31, m41;
	double m12, m22, m32, m42;
	double m13, m23, m33, m43;
	double m14, m24, m34, m44;

	t=t0;
	y.resize(4);// five solutions:v,m,n,h
	y=y0;// input the initial values y0 to the y
////////////////////////////////////////////////////////////////////////////////
		for (int i=0; i<iter; i++)
		{
			// k1 = f(t(n), y(n))
			//(*voltage_sci_dt)(double t,vector<double> y,double Input,double &dv_dt)
			(*voltage_sci_dt)(t,y,*(Lbq_WhiteNoise.pStart+2*i),m11);
			//(*dmdt)(double t,double y_0, double y_1, double &dm_dt)
			(*m_sci_dt)(t,y[0],y[1],m12);
			//void (*dhdt)(double t,double y_0, double y_2, double &dh_dt)
	                (*h_sci_dt)(t,y[0],y[2],m13);
			//(*dndt)(double t,double y_0, double y_3,double &dn_dt)
			(*n_sci_dt)(t,y[0],y[3],m14);

			//assign the m11,m12,m13,m14 to k1
			k1[0]=m11;
			k1[1]=m12;
			k1[2]=m13;
			k1[3]=m14;

			// k2 = f(t(n)+h/2, y(n)+k1*h/2)


			temp[0]=0.5*h*k1[0]+y[0];
			temp[1]=0.5*h*k1[1]+y[1];
			temp[2]=0.5*h*k1[2]+y[2];
			temp[3]=0.5*h*k1[3]+y[3];

                        (*voltage_sci_dt)((t+0.5*h),temp,*(Lbq_WhiteNoise.pStart+2*i+1),m21);
			(*m_sci_dt)((t+0.5*h),temp[0],temp[1],m22);
	                (*h_sci_dt)((t+0.5*h),temp[0],temp[2],m23);
			(*n_sci_dt)((t+0.5*h),temp[0],temp[3],m24);

			k2[0]=m21;
			k2[1]=m22;
			k2[2]=m23;
			k2[3]=m24;

			// k3 = f(t(n)+h/2, y(n)+k2*h/2)
			temp[0]=0.5*h*k2[0]+y[0];
			temp[1]=0.5*h*k2[1]+y[1];
			temp[2]=0.5*h*k2[2]+y[2];
			temp[3]=0.5*h*k2[3]+y[3];


			(*voltage_sci_dt)((t+0.5*h),temp,*(Lbq_WhiteNoise.pStart+2*i+1),m31);
			(*m_sci_dt)((t+0.5*h),temp[0],temp[1],m32);
	                (*h_sci_dt)((t+0.5*h),temp[0],temp[2],m33);
			(*n_sci_dt)((t+0.5*h),temp[0],temp[3],m34);

			k3[0]=m31;
			k3[1]=m32;
			k3[2]=m33;
			k3[3]=m34;


			// k4 = f(t(n)+h, y(n)+k3*h)

			temp[0]=h*k3[0]+y[0];
			temp[1]=h*k3[1]+y[1];
			temp[2]=h*k3[2]+y[2];
			temp[3]=h*k3[3]+y[3];


			(*voltage_sci_dt)((t+h),temp,*(Lbq_WhiteNoise.pStart+2*i+2),m41);
			(*m_sci_dt)((t+h),temp[0],temp[1],m42);
	                (*h_sci_dt)((t+h),temp[0],temp[2],m43);
			(*n_sci_dt)((t+h),temp[0],temp[3],m44);

			k4[0]=m41;
			k4[1]=m42;
			k4[2]=m43;
			k4[3]=m44;

			//The solution value



			for(int i=0;i<4;i++)
			{
				y[i]=y[i]+(h/6)*(k1[i]+2*k2[i]+2*k3[i]+k4[i]);
			}

			//updata t
            t=t+h;
		}
}

void ModfyHH_Sci_Flate_RK4(vector<double> y0,double t0,int iter,double h,vector<double> &y,double &t,double *Flate_Current,
	void (*voltage_sci_dt)(double t,vector<double> y,double Input,double &dv_dt),
	void (*m_sci_dt)(double t,double y_0, double y_1, double &dm_dt),
	void (*h_sci_dt)(double t,double y_0, double y_2, double &dh_dt),
	void (*n_sci_dt)(double t,double y_0, double y_3,double &dn_dt))
{
	vector<double>  temp(4);
	vector<double>  k1(4);
	vector<double>  k2(4);
	vector<double>  k3(4);
	vector<double>  k4(4);
	double m11, m21, m31, m41;
	double m12, m22, m32, m42;
	double m13, m23, m33, m43;
	double m14, m24, m34, m44;

	t=t0;
	y.resize(4);// five solutions:v,m,n,h
	y=y0;// input the initial values y0 to the y
////////////////////////////////////////////////////////////////////////////////
		for (int i=0; i<iter; i++)
		{
			// k1 = f(t(n), y(n))
			//(*voltage_sci_dt)(double t,vector<double> y,double Input,double &dv_dt)
			(*voltage_sci_dt)(t,y,Flate_Current[2*i],m11);
			//(*dmdt)(double t,double y_0, double y_1, double &dm_dt)
			(*m_sci_dt)(t,y[0],y[1],m12);
			//void (*dhdt)(double t,double y_0, double y_2, double &dh_dt)
	                (*h_sci_dt)(t,y[0],y[2],m13);
			//(*dndt)(double t,double y_0, double y_3,double &dn_dt)
			(*n_sci_dt)(t,y[0],y[3],m14);

			//assign the m11,m12,m13,m14 to k1
			k1[0]=m11;
			k1[1]=m12;
			k1[2]=m13;
			k1[3]=m14;

			// k2 = f(t(n)+h/2, y(n)+k1*h/2)


			temp[0]=0.5*h*k1[0]+y[0];
			temp[1]=0.5*h*k1[1]+y[1];
			temp[2]=0.5*h*k1[2]+y[2];
			temp[3]=0.5*h*k1[3]+y[3];

                        (*voltage_sci_dt)((t+0.5*h),temp,Flate_Current[2*i+1],m21);
			(*m_sci_dt)((t+0.5*h),temp[0],temp[1],m22);
	                (*h_sci_dt)((t+0.5*h),temp[0],temp[2],m23);
			(*n_sci_dt)((t+0.5*h),temp[0],temp[3],m24);

			k2[0]=m21;
			k2[1]=m22;
			k2[2]=m23;
			k2[3]=m24;

			// k3 = f(t(n)+h/2, y(n)+k2*h/2)
			temp[0]=0.5*h*k2[0]+y[0];
			temp[1]=0.5*h*k2[1]+y[1];
			temp[2]=0.5*h*k2[2]+y[2];
			temp[3]=0.5*h*k2[3]+y[3];


			(*voltage_sci_dt)((t+0.5*h),temp,Flate_Current[2*i+1],m31);
			(*m_sci_dt)((t+0.5*h),temp[0],temp[1],m32);
	                (*h_sci_dt)((t+0.5*h),temp[0],temp[2],m33);
			(*n_sci_dt)((t+0.5*h),temp[0],temp[3],m34);

			k3[0]=m31;
			k3[1]=m32;
			k3[2]=m33;
			k3[3]=m34;


			// k4 = f(t(n)+h, y(n)+k3*h)

			temp[0]=h*k3[0]+y[0];
			temp[1]=h*k3[1]+y[1];
			temp[2]=h*k3[2]+y[2];
			temp[3]=h*k3[3]+y[3];


			(*voltage_sci_dt)((t+h),temp,Flate_Current[2*i+2],m41);
			(*m_sci_dt)((t+h),temp[0],temp[1],m42);
	                (*h_sci_dt)((t+h),temp[0],temp[2],m43);
			(*n_sci_dt)((t+h),temp[0],temp[3],m44);

			k4[0]=m41;
			k4[1]=m42;
			k4[2]=m43;
			k4[3]=m44;

			//The solution value



			for(int i=0;i<4;i++)
			{
				y[i]=y[i]+(h/6)*(k1[i]+2*k2[i]+2*k3[i]+k4[i]);
			}

			//updata t
            t=t+h;
		}
}

// This is the numerical method to SDE, which is Milstein method, to solve the HH model what addtive white noise.
void HH_Sci_White_Milstein(vector<double> y0,double t0,int iter,double h,vector<vector<double> >  &y,vector<double>  &t,double *White,
        void (*voltage_sci_dt)(double t,vector<double> y,double Input,double &dv_dt),
	void (*m_sci_dt)(double t,double y_0, double y_1, double &dm_dt),
	void (*h_sci_dt)(double t,double y_0, double y_2, double &dh_dt),
	void (*n_sci_dt)(double t,double y_0, double y_3,double &dn_dt))
{
	double m11, m12, m13, m14;
        double newh,newn,newm;
	t.resize(iter+1);
	y.resize(iter+1);
	t[0]=t0;

	for (int j=0;j<iter+1;j++)
		{
			y[j].resize(4);// five solutions:v,m,n,h,q
		}

	y[0]=y0;// input the initial values y0 to the y
////////////////////////////////////////////////////////////////////////////////
		for (int i=0; i<iter; i++)
		{
                        // SDE:
			// Y_(n+1)=Y_(n)+A(Y,t)*Detal_(n)+B(Y,t)*dw_(n)+(1/2)*B(Y,t)*(B(Y,t))'*(dw_(n)^2-detal)

                        // Following is to obtain A(Y,t)
			(*voltage_sci_dt)(t[i],y[i],0,m11);

			(*m_sci_dt)(t[i],y[i][0],y[i][1],m12);

                        (*h_sci_dt)(t[i],y[i][0],y[i][2],m13);

			(*n_sci_dt)(t[i],y[i][0],y[i][3],m14);

			//Because the B(Y,t)=1, therefore the B(Y,t)'=0;
                        //The solution value

                       #if Channel_Noise
                        {
                          //cout<<"Channel Noise"<<endl;
                          /*
			  y[i+1][0]=y[i][0]+m11*h+Sigma_white*White[i];

		          y[i+1][1]=y[i][1]+m12*h+m_std*White[i];

                          y[i+1][2]=y[i][2]+m13*h+h_std*White[i];

                          y[i+1][3]=y[i][3]+m14*h+n_std*White[i];
                          */
                          y[i+1][0]=y[i][0]+m11*h+White[i]*h;

                          newm=-1;
                          while(newm<0 || newm>1)
                            {
                                newm=y[i][1]+m12*h+m_std*sqrt(h)*WhiteNoise_1[i];
                            }
		                  y[i+1][1]=newm;

                          //cout<<"WhiteNoise_1 "<<WhiteNoise_1[0]<<endl;

                          newh=-1;
                          while(newh<0 || newh>1)
                            {
                                newh=y[i][2]+m13*h+h_std*sqrt(h)*WhiteNoise_1[i];
                            }
                          y[i+1][3]=newh;


                          newn=-1;
                          while(newn<0 || newn>1)
                            {
                                newn=y[i][3]+m14*h+n_std*sqrt(h)*WhiteNoise_1[i];
                            }
                          y[i+1][3]=newn;

			}
                       #else
                        {
			              y[i+1][0]=y[i][0]+m11*h+Sigma_white*White[i];
		                  y[i+1][1]=y[i][1]+m12*h;
                          y[i+1][2]=y[i][2]+m13*h;
                          y[i+1][3]=y[i][3]+m14*h;
                        }
                       #endif

			//updata t

                        t[i+1]=t[i]+h;
		}
}

//********************************************************************************************************************
void HH_Sci_White_Sine_Milstein(vector<double> y0,double t0,int iter,double h,vector<vector<double> >  &y,vector<double>  &t,double *White,
        void (*voltage_sci_1_dt)(double t,vector<double> y,double Input,double f,double &dv_dt),
	void (*m_sci_dt)(double t,double y_0, double y_1, double &dm_dt),
	void (*h_sci_dt)(double t,double y_0, double y_2, double &dh_dt),
	void (*n_sci_dt)(double t,double y_0, double y_3,double &dn_dt))
{



	double m11, m12, m13, m14;

	t.resize(iter+1);
	y.resize(iter+1);
	t[0]=t0;

	for (int j=0;j<iter+1;j++)
		{
			y[j].resize(4);// five solutions:v,m,n,h,q
		}

	y[0]=y0;// input the initial values y0 to the y
////////////////////////////////////////////////////////////////////////////////
		for (int i=0; i<iter; i++)
		{
                        // SDE:
			// Y_(n+1)=Y_(n)+A(Y,t)*Detal_(n)+B(Y,t)*dw_(n)+(1/2)*B(Y,t)*(B(Y,t))'*(dw_(n)^2-detal)

                        // Following is to obtain A(Y,t)
			(*voltage_sci_1_dt)(t[i],y[i],0,Omega_F_Sine,m11);

			(*m_sci_dt)(t[i],y[i][0],y[i][1],m12);

	                (*h_sci_dt)(t[i],y[i][0],y[i][2],m13);

			(*n_sci_dt)(t[i],y[i][0],y[i][3],m14);

			//Because the B(Y,t)=1, therefore the B(Y,t)'=0;
                        //The solution value
                       #if Channel_Noise
                        {
                          cout<<"Channel Noise"<<endl;
			  y[i+1][0]=y[i][0]+m11*h+h*White[i];

		          y[i+1][1]=y[i][1]+m12*h+m_std*White[i];

                          y[i+1][2]=y[i][2]+m13*h+h_std*White[i];

                          y[i+1][3]=y[i][3]+m14*h+n_std*White[i];
                          /*
                          y[i+1][0]=y[i][0]+m11*h+Sigma_white*White[i];
                          WhilteNoise_fun1(1);
		          y[i+1][1]=y[i][1]+m12*h+m_std*sqrt(h)*WhiteNoise_1[0];
                          WhilteNoise_fun1(1);
                          y[i+1][2]=y[i][2]+m13*h+h_std*sqrt(h)*WhiteNoise_1[0];
                          WhilteNoise_fun1(1);
                          y[i+1][3]=y[i][3]+m14*h+n_std*sqrt(h)*WhiteNoise_1[0];
                          */
			}
                       #else
                        {
			              y[i+1][0]=y[i][0]+m11*h+Sigma_white*White[i];
		                  y[i+1][1]=y[i][1]+m12*h;
                          y[i+1][2]=y[i][2]+m13*h;
                          y[i+1][3]=y[i][3]+m14*h;

                        }
                       #endif
			//updata t

                        t[i+1]=t[i]+h;
		}
}
//********************************************************************************************************************
void ModyHH_Sci_White_Milstein(vector<double> y0,double t0,int iter,double h,vector<double> &y,double &t,double *White,
	void (*voltage_sci_dt)(double t,vector<double> y,double Input,double &dv_dt),
	void (*m_sci_dt)(double t,double y_0, double y_1, double &dm_dt),
	void (*h_sci_dt)(double t,double y_0, double y_2, double &dh_dt),
	void (*n_sci_dt)(double t,double y_0, double y_3,double &dn_dt))
{
	double m11, m12, m13, m14;

	t=t0;

	y.resize(4);// five solutions:v,m,n,h,q


	y=y0;// input the initial values y0 to the y
////////////////////////////////////////////////////////////////////////////////
		for (int i=0; i<iter; i++)
		{
                        // SDE:
			// Y_(n+1)=Y_(n)+A(Y,t)*Detal_(n)+B(Y,t)*dw_(n)+(1/2)*B(Y,t)*(B(Y,t))'*(dw_(n)^2-detal)

            // Following is to obtain A(Y,t)
			(*voltage_sci_dt)(t,y,Mean_white,m11);

			(*m_sci_dt)(t,y[0],y[1],m12);

            (*h_sci_dt)(t,y[0],y[2],m13);

			(*n_sci_dt)(t,y[0],y[3],m14);

			//Because the B(Y,t)=1, therefore the B(Y,t)'=0;
                        //The solution value

			y[0]=y[0]+m11*h+h*White[i];
			y[1]=y[1]+m12*h+m_std*sqrt(h)*WhiteNoise_1[i];
            y[2]=y[2]+m13*h+h_std*sqrt(h)*WhiteNoise_1[i];
            y[3]=y[3]+m14*h+n_std*sqrt(h)*WhiteNoise_1[i];
            t=t+h;
		}
}
//*********************************************************************************************************************
void ModyHH_Sci_White_Sine_Milstein(vector<double> y0,double t0,int iter,double h,vector<double> &y,double &t,double *White,
	void (*voltage_sci_1_dt)(double t,vector<double> y,double Input,double f,double &dv_dt),
	void (*m_sci_dt)(double t,double y_0, double y_1, double &dm_dt),
	void (*h_sci_dt)(double t,double y_0, double y_2, double &dh_dt),
	void (*n_sci_dt)(double t,double y_0, double y_3,double &dn_dt))
{
	double m11, m12, m13, m14;

	t=t0;

	y.resize(4);// five solutions:v,m,n,h,q


	y=y0;// input the initial values y0 to the y
////////////////////////////////////////////////////////////////////////////////
		for (int i=0; i<iter; i++)
		{
                        // SDE:
			// Y_(n+1)=Y_(n)+A(Y,t)*Detal_(n)+B(Y,t)*dw_(n)+(1/2)*B(Y,t)*(B(Y,t))'*(dw_(n)^2-detal)

                        // Following is to obtain A(Y,t)
			(*voltage_sci_1_dt)(t,y,Mean_white,Omega_F_Sine,m11);

			(*m_sci_dt)(t,y[0],y[1],m12);

	                (*h_sci_dt)(t,y[0],y[2],m13);

			(*n_sci_dt)(t,y[0],y[3],m14);

			//Because the B(Y,t)=1, therefore the B(Y,t)'=0;
                        //The solution value

			y[0]=y[0]+m11*h+Sigma_white*White[i];
		        y[1]=y[1]+m12*h;
                        y[2]=y[2]+m13*h;
                        y[3]=y[3]+m14*h;

			//updata t

                        t=t+h;
		}
}

