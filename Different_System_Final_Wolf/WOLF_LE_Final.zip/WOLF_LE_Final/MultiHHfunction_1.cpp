#include <cstdlib>
#include <vector>
#include <string>
#include <iostream>
#include<cmath>
#include"HHconst.h"
#include"THHfunciton.h"
using namespace std;
double v_1;
double alphan_1,betan_1,alpham_1,betam_1,alphah_1,betah_1;
double SUM_1(double x, double y);
/*double vectordoubleSum(vector<double>::iterator first, vector<double>::size_type size);vector ���*/

void voltagei_1_dt(double t,vector<double> y,vector<double> amp,vector<double> &dv_dt)
{
	dv_dt[0]=(amp[0]+sin(2*pi*y[6]))-(g_na_max*(pow(y[1],3))*y[2]*(y[0]-115) + g_k_max*(pow(y[3],4))*(y[0]+12) + g_l*(-10.6+y[0]))-y[4]*(y[0]+65);
	dv_dt[1]=-(g_na_max*(pow(y[8],3))*y[9]*(y[7]-115) + g_k_max*(pow(y[10],4))*(y[7]+12) + g_l*(-10.6+y[7]))-y[11]*(y[7]+65);

}
    void mi_1_dt(double t,vector<double> y, vector<double> &dm_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
	      int y1=1+7*(NumNeuronth-1);
	      v_1=y[7*(NumNeuronth-1)];
	      //m channel
	      alpham_1=0.1*(25-v_1)/(exp((25-v_1)/10)-1);
	      betam_1=4*exp(-v_1/18);
	      dm_dt[NumNeuronth-1]=(alpham_1-(alpham_1+betam_1)*y[y1]);
	}
}
	void hi_1_dt(double t,vector<double> y,vector<double> &dh_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
	      int y2=2+7*(NumNeuronth-1);
	      v_1=y[7*(NumNeuronth-1)];
	      //h channel
	      alphah_1=0.07*exp(-v_1/20);
	      betah_1=1/(exp((30-v_1)/10)+1);
	      dh_dt[NumNeuronth-1]=(alphah_1-(alphah_1+betah_1)*y[y2]);
	}
}
	void ni_1_dt(double t,vector<double> y, vector<double> &dn_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
	      int y3=3+7*(NumNeuronth-1);
	      v_1=y[7*(NumNeuronth-1)];
	      //n channel
	      alphan_1=0.01*(10-v_1)/(exp((10-v_1)/10)-1);
	      betan_1=0.125*exp(-v_1/80);
	      dn_dt[NumNeuronth-1]=(alphan_1-(alphan_1+betan_1)*y[y3]);
	}
}
	void Gi_1_dt(double t,vector<double> y,vector<double> &G_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{  
		int y4=4+7*(NumNeuronth-1);
		int y5=5+7*(NumNeuronth-1);
		G_dt[NumNeuronth-1]=y[y5]-y[y4]/Time_ExCon;
	}

}
	void G1i_1_dt(double t,vector<double> y,vector<vector<double> >  Couple,vector<double> &G_dt)
{
	double sum;
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
		sum=0;
		int y5=5+7*(NumNeuronth-1);
		for(int PreNeuron=0;PreNeuron<NumNeuron;PreNeuron++)
		{
		int y7=7*(PreNeuron);
		sum=SUM_1(Couple[NumNeuronth-1][PreNeuron]*(1/(1+exp(-(y[y7]-20)/2))),sum);
		}
		G_dt[NumNeuronth-1]= -(y[y5]/Time_ExConR)+sum;
	}
	}
	void qi_1_dt(double t,vector<double> Omega,vector<double> &dq_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
	   dq_dt[NumNeuronth-1]=Omega[NumNeuronth-1];
	}
}
	double SUM_1(double x, double y)
	{
		return (x+y);
	}
