#include "HHconst.h"
#include "loop.h"

using namespace std;

void vector_initialize(vector_v &a) // for a vector without being evaluated
{
	a.vect_size = -1;

	a.vect_index = 0;

	a.vect_value = NULL;
};

void vector_set_value(vector_v &a, int dim, double v)
{
	if (a.vect_value != NULL)
	{
		free(a.vect_value);
	}
	
	a.vect_size = dim;
	
	a.vect_index = 0;

	a.vect_value = (double*)malloc(sizeof(double)*dim);
	
	for (int i = 0; i < dim; i++)
	{
		a.vect_value[i] = v;
	}
};

void vector_allocate(vector_v &a, int dim)
{
	if (a.vect_value != NULL)
	{
		free(a.vect_value);
	}

	a.vect_index = 0;
	a.vect_size = dim;

	a.vect_value = (double*)malloc(sizeof(double)*dim);
}

void vector_reallocate(vector_v &a)
{
	a.vect_size += VECTOR_ADD_SIZE;
	
	double *new_vect_value = (double*)malloc(a.vect_size*sizeof(double));

	for (int i=0; i<a.vect_index; i++)
	{
		new_vect_value[i] = a.vect_value[i];
	}

	free(a.vect_value);
	a.vect_value = new_vect_value;
};

void vector_insert(vector_v &a, double v)
{
	if (a.vect_index >= a.vect_size)
	{
		vector_reallocate(a);
	}

	a.vect_value[a.vect_index] = v;
	a.vect_index++;
}

void vector_destroy(vector_v &a) 
{
	a.vect_size = -1;

	a.vect_index = 0;

	if (a.vect_value != NULL)
	{
		free(a.vect_value);

		a.vect_value = NULL;
	}	
};

void vector_copy(vector_v &des, const vector_v &src)
{
	if (des.vect_value != NULL)
	{
		free(des.vect_value);
	}
	
	des.vect_size = src.vect_size;

	if (des.vect_size < 0)
	{
		cout<<"The source vector is null! "<<endl;
		return;
	}

	des.vect_value = (double*)malloc(sizeof(double)*src.vect_size);
	
	memcpy(des.vect_value, src.vect_value, sizeof(double)*src.vect_size);
};

double vector_sum(vector_v &a)
{
	int i;
	double sum = 0.0;
	for (i=0; i<a.vect_size; i++)
	{
		sum += a.vect_value[i];
	}
	return sum;
}

void vector_output(vector_v &a)
{
	cout<<"vector output begins: "<<endl;
    
	// a.vect_size implies whether the vector is evaluated or not
	for (int i=0; i<a.vect_size; i++)
	{
		cout<<a.vect_value[i]<<"  ";

		if ((i+1)%6==0)
		{
			cout<<endl;
		}
	}

	cout<<"vector output ends! "<<endl;
};

void loop_initialize(loop &a)
{
	a.loop_index = -1;

	vector_initialize(a.loop_vect);
};

void loop_allocate(loop &a, int dim)
{
	a.loop_index = 0;

	vector_set_value(a.loop_vect, dim, 0);
};

void loop_insert(loop &a, double data)
{
//	a.loop_index = (a.loop_index % (a.loop_vect).vect_size);

	(a.loop_vect).vect_value[a.loop_index % (a.loop_vect).vect_size] = data;

	a.loop_index++;

};

double loop_sum(loop &a)
{
	return vector_sum(a.loop_vect);
}

void loop_destroy(loop &a)
{
	a.loop_index = -1;

	vector_destroy(a.loop_vect);

};

void loop_output(loop &a)
{
	cout<<"loop vector output begins: "<<endl;

	int length = (a.loop_vect).vect_size;
	for (int i=0; i<length; i++)
	{
		cout<<(a.loop_vect).vect_value[(i+a.loop_index)%length]<<"  ";

		if ((i+1)%6==0)
		{
			cout<<endl;
		}
	}

	cout<<"loop vector output ends! "<<endl;
};
