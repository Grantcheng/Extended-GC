#ifndef _save_h_
#define _save_h_
#include <cstdlib>
#include <vector>
#include <string>
#include <iostream>
#include<cmath>
#include<fstream>

using namespace std;

void save(vector<vector<double> > DATA,string fname);
void save_f(vector<double>FData,string fname);
void save_solution(vector<double> DATA,string fname);
void save_solution_Strength(vector<double> DATA,string fname1, string fname);
int CreatDir(char *pDir) ;
#endif 
