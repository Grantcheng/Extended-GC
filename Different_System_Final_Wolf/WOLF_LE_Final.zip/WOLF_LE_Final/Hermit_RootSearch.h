#ifndef _Hermit_RootSearch_h_
#define _Hermit_RootSearch_h_

#include <iostream>
#include <vector>
#include <string>
using namespace std;

void hermit(double a, double b, double va, double vb,double dva, double dvb, double x, double &fx);

double root_search(void (*func)(double a, double b, double va, double vb,double dva, double dvb, double x, double &fx), double x1, double x2, 
				 double fx1, double fx2, double dfx1, double dfx2, double xacc);

#endif // _Hermit_RootSearch_h_
