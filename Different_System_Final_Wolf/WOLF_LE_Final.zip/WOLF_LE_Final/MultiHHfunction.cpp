#include <cstdlib>
#include <vector>
#include <string>
#include <iostream>
#include<cmath>
#include"HHconst.h"
#include"THHfunciton.h"
using namespace std;
double v;
double alphan,betan,alpham,betam,alphah,betah;
double SUM(double x, double y);
/*double vectordoubleSum(vector<double>::iterator first, vector<double>::size_type size);vector ���*/

void voltagei_dt(double t,vector<double> y,vector<double> amp,vector<double> &dv_dt)
{
		for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
		{
		int y6=7*NumNeuronth-1;
		int y1=1+7*(NumNeuronth-1);
		int y0=7*(NumNeuronth-1);
		int y2=2+7*(NumNeuronth-1);
		int y3=3+7*(NumNeuronth-1);
		int y4=4+7*(NumNeuronth-1);
		dv_dt[NumNeuronth-1]=(amp[NumNeuronth-1]+sin(2*pi*y[y6]))-(g_na_max*(pow(y[y1],3))*y[y2]*(y[y0]-115) + g_k_max*(pow(y[y3],4))*(y[y0]+12) + g_l*(-10.6+y[y0]))-y[y4]*(y[y0]+65);
	       }
}
    void mi_dt(double t,vector<double> y, vector<double> &dm_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
	      int y1=1+7*(NumNeuronth-1);
	      v=y[7*(NumNeuronth-1)];
	      //m channel
	      alpham=0.1*(25-v)/(exp((25-v)/10)-1);
	      betam=4*exp(-v/18);
	      dm_dt[NumNeuronth-1]=(alpham-(alpham+betam)*y[y1]);
	}
}
	void hi_dt(double t,vector<double> y,vector<double> &dh_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
	      int y2=2+7*(NumNeuronth-1);
	      v=y[7*(NumNeuronth-1)];
	      //h channel
	      alphah=0.07*exp(-v/20);
	      betah=1/(exp((30-v)/10)+1);
	      dh_dt[NumNeuronth-1]=(alphah-(alphah+betah)*y[y2]);
	}
}
	void ni_dt(double t,vector<double> y, vector<double> &dn_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
	      int y3=3+7*(NumNeuronth-1);
	      v=y[7*(NumNeuronth-1)];
	      //n channel
	      alphan=0.01*(10-v)/(exp((10-v)/10)-1);
	      betan=0.125*exp(-v/80);
	      dn_dt[NumNeuronth-1]=(alphan-(alphan+betan)*y[y3]);
	}
}
	void Gi_dt(double t,vector<double> y,vector<double> &G_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
		int y4=4+7*(NumNeuronth-1);
		int y5=5+7*(NumNeuronth-1);
		G_dt[NumNeuronth-1]=y[y5]-y[y4]*2;
	}

}
	void G1i_dt(double t,vector<double> y,vector<vector<double> >  Couple,vector<double> &G_dt)
{
	
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
		double sum=0;
		int y5=5+7*(NumNeuronth-1);
		for(int PreNeuron=0;PreNeuron<NumNeuron;PreNeuron++)
		{
		int y7=7*(PreNeuron);
		sum=SUM(Couple[NumNeuronth-1][PreNeuron]*(1/(1+exp(-(y[y7]-20)/2))),sum);
		}
		G_dt[NumNeuronth-1]= -(y[y5]*2)+sum;
	}
	}
	void qi_dt(double t,vector<double> Omega,vector<double> &dq_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
	   dq_dt[NumNeuronth-1]=Omega[NumNeuronth-1];
	}
}
	double SUM(double x, double y)
	{
		return (x+y);
	}