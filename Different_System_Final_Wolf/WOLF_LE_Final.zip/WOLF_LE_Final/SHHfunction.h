#ifndef _SHHfunction_h_
#define _SHHfunction_h_
#include <iostream>
#include <vector>
#include <string>
using namespace std;

        void voltage_dt(double t,vector<double> y,double &dv_dt);
        void m_dt(double t,double y_0,double y, double &dm_dt);
	void h_dt(double t,double y_0,double y,double &dh_dt);
	void n_dt(double t,double y_0,double y, double &dn_dt);
	void qq_dt(double t,double Omega,double &dq_dt);
	void ISIJin(int N, double Dt,vector<double> y_0, vector<double> Omega,vector<vector<double> >Couple,vector<double> amp, double *out_y);
	

        void voltageo_dt(double t,vector<double> y,double &dv_dt);
        void mo_dt(double t,double y_0,double y, double &dm_dt);
	void ho_dt(double t,double y_0,double y,double &dh_dt);
	void no_dt(double t,double y_0,double y, double &dn_dt);
	void qqo_dt(double t,double Omega,double &dq_dt);
	
	void voltage_p_dt(double t,vector<double> y,double gE, double gI,double &dv_dt);
        void voltage_p_non_dt(double t,vector<double> y,double Omega,double gE, double gI,double &dv_dt);
	void m_p_dt(double t,double y_0, double y_1, double &dm_dt);
	void h_p_dt(double t,double y_0, double y_2, double &dh_dt);
	void n_p_dt(double t,double y_0, double y_3,double &dn_dt);
	void q_p_dt(double t,double Omega, double &dqp_dt);

        void voltage_sci_1_dt(double t,vector<double> y,double Input,double f,double &dv_dt);
	void voltage_sci_dt(double t,vector<double> y,double Input,double &dv_dt);
	void m_sci_dt(double t,double y_0, double y_1, double &dm_dt);
	void h_sci_dt(double t,double y_0, double y_2, double &dh_dt);
	void n_sci_dt(double t,double y_0, double y_3,double &dn_dt);
        void HH_SCI_ISIJin(int N, double Dt,int Flage_sci_flat_white,vector<double> y_0, vector<double> Omega,double *out_y);

#endif // _SHHfunction_h_
