/*: conv function */

#include <iostream> 
#include"Convolutional.h"
using namespace std;

/*
struct array conv(array a,array b);


int main()
{
int i;
struct array a,b,y;
a.length =1000;
b.length =1000;
a.pStart =new float [a.length ];
b.pStart =new float [b.length ];

// display a,b & the result of conv
cout<<"a=   ";
for (i=0;i<a.length;i++)
{
*(a.pStart+i)=float(1);
cout<<*(a.pStart+i)<<"   ";
}
cout<<endl;

cout<<"b=   ";
for (i=0;i<b.length;i++)
{
*(b.pStart+i)=float(1+i);
cout<<*(b.pStart+i)<<"   ";
}
cout<<endl;

cout<<"y=   ";
y=conv(a,b);
for (i=0;i<y.length;i++)
cout<<*(y.pStart+i)<<"   ";

cout<<endl;

delete [] a.pStart ;
delete [] b.pStart ;
delete [] y.pStart ;

return 0;
}
*/

struct array conv(array a,array b)
{
int i,j;
float aa,bb;
struct array y;
y.length =a.length +b.length-1 ;
y.pStart =new float [y.length];

for (i=0;i<y.length ;i++)
*(y.pStart +i)=0;

if (a.length >=b.length )  //如果a的长度大于或等于b的长度
{
for (i=0;i<b.length ;i++)
{
for (j=0;j<=i;j++)
{
aa=*(a.pStart+i-j);
    bb=*(b.pStart +j);
*(y.pStart +i)=*(y.pStart +i)+aa*bb;
}
}

for (i=b.length;i<a.length;i++)
{
for (j=0;j<b.length;j++)
{
aa=*(a.pStart+i-j);
    bb=*(b.pStart +j);
*(y.pStart +i)=*(y.pStart +i)+aa*bb;
}
}

for (i=a.length;i<a.length+b.length;i++)
{
for (j=i-a.length+1;j<b.length;j++)
{
aa=*(a.pStart+i-j);
    bb=*(b.pStart +j);
*(y.pStart +i)=*(y.pStart +i)+aa*bb;
}
}
}

else  //如果b的长度大于或等于a的长度
{
for (i=0;i<a.length ;i++)
{
for (j=0;j<=i;j++)
{
bb=*(b.pStart+i-j);
    aa=*(a.pStart +j);
*(y.pStart +i)=*(y.pStart +i)+aa*bb;
}
}

for (i=a.length;i<b.length;i++)
{
for (j=0;j<a.length;j++)
{
bb=*(b.pStart+i-j);
    aa=*(a.pStart +j);
*(y.pStart +i)=*(y.pStart +i)+aa*bb;
}
}

for (i=b.length;i<b.length+a.length-1;i++)
{
for (j=i-b.length+1;j<a.length;j++)
{
bb=*(b.pStart+i-j);
    aa=*(a.pStart +j);
*(y.pStart +i)=*(y.pStart +i)+aa*bb;
}
}
}

return(y);
} 
