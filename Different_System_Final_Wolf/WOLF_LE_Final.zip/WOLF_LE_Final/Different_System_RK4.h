#ifndef _Different_System_RK4_H_
#define _Different_System_RK4_H_
#include <iostream>
#include <vector>
#include <string>
#include "Convolutional.h"
using namespace std;

void System_Duffing_RK4(vector<double> y0,vector<double> Omega,double t0,int iter,double h,double alpha,double beta,double gamma,double force,
        vector<vector<double> >  &y,vector<double>  &t,
        void (*x_dt)(double t,double y_2,double &dx_dt),
	void (*y_dt)(double t,double y_2, double y_1, double y_3,double alpha,double beta,double gamma,double force,double &dy_dt),
	void (*dqdt)(double t,double Omega, double &dq_dt));


void System_Lorenz_RK4(vector<double> y0,vector<double> Omega,double t0,int iter,double h,vector<vector<double> >  &y,vector<double>  &t,
        void (*Lx_dt)(double t, vector<double> Ly, double &dx_dt),
	void (*Ly_dt)(double t, vector <double> Ly,double &dy_dt),
	void (*Lz_dt)(double t, vector<double> Ly, double &dz_dt));

void System_Rossler_RK4(vector<double> y0,vector<double> Omega,double t0,int iter,double h,vector<vector<double> >  &y,vector<double>  &t,
        void (*Lx_dt)(double t, vector<double> Ly, double &dx_dt),
	void (*Ly_dt)(double t, vector <double> Ly,double &dy_dt),
	void (*Lz_dt)(double t, vector<double> Ly, double &dz_dt));

void System_Morris_Lecar_RK4(vector<double> y0,vector<double> Omega,double t0,int iter,double h,vector<vector<double> >  &y,vector<double>  &t,
        void (*MLv_dt)(double t, vector<double> Ly, double Omega, double &dv_dt),
	void (*MLw_dt)(double t, vector <double> Ly,double Omega, double &dw_dt),
        void (*Mqq_dt)(double t,vector<double> ML_y,double Omega, double &dqq_dt));

void MSystem_Morris_Lecar_RK4(vector<double> y0,vector<double> Omega,double t0,int iter,double h,vector<vector<double> >  &y,vector<double>  &t,
        vector<vector<double> >Couple,vector<double> amp,
        void (*MLv_mdt)(double t, vector<double> Ly, vector<double> amp,vector<double> Omega,vector<double>  &dv_dt),
	void (*MLw_mdt)(double t, vector <double> Ly,vector<double> Omega,vector<double>  &dw_dt),
        void (*MG1idt)(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt),
        void (*Mqq_mdt)(double t,vector<double> ML_y,vector<double> Omega, vector<double>  &Mqq_dt));

void System_Fitzhugh_Nagumo_RK4(vector<double> y0,vector<double> Omega,double t0,int iter,double h,vector<vector<double> >  &y,vector<double>  &t,
        void (*FNv_dt)(double t, vector<double> Ly, double &dv_dt),
	void (*FNw_dt)(double t, vector <double> Ly,double &dw_dt),
        void (*Fqq_dt)(double t,double Omega, double &dqq_dt));

void HH_Sci_Flate_RK4(vector<double> y0,double t0,int iter,double h,vector<vector<double> >  &y,vector<double>  &t,double *Flate_Current,
        void (*voltage_sci_dt)(double t,vector<double> y,double Input,double &dv_dt),
	void (*m_sci_dt)(double t,double y_0, double y_1, double &dm_dt),
	void (*h_sci_dt)(double t,double y_0, double y_2, double &dh_dt),
	void (*n_sci_dt)(double t,double y_0, double y_3,double &dn_dt));

void HH_Sci_White_RK4(vector<double> y0,double t0,int iter,double h,vector<vector<double> >  &y,vector<double>  &t,struct array Lbq_WhiteNoise,
        void (*voltage_sci_dt)(double t,vector<double> y,double Input,double &dv_dt),
	void (*m_sci_dt)(double t,double y_0, double y_1, double &dm_dt),
	void (*h_sci_dt)(double t,double y_0, double y_2, double &dh_dt),
	void (*n_sci_dt)(double t,double y_0, double y_3,double &dn_dt));

void ModfyHH_Sci_White_RK4(vector<double> y0,double t0,int iter,double h,vector<double> &y,double &t,struct array Lbq_WhiteNoise,
	void (*voltage_sci_dt)(double t,vector<double> y,double Input,double &dv_dt),
	void (*m_sci_dt)(double t,double y_0, double y_1, double &dm_dt),
	void (*h_sci_dt)(double t,double y_0, double y_2, double &dh_dt),
	void (*n_sci_dt)(double t,double y_0, double y_3,double &dn_dt));

void ModfyHH_Sci_Flate_RK4(vector<double> y0,double t0,int iter,double h,vector<double> &y,double &t,double *Flate_Current,
	void (*voltage_sci_dt)(double t,vector<double> y,double Input,double &dv_dt),
	void (*m_sci_dt)(double t,double y_0, double y_1, double &dm_dt),
	void (*h_sci_dt)(double t,double y_0, double y_2, double &dh_dt),
	void (*n_sci_dt)(double t,double y_0, double y_3,double &dn_dt));

void HH_Sci_White_Milstein(vector<double> y0,double t0,int iter,double h,vector<vector<double> >  &y,vector<double>  &t,double *White,
        void (*voltage_sci_dt)(double t,vector<double> y,double Input,double &dv_dt),
	void (*m_sci_dt)(double t,double y_0, double y_1, double &dm_dt),
	void (*h_sci_dt)(double t,double y_0, double y_2, double &dh_dt),
	void (*n_sci_dt)(double t,double y_0, double y_3,double &dn_dt));

void ModyHH_Sci_White_Milstein(vector<double> y0,double t0,int iter,double h,vector<double> &y,double &t,double *White,
	void (*voltage_sci_dt)(double t,vector<double> y,double Input,double &dv_dt),
	void (*m_sci_dt)(double t,double y_0, double y_1, double &dm_dt),
	void (*h_sci_dt)(double t,double y_0, double y_2, double &dh_dt),
	void (*n_sci_dt)(double t,double y_0, double y_3,double &dn_dt));

void ModyHH_Sci_White_Sine_Milstein(vector<double> y0,double t0,int iter,double h,vector<double> &y,double &t,double *White,
	void (*voltage_sci_1_dt)(double t,vector<double> y,double Input,double f,double &dv_dt),
	void (*m_sci_dt)(double t,double y_0, double y_1, double &dm_dt),
	void (*h_sci_dt)(double t,double y_0, double y_2, double &dh_dt),
	void (*n_sci_dt)(double t,double y_0, double y_3,double &dn_dt));

void HH_Sci_White_Sine_Milstein(vector<double> y0,double t0,int iter,double h,vector<vector<double> >  &y,vector<double>  &t,double *White,
        void (*voltage_sci_1_dt)(double t,vector<double> y,double Input,double f,double &dv_dt),
	void (*m_sci_dt)(double t,double y_0, double y_1, double &dm_dt),
	void (*h_sci_dt)(double t,double y_0, double y_2, double &dh_dt),
	void (*n_sci_dt)(double t,double y_0, double y_3,double &dn_dt));
#endif
