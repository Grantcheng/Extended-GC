#ifndef _DATAINPUT_H_
#define _DATAINPUT_H_

// read data from input file to set up some global variables
void readinput(char *filename);

// initial setup of global variables, such as assigning space ...
void setglobals();

// initial setup for the external drive, the neurons' information, ...
void input_initialization(vector<double> y_0);

// generate poisson input spike train
void poisson_generator(int index_neuron, vector_v &Timing_input,double Tstep_1);

#if FFTW_USE     
// save the power spectrum of voltage 
void powerspectrum_vot_BINrecord();
#endif

void data_dump();

#endif
