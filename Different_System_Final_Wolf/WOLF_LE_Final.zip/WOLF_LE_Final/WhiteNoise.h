#ifndef _WhiteNoise_H_
#define _WhiteNoise_H_

void	F_CreatWhiteNoise(double fSigma,int FRAME_1,int flage_channel);
double	F_ComputeMean(double* pData ,int nCount);
double	F_ComputeVar(double* pData ,int nCount);
void	F_ComputePdf(void);
double WhilteNoise_fun(int FRAME);
double WhilteNoise_fun1(int FRAME);
#endif //_WhiteNoise_H_
