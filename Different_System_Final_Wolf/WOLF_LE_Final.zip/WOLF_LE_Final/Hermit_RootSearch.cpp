#include <cstdlib>
#include <vector>
#include <string>
#include <iostream>
#include <cmath>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <stdio.h>
#include <time.h>
#include "Lya_input.h"
#include "Different_System_RK4.h"
#include "HHconst.h"
#include "Duffing_Equation.h"
#include "RK4.h"
#include "SHHfunction.h"
#include "THHfunciton.h"
#include "poisson_input.h"
#include "neuron.h"
#include "loop.h"
#include "datainput.h"

void hermit(double a, double b, double va, double vb, 
			double dva, double dvb, double x, double &fx)
{
	// use v(a), v(b), dv(a)/dt, dv(b)/dt to construct a cubic polynomial
	// basic function f1 satisfies: f1(a)=1, f1(b)=0, f1'(a)=0, f1'(b)=0
	double f1 = va*(2*x+b-3*a)*(x-b)*(x-b)/(b-a)/(b-a)/(b-a);
	// basic function f2 satisfies: f2(a)=0, f2(b)=1, f2'(a)=0, f2'(b)=0
	double f2 = vb*(3*b-2*x-a)*(x-a)*(x-a)/(b-a)/(b-a)/(b-a);
	// basic function f3 satisfies: f3(a)=0, f3(b)=0, f3'(a)=1, f3'(b)=0
	double f3 = dva*(x-a)*(x-b)*(x-b)/(b-a)/(b-a);
	// basic function f4 satisfies: f4(a)=0, f4(b)=0, f4'(a)=0, f4'(b)=1
	double f4 = dvb*(x-a)*(x-a)*(x-b)/(b-a)/(b-a);

    // the polynomial of v(x) - Vot_Threshold
     //  cout<<"Vot_Threshold = "<<Vot_Threshold<<endl;
	fx = f1 + f2 + f3 + f4 - Vot_Threshold; 
};

double root_search(void (*func)(double a, double b, double va, double vb,
				 double dva, double dvb, double x, double &fx), double x1, double x2, 
				 double fx1, double fx2, double dfx1, double dfx2, double xacc)
{
	int j;
	double tempx1,tempx2,dx,f,fmid,xmid,root;

	// for firing time case, fx1<0, fmid>0
	(*func)(x1,x2,fx1,fx2,dfx1,dfx2,x1,f);
	(*func)(x1,x2,fx1,fx2,dfx1,dfx2,x2,fmid);
 
	if (f*fmid > 0) 
	{
		//cout<<"The neuron does not fire at the end point?!"<<endl;
		//cout<<"voltage difference at the beginning time and ending time: "<<f<<" ; "<<fmid<<endl;
 		return x1;
	}

#if ROOT_FIND_DEBUG
	cout<<endl<<"In root_search program!"<<endl;
	cout<<"the global time: "<<time_evolution<<endl;
	cout<<"the value at left interval point: "<<f<<endl;
	cout<<"the value at right interval point "<<fmid<<endl;
#endif

	tempx1 = x1;
	tempx2 = x2;
	for (j=0; j<Maxnum_search; j++)
	{
		dx = tempx2 - tempx1;
		xmid = tempx1 + dx/2;
		(*func)(x1,x2,fx1,fx2,dfx1,dfx2,xmid,fmid);
		
		if (fmid <= 0.0) 
		{
			tempx1 = xmid;
		}
		else
		{
			tempx2 = xmid;
		}

#if ROOT_FIND_DEBUG
		cout<<"iteration number: "<<j<<"; "<<"mid value: "<<fmid<<endl;
#endif
		// the interval is small enough or already find the root
		if (fabs(fmid)<xacc)
		{
			root = xmid;
			return root;
		}
	}

#if ROOT_FIND_DEBUG
	cout<<"the estimated root: "<<tempx1<<"  "<<tempx2<<"  "<<xmid<<endl;
	cout<<"the value at the estimated root: "<<fabs(fmid)<<endl;
#endif

	//cout<<"Too many bisections in root searching!"<<endl;
//	getchar();

	return xmid;
};
