#ifndef _tau_const_h_
#define _tau_const_h_
void Mutual_Function_opentstool (double *Pdata,int * tau,unsigned long Length,long Corrlength);
void Mutual_Function (double *pdata,int * tau,unsigned long length,long corrlength);
//void SearchNN(ANNpointArray dataPts,int *ref1,int nPts,int *index1,double *R_D1,int dim);
void SearchNN(double** dataPts,int *ref1,int nPts,int *index1,double *R_D1,int dim);

void FNN(double *pdata,int N,int tau,int d_max,double R_tol,double A_tol, int *Dim_FNN,int DOS);
void FNN_Multi(double *pdata_1,double *pdata_2,int N_pdata,int tau,int tau2,int d_max,int *Dim_FNN);

void System_Solve(int N, vector<double> y_0, vector<double> Omega, double alpha,double beta,double gamma,double force,double *out_y);
void Lorenz_System_Solve(int N,vector<double> y_0, vector<double> Omega,double h,double *out_y);
vector<vector<double> > Morris_Lecar_Solve(int N,vector<double> y_0, vector<double> Omega,double h, double *out_y);
vector<vector<double> > Fitzhugh_Nagumo_Solve(int N,vector<double> y_0, vector<double> Omega,double h, double *out_y);
void Rossler_System_Solve(int N,vector<double> y_0, vector<double> Omega,double h,double *out_y);
void ISIJin(int N, double Dt,vector<double> y_0, vector<double> Omega,vector<vector<double> >Couple,vector<double> amp, double *out_y);


#endif // _tau_const_h_
