#include<iostream>
#include<cmath>
#include<iomanip>
#include<fstream>
#include<stdio.h>
#include<stdlib.h>
#include<sstream>
#include<vector>
#include"HHconst.h"
#include"SHHfunction.h"
#include"THHfunciton.h"
#include"convergence.h"
#include"RK4.h"
#include"Lya_input.h"
#include"save.h"
#include"Different_System_RK4.h"
#include"Duffing_Equation.h"

using namespace std;
//void save_solution(vector<double> DATA,string fname);
//string   double_to_str(double x) ;

/*void FREE_1(vector<vector<double> > &Initial_1)
{
	vector<vector<double> > SWAP_1;
    Initial_1.swap(SWAP_1);

}
void FREE_2(vector<double> &Initial_2)
{

	vector<double> SWAP_2;
	Initial_2.swap(SWAP_2);
}
*/
vector<vector<double> > ISIJin2(int N,double Dt, vector<double> y_0, vector<double> Omega,vector<vector<double> >Couple,vector<double> amp, double *out_y,double *out_y2,int Length_NN)
{
double Tstart=0;
double h=Dt;
int solution_num;
vector<double> T0;
vector<vector<double> > y;
vector<double> y_temp;
vector<vector<double> > SpikeTime;
vector<vector<double> > HH_solution;

vector<vector<double> > ISI1;
vector<vector<double> > ISIout;
double T0_convergence;
vector<string> sloution_name;
vector<string> strength_name;
double Time=1024;//convergence test ,the time evolution
double h_0=(double)1/1024;
double N_0;//convergence test ,the time evolution
N_0=Time/h_0;//convergence test ,the time evolution
int num_neuron_ISIJin2 = Number_Exneuron + Number_Inneuron;
solution_num=num_neuron_ISIJin2;
int array[solution_num];
cout<<"solution_num is "<<solution_num<<endl;
cout<<endl;
cout<<endl;
cout<<"Now is running ISIJin2 "<<endl;
cout<<endl;
cout<<"Convergence_Test_0 = "<<Convergence_Test_0<<endl;
cout<<"Vot_Threshold = "<<Vot_Threshold<<endl;
cout<<endl;
#if Convergence_Test_0  //Test convergence of the single neuron program
vector<double> y_convergence;
cout<<" Running Convergence Test "<<endl;

#if POISSON_INPUT_USE
cout<<"Test Poisson Convergence "<<endl;
cout<<endl;
Convergence_P(y_0,Omega,Tstart,N_0,h_0,y_convergence,T0_convergence,Time);
#else
cout<<"Test Sine Convergence "<<endl;
cout<<endl;
Convergence_2(y_0,Omega,Tstart,N_0,h_0,y_convergence,T0_convergence,Couple,amp,Time);
#endif

#endif

#if Runmain_each_solution_range
for (int a=0;a<solution_num;a++)
{sloution_name.push_back("HH_Solution("+double_to_str(3*OmegaStart)+"-"+double_to_str(3*OmegaFinal)+")w1_"+double_to_str(a)+"_"+double_to_str(Omega[0]));}
#else
for (int a=0;a<solution_num;a++)
{
if(Neuron_Type==2)
   {
      if (Strength_Change==1)
         {
          strength_name.push_back("Couple="+double_to_str(Couple[1][0]));

         }
    }
  sloution_name.push_back("HH_Solution_w1_"+double_to_str(3*Omega[0])+"_"+double_to_str(a));
}

#endif

//-------------------------------
/*for(unsigned int i=0;i<Couple.size();i++)
{
for (vector<double>::iterator iter=Couple[i].begin();iter !=Couple[i].end();++iter)
{
	cout<<*iter<<" ";
}
cout<<endl;
}
*/
//-------------------------------
    int Dimension;
    Dimension=y_0.size();
if (Choice_HH_Ori==0)
{
 cout<<" Now is running the Sine Input case! "<<endl;
 //Runge_Kutta4M(y_0,Omega,Tstart,N,h,y,T0,Couple,amp,voltagei_1_dt,mi_1_dt,hi_1_dt,ni_1_dt,Gi_1_dt,G1i_1_dt,qi_1_dt);
Runge_Kutta4M(y_0,Omega,Tstart,N,h,y,T0,Couple,amp,voltagei_dt,mi_dt,hi_dt,ni_dt,Gi_dt,G1i_dt,qi_dt);
}
else if (Choice_HH_Ori==1)
{
  cout<<" Now is running the Sine Input case! "<<endl;

   if(Caiyang==0)
   {
     Runge_Kutta4M(y_0,Omega,Tstart,N,h,y,T0,Couple,amp,voltageio_dt,mio_dt,hio_dt,nio_dt,Gio_dt,G1io_dt,qio_dt);
   }
   else if(Caiyang==1)
   {
      cout<<"The Sample_Step is : "<<Sample_Step<<endl;
      y.resize(N);
	  for (int j=0;j<N;j++)
		 {
		 	y[j].resize(Dimension);
		 }

		 y[0]=y_0;

       for(int ii=1;ii<N+1;ii++)
         {
           ModfyRunge_Kutta4M(y_0,Omega,Tstart,Sample_Step,h,y_temp,T0_convergence,Couple,amp,voltageio_dt,mio_dt,hio_dt,nio_dt,Gio_dt,G1io_dt,qio_dt);
           y[ii]=y_temp;
           y_0=y_temp;
           Tstart=T0_convergence;
         }
    }
}

// Record HH solution
HH_solution.resize(solution_num);
SpikeTime.resize(solution_num);
ISI1.resize(solution_num);;
ISIout.resize(solution_num);;

for (int Num=0;Num<solution_num;Num++)
{
#if POISSON_INPUT_USE
HH_solution[Num].resize(N);
SpikeTime[Num].resize(N);
#else
HH_solution[Num].resize(Length_NN);
SpikeTime[Num].resize(T0.size());
#endif
}

#if POISSON_INPUT_USE
for (int k=0;k<N;k++)
{

	for (int s_num=0;s_num<solution_num;s_num++)
		{

			HH_solution[s_num][k]=y[k][7*(s_num)];
      	        }

}
#else
for (int k=0;k<T0.size();k++)
{
	//SpikeTime[k]=y[k][0]-Vot_Threshold;//Vot_Threshold
	for (int s_num=0;s_num<solution_num;s_num++)
		{
           SpikeTime[s_num][k]=y[k][7*(s_num)]-Vot_Threshold;
        }

}
for (int k=0;k<Length_NN;k++)
{
    for (int s_num=0;s_num<solution_num;s_num++)
		{
           HH_solution[s_num][k]=y[k+1000000/Sample_Step][7*(s_num)];
		}

}
#endif

// save each solution of the HH system equation
#if Runmain_each_solution
for (int s_num=0;s_num<solution_num;s_num++)
{

  if(Neuron_Type==2)
   {
      if (Strength_Change==1)
         {
           save_solution_Strength(HH_solution[s_num],strength_name[s_num],sloution_name[s_num]);
         }
      else
        {
          save_solution(HH_solution[s_num],sloution_name[s_num]);
         }
    }
 else
   {
      save_solution(HH_solution[s_num],sloution_name[s_num]);
   }
}
#endif


while (!sloution_name.empty())
				{
					sloution_name.pop_back();
				}

FREE_1(HH_solution);
while (!strength_name.empty())
				{
					strength_name.pop_back();
				}
// The ISI of Two HH neurons
for (int Num=0;Num<solution_num;Num++)
{
   int i=0;
  for (unsigned int j=1;j<SpikeTime[Num].size();j++)
    {
      if(SpikeTime[Num][j]>=0 && SpikeTime[Num][j-1]<0)
        {
          ISI1[Num].push_back(T0[j]);
          i++;
        }
    }
   array[Num]=i;
}

for (int Num=0;Num<solution_num;Num++)
{
  int length_spike=0;
  if (array[Num]!=0)
    {
      length_spike=sizeof(array[Num]);
      for (int z=0;z<array[Num];z++)
         {
             if(z==0)
                 {
                    ISIout[Num].push_back(ISI1[Num][z]);
                 }
             else
                {
                    ISIout[Num].push_back(ISI1[Num][z]-ISI1[Num][z-1]);
                }
           }
    }
   else
      {
        ISIout[Num].resize(length_spike);
      }
}

FREE_1(SpikeTime);
//Two neurons model that the series use as Wolf_LE data
for (unsigned int k=0;k<Length_NN;k++)
{
out_y[k]=y[k+1000000/Sample_Step][0];
out_y2[k]=y[k+1000000/Sample_Step][7];
}
//************************* release the capacity
FREE_1(y);
FREE_2(T0);
//***************************
T0.clear();
return ISIout;
}


//*********************************************************************************************************

void Morris_Lecar_Solve2(int N,double Dt, vector<double> y_0, vector<double> Omega,vector<vector<double> >Couple,vector<double> amp, double *out_y,double *out_y2,int Length_NN)
{
double Tstart=0;
double h=Dt;
int solution_num;
vector<double> T0;
vector<vector<double> > y;
vector<double> y_temp;
double T0_convergence;
vector<double> SpikeTime;
vector<vector<double> > ML_solution;
vector<string> sloution_name;
double Time=1024;//convergence test ,the time evolution
double h_0=(double)1/1024;
double N_0;//convergence test ,the time evolution
N_0=Time/h_0;//convergence test ,the time evolution
int num_neuron_ML2 = Number_Exneuron + Number_Inneuron;
solution_num=num_neuron_ML2;
cout<<"solution_num is "<<solution_num<<endl;
cout<<endl;
cout<<endl;
cout<<"Now is running ML2 "<<endl;
cout<<endl;
cout<<"Convergence_Test_0 = "<<Convergence_Test_0<<endl;
cout<<"Vot_Threshold = "<<Vot_Threshold<<endl;
cout<<endl;
/*
#if Convergence_Test_0  //Test convergence of the single neuron program
double T0_convergence;
vector<double> y_convergence;
cout<<" Running Convergence Test "<<endl;

cout<<"Test Sine Convergence "<<endl;
cout<<endl;
Convergence_2(y_0,Omega,Tstart,N_0,h_0,y_convergence,T0_convergence,Couple,amp,Time);

#endif
*/

#if Runmain_each_solution_range
for (int a=0;a<solution_num;a++)
{sloution_name.push_back("ML_Solution("+double_to_str(OmegaStart)+"-"+double_to_str(OmegaFinal)+")w1_"+double_to_str(a)+"_"+double_to_str(Omega[0]));}
#else
for (int a=0;a<solution_num;a++)
{sloution_name.push_back("ML_Solution_w1_"+double_to_str(Omega[0])+"_"+double_to_str(a));}
#endif

cout<<" Now is running the Sine Input case! "<<endl;
//
cout   << "The Couple is: "<<endl;
			for(unsigned int i=0;i<Couple.size();i++)
				{
					for (vector<double>::iterator iter=Couple[i].begin();iter !=Couple[i].end();++iter)
						{
							cout<<*iter<<" ";
						}
							cout<<endl;
				}
//
    int Dimension;
    Dimension=y_0.size();

if(Caiyang==0)
    {
       MSystem_Morris_Lecar_RK4(y_0,Omega,Tstart,N,h,y,T0,Couple,amp,MLv0_mdt,MLw0_mdt,Gm0_dt,Mqqm0_dt);
    }
else if(Caiyang==1)
    {
        cout<<"The Sample_Step is : "<<Sample_Step<<endl;
        y.resize(N);
	  for (int j=0;j<N;j++)
		 {
		 	y[j].resize(Dimension);
		 }

		 y[0]=y_0;

       for(int ii=1;ii<N+1;ii++)
         {
           ModfyMSystem_Morris_Lecar_RK4(y_0,Omega,Tstart,Sample_Step,h,y_temp,T0_convergence,Couple,amp,MLv0_mdt,MLw0_mdt,Gm0_dt,Mqqm0_dt);
           y[ii]=y_temp;
           y_0=y_temp;
           Tstart=T0_convergence;
         }
    }

// Record HH solution
ML_solution.resize(solution_num);

for (int Num=0;Num<solution_num;Num++)
{

ML_solution[Num].resize(Length_NN);

}

SpikeTime.resize(T0.size());


for (int k=0;k<Length_NN;k++)
{
	//SpikeTime[k]=y[k][0]-Vot_Threshold;//Vot_Threshold
	for (int s_num=0;s_num<solution_num;s_num++)
		{
            ML_solution[s_num][k]=y[k+1000000/Sample_Step][4*(s_num)];
        }
           //out_y[k]=y[k][0];
}


// save each solution of the HH system equation
#if Runmain_each_solution
for (int s_num=0;s_num<solution_num;s_num++)
{save_solution(ML_solution[s_num],sloution_name[s_num]);}
#endif


while (!sloution_name.empty())
				{
					sloution_name.pop_back();
				}

FREE_1(ML_solution);
//Two neurons model that the series use as Wolf_LE data
for (unsigned int k=0;k< Length_NN;k++)
{
out_y[k]=y[k+1000000/Sample_Step][0];
out_y2[k]=y[k+1000000/Sample_Step][4];
}
//************************* release the capacity
FREE_1(y);
FREE_2(T0);
//***************************
T0.clear();
}

