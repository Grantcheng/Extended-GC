#include <iostream>
#include <cmath>
#include <iomanip>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <sstream>
#include <vector>
#include "HHconst.h"
#include "SHHfunction.h"
#include "THHfunciton.h"
#include "convergence.h"
#include "RK4.h"
#include "Lya_input.h"
#include "save.h"
#include "poisson_input.h"
#include "datainput.h"
#include "neuron.h"
#include "loop.h"
#include "Hermit_RootSearch.h"
#include "random.h"

using namespace std;

void save_solution(vector<double> DATA,string fname);

void spiking_time_Sin(vector<vector<double> > y_spike,int index,double Ta,double Tb,double &firing_time)
{
	double va=y_spike[index-1][0];
	 double dva = 0; // initialization
	
	//voltage_dt(index_neuron,t_evolution,gEa,gIa,va,dva);
            voltage_dt(Ta,y_spike[index-1],dva);
	
        double vb=y_spike[index][0];
	double dvb = 0; // initialization

	//voltage_dt(index_neuron,(t_evolution+Tb-Ta),gEb,gIb,vb,dvb);
         voltage_dt(Tb,y_spike[index],dvb);

	firing_time = root_search(hermit, Ta, Tb, va, vb, dva, dvb, root_acc);
}

void ISIJin(int N, double Dt,vector<double> y_0, vector<double> Omega,vector<vector<double> >Couple,vector<double> amp, double *out_y)
{
double Tstart=0;
//double h=0.01;
double h=Dt;
int solution_num=1;
//double h_0=pow(0.5,(14));// convergence test ,the time evolution,RK4 step
double h_0=(double)1/1024;
vector<double> SpikeTime;
vector<vector<double> > HH_solution;
vector<double> Compare_Th;
vector<double> T0;
vector<vector<double> > y;
vector<string> sloution_name;
double Time=1024;//convergence test ,the time evolution
double N_0;//convergence test ,the time evolution
N_0=Time/h_0;//convergence test ,the time evolution
int totalnum=1;
vector<double> ISI0_P; //Record the firetime
vector<double>  ISI_P; // Record the ISI
int num_neuron = Number_Exneuron + Number_Inneuron;

#if NumNeuron1
vector<double> ISI0;
vector<vector<double> > ISI;

cout<<"Convergence_Test_0 = "<<Convergence_Test_0<<endl;
cout<<"Vot_Threshold = "<<Vot_Threshold<<endl;
#if Convergence_Test_0  //Test convergence of the single neuron program
double T0_convergence;
vector<double> y_convergence;
cout<<" Running Convergence Test "<<endl;
#if POISSON_INPUT_USE
cout<<"Test Poisson Convergence "<<endl;
cout<<endl;
Convergence_P(y_0,Omega,Tstart,N_0,h_0,y_convergence,T0_convergence,Time);
#else
cout<<"Test Sine Convergence "<<endl;
cout<<endl;
Convergence_1(y_0,Omega,Tstart,N_0,h_0,y_convergence,T0_convergence,Time);
#endif
//return ISI;
#endif

#if Runmain_each_solution_range
for (int a=0;a<solution_num;a++)
{sloution_name.push_back("HH_Solution("+double_to_str(3*OmegaStart)+"-"+double_to_str(3*OmegaFinal)+")w1_"+double_to_str(a)+"_"+double_to_str(Omega[0]));}
#else
for (int a=0;a<solution_num;a++)
{sloution_name.push_back("HH_Solution_w1_"+double_to_str(3*Omega[0])+"_"+double_to_str(a));}
#endif

if (Choice_HH_Ori==0)
{
 #if POISSON_INPUT_USE

 srand(initial_seed);
	for( int i = 0; i < num_neuron; i++ )
	{
		initialseed_neuron[i] = (long) -rand();

		last_input[i] = -log(RANDOM(initialseed_neuron+i,ran_iy,ran_iv,i))/Rate_input;

	}

  cout<<" Now is running the Poisson Input case! "<<endl;
  Tstep=h;
 //Neuron_Solution(N,h,Tstart,Omega,y,y_0);
  y.resize(N);
  Neuron_Solution_ISIjin(N,h,Tstart,Omega,y,y_0,2);
 #else 
  cout<<" Now is running the Sine Input case! "<<endl;
  Runge_Kutta4(y_0,Omega,Tstart,N,h,y,T0,voltage_dt,m_dt,h_dt,n_dt,qq_dt);
 #endif
   
}
else if (Choice_HH_Ori==1)
{
 #if POISSON_INPUT_USE

 srand(initial_seed);
	for( int i = 0; i < num_neuron; i++ )
	{
		initialseed_neuron[i] = (long) -rand();

		last_input[i] = -log(RANDOM(initialseed_neuron+i,ran_iy,ran_iv,i))/Rate_input;

	}

 cout<<" Now is running the Poisson Input case! "<<endl;
 Tstep=h;
 //Neuron_Solution(N,h,Tstart,Omega,y,y_0);
 y.resize(N);
 Neuron_Solution_ISIjin(N,h,Tstart,Omega,y,y_0,2);
 #else 
 cout<<" Now is running the Sine Input case! "<<endl;
 Runge_Kutta4(y_0,Omega,Tstart,N,h,y,T0,voltageo_dt,mo_dt,ho_dt,no_dt,qqo_dt);
 #endif
}

HH_solution.resize(solution_num);
for (int Num=0;Num<solution_num;Num++)
{
#if POISSON_INPUT_USE
HH_solution[Num].resize(N);
#else
HH_solution[Num].resize(T0.size());
#endif
}
//***************************************************
#if POISSON_INPUT_USE
SpikeTime.resize(N);
#else
SpikeTime.resize(T0.size());
#endif
ISI.resize(1);

//int i=0;
#if POISSON_INPUT_USE
for (int k=0;k<N;k++)
{
	SpikeTime[k]=y[k][0]-Vot_Threshold;
	for (int s_num=0;s_num<solution_num;s_num++)
		{
			
			HH_solution[s_num][k]=y[k][s_num];
                        out_y[k]=y[k][s_num];
	
	    }
}
#else
for (int k=0;k<T0.size();k++)
{
	SpikeTime[k]=y[k][0]-Vot_Threshold;//Vot_Threshold
	for (int s_num=0;s_num<solution_num;s_num++)
		{
			
			HH_solution[s_num][k]=y[k][s_num];
                        out_y[k]=y[k][s_num];
	
	    }
}
#endif

// save each solution of the HH system equation
#if Runmain_each_solution
for (int s_num=0;s_num<solution_num;s_num++)
{save_solution(HH_solution[s_num],sloution_name[s_num]);}
#endif


while (!sloution_name.empty())
				{
					sloution_name.pop_back();
				}

FREE_1(HH_solution);
//*************************************************************************************************************
// Compute ISI and Save ISI
int compute_ISI_HH=0;

//*************Save ISI**********

if(compute_ISI_HH==1)
{
double firing_time = 0;
vector<double>f_omega;
//*********************************************************************************************
string ISI_fname="ISI("+double_to_str(OmegaStart)+"_"+double_to_str(OmegaFinal)+")";
string ISI_f_fname="ISI("+double_to_str(OmegaStart)+"_"+double_to_str(OmegaFinal)+")_f";	
//********************************************************************************************	
#if POISSON_INPUT_USE  

  save_f(ISI_P,ISI_fname);
  save_f(f_omega,ISI_f_fname);

#else	
int spike_i=0;
for (int j=1;j<SpikeTime.size();j++)
{
	/*
      if (SpikeTime[j]>=0 && SpikeTime[j-1]<0)
	{
		ISI0.push_back(T0[j]);
		i++;
	}
       */
if ((SpikeTime[j]>=0) &&(SpikeTime[j-1]<0) )
{
spiking_time_Sin(y,j,T0[j-1],T0[j],firing_time);//(double va,double vot_cross,double Ta,double Tb,double &firing_time)
ISI0.push_back(firing_time);
spike_i++;
}

}

for(int z=0; z<spike_i;z++)
{
	if(z==0)
	{
		ISI[0].push_back(ISI0[z]);
	}
	else
        {
	        ISI[0].push_back(ISI0[z]-ISI0[z-1]);
        }
}
//return ISI;
  save(ISI,ISI_fname);
  save_f(f_omega,ISI_f_fname);
#endif

}

//*******************************
#else
//-------------------------------
for(unsigned int i=0;i<Couple.size();i++)
{
for (vector<double>::iterator iter=Couple[i].begin();iter !=Couple[i].end();++iter)
{
	cout<<*iter<<" ";
}
cout<<endl;
}
//-------------------------------
#if Convergence_Test  //Test convergence of the multipe neurons program

double T0_convergence;
vector<double> y_convergence;
vector<vector<double> > ISI;
Convergence_2(y_0,Omega,Tstart,N_0,h_0,y_convergence,T0_convergence,Couple,amp,Time);
return ISI;
//
#endif
for(int k=0;k<NumNeuron;k++)
{sloution_name.push_back("HH_Solution"+double_to_str(k)+"w1_"+double_to_str(Omega[0])+"_w2"+double_to_str(Omega[1]));}

Runge_Kutta4M(y_0,Omega,Tstart,N,h,y,T0,Couple,amp,voltagei_1_dt,mi_1_dt,hi_1_dt,ni_1_dt,Gi_1_dt,G1i_1_dt,qi_1_dt);

// use it to obtain two neurons ISI
/* 
vector<vector<double> > SpikeTime1;
vector<vector<double> > Double_HH_Solution;
vector<vector<double> >  ISI1;
vector<vector<double> >  ISIout;
int array[NumNeuron];
Double_HH_Solution.resize(NumNeuron);
SpikeTime1.resize(NumNeuron);
ISI1.resize(NumNeuron);
ISIout.resize(NumNeuron);
for (int Num=0;Num<NumNeuron;Num++)
{
SpikeTime1[Num].resize(T0.size());
Double_HH_Solution[Num].resize(T0.size());
}

for (int Num=0;Num<NumNeuron;Num++)
{
for (unsigned int k=0;k< T0.size();k++)
{
	SpikeTime1[Num][k]=y[k][Num*7]-Vot_Threshold;
	Double_HH_Solution[Num][k]=y[k][Num*7];
        

}
}
*/
// use as Wolf_LE data
for (unsigned int k=0;k< T0.size();k++)
{
out_y[k]=y[k][7];
}


//********** save HH solution
/*	
for (int k=0;k<NumNeuron;k++)
		 {
			save_solution(Double_HH_Solution[k],sloution_name[k]);
			}
//****************************release the solution_name
				while (!sloution_name.empty())
				{
					sloution_name.pop_back();
				}
				//***********************************************************

for (int Num=0;Num<NumNeuron;Num++)
{ int i=0;
for (unsigned int j=1;j<SpikeTime1[Num].size();j++)
{
	
	if (SpikeTime1[Num][j]>=0 && SpikeTime1[Num][j-1]<0)
	{
		ISI1[Num].push_back(T0[j]);
		i++;
	}
	
}
array[Num]=i;
}

for (int Num=0;Num<NumNeuron;Num++)
{ int length=0;
	if (array[Num]!=0)
	{  length=sizeof(array[Num]);
		for(int z=0; z<array[Num];z++){
			if(z==0)
					{
							ISIout[Num].push_back(ISI1[Num][z]);
					}

			else
					{
							ISIout[Num].push_back(ISI1[Num][z]-ISI1[Num][z-1]);
					}
										}
	}
	else
	{ISIout[Num].resize(length);}
}
*/
//************************* release the capacity
FREE_1(y);
//FREE_1(SpikeTime1);
FREE_2(T0);
FREE_2(SpikeTime);
//***************************

//return ISIout;
#endif
FREE_1(y);
FREE_2(T0);
T0.clear();
}

