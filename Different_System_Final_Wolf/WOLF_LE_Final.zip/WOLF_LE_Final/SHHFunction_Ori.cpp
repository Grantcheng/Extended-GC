#include <cstdlib>
#include <vector>
#include <string>
#include <iostream>
#include<cmath>
#include<iomanip>
#include"HHconst.h"
#include"SHHfunction.h"

using namespace std;

    double vv;
    double alphan1o,betan1o,alpham1o,betam1o,alphah1o,betah1o;
	
void voltageo_dt(double t,vector<double> y,double &dv_dt)
{
	//cout<<setprecision(16)<<y[4]<<endl;
	
	//system("pause");
	//cout<<"after fmod "<<y[4]<<endl;
dv_dt=(amp1+sin(2*pi*y[4]))-(g_na_max*(pow(y[1],3))*y[2]*(y[0]-50) + g_k_max*(pow(y[3],4))*(y[0]+77) + g_l*(y[0]+54.387)); 
}

void mo_dt(double t,double y_0, double y_1, double &dm_dt)
{
	vv=y_0;
	//m channel
        alpham1o=0.1*(vv+40)/(1-exp(-(vv+40)/10));
	      
	betam1o=4*exp(-(vv+65)/18);
	dm_dt=(alpham1o-(alpham1o+betam1o)*y_1);
}

void ho_dt(double t,double y_0, double y_2, double &dh_dt)
{
	vv=y_0;
	//h channel
	alphah1o=0.07*exp(-(vv+65)/20);
	betah1o=1/(exp(-(vv+35)/10)+1);

	dh_dt=(alphah1o-(alphah1o+betah1o)*y_2);
}

void no_dt(double t,double y_0, double y_3,double &dn_dt)
	{
	vv=y_0;
	//n channel
	alphan1o=0.01*(vv+55)/(1-exp(-(vv+55)/10));
	
	betan1o=0.125*exp(-(vv+65)/80);
	dn_dt=(alphan1o-(alphan1o+betan1o)*y_3);

	}

void qqo_dt(double t,double Omega, double &dqq_dt)
	{   
		dqq_dt=Omega;
	}
