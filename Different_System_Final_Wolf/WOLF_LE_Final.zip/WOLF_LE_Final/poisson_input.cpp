#include <iostream>
#include <cmath>
#include <iomanip>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <sstream>
#include <vector>
#include "HHconst.h"
#include "SHHfunction.h"
#include "poisson_input.h"
#include "save.h"
#include "neuron.h"
#include "loop.h"
#include "datainput.h"
#include "Hermit_RootSearch.h"

using namespace std;


int ISI_SAVE=0;
vector<double> ISI0_P; //Record the firetime
vector<double>  ISI_P; // Record the ISI

// only use excitatory conductance and inhibitory conductance: GE and GI
void force_input( neuron *tempneu, int index_neuron)
{
#if Autonomy_Use
	tempneu[index_neuron].value[5] += Strength_Exinput*2.0/(Time_ExCon); // excitatory conductance
	
	tempneu[index_neuron].value[Stepsmooth_Con+5] += Strength_Ininput*5.0/(Time_InCon); // inhibitory conductance
#else
	tempneu[index_neuron].value[4] += Strength_Exinput*2.0/(Time_ExCon); // excitatory conductance
	
	tempneu[index_neuron].value[Stepsmooth_Con+4] += Strength_Ininput*5.0/(Time_InCon); // inhibitory conductance
#endif


};


// use smooth conductance HE and HI
void force_inputR( neuron *tempneu, int index_neuron)
{
#if Autonomy_Use
	tempneu[index_neuron].value[Stepsmooth_Con+4] += Strength_Exinput; // excitatory conductance
	
	tempneu[index_neuron].value[2*Stepsmooth_Con+4] += Strength_Ininput; // inhibitory conductance
#else
	tempneu[index_neuron].value[Stepsmooth_Con+3] += Strength_Exinput; // excitatory conductance
	
	tempneu[index_neuron].value[2*Stepsmooth_Con+3] += Strength_Ininput; // inhibitory conductance
#endif
};


// use non-smooth conductance
void conductance_decay( neuron *tempneu, int index_neuron, double subTstep)
{
#if Autonomy_Use
//*******************************renew the Excitatory conductance*******************************************  
	// renew the ex-conductance with non-smooth
	tempneu[index_neuron].value[5] = tempneu[index_neuron].value[5]*exp(-subTstep/Time_ExCon);
								 
//*************************renew the Inhibitory conductance************************************************* 
	// renew the in-conductance with non-smooth
	tempneu[index_neuron].value[Stepsmooth_Con+5] = tempneu[index_neuron].value[Stepsmooth_Con+5]*exp(-subTstep/Time_InCon);
#else
            tempneu[index_neuron].value[4] = tempneu[index_neuron].value[4]*exp(-subTstep/Time_ExCon);
            tempneu[index_neuron].value[Stepsmooth_Con+4] = tempneu[index_neuron].value[Stepsmooth_Con+4]*exp(-subTstep/Time_InCon);
#endif
};


// use smooth conductance
void conductance_evolve( neuron *tempneu, int index_neuron, double subTstep)
{
#if Autonomy_Use
//*********************************renew the Excitatory conductance***************************************
      // renew the ex-conductance with highest smoothness
	tempneu[index_neuron].value[Stepsmooth_Con+3] = tempneu[index_neuron].value[Stepsmooth_Con+3]*exp(-subTstep/Time_ExCon)
		+1.0*Time_ExCon*Time_ExConR/(Time_ExConR-Time_ExCon)*(exp(-subTstep/Time_ExConR) - exp(-subTstep/Time_ExCon))*tempneu[index_neuron].value[Stepsmooth_Con+4];
	
	tempneu[index_neuron].value[Stepsmooth_Con+4] = tempneu[index_neuron].value[Stepsmooth_Con+4]*exp(-subTstep/Time_ExConR);

//**********************************renew the Inhibitory conductance************************************** 
	// renew the in-conductance with highest smoothness
	tempneu[index_neuron].value[Stepsmooth_Con+5] = tempneu[index_neuron].value[Stepsmooth_Con+5]*exp(-subTstep/Time_InCon)
		+1.0*Time_InCon*Time_InConR/(Time_InConR-Time_InCon)*(exp(-subTstep/Time_InConR) - exp(-subTstep/Time_InCon))*tempneu[index_neuron].value[2*Stepsmooth_Con+4];

	tempneu[index_neuron].value[2*Stepsmooth_Con+4] = tempneu[index_neuron].value[2*Stepsmooth_Con+4]*exp(-subTstep/Time_InConR);
#else
//*********************************renew the Excitatory conductance***************************************
         tempneu[index_neuron].value[Stepsmooth_Con+2] = tempneu[index_neuron].value[Stepsmooth_Con+2]*exp(-subTstep/Time_ExCon)
		+1.0*Time_ExCon*Time_ExConR/(Time_ExConR-Time_ExCon)*(exp(-subTstep/Time_ExConR) - exp(-subTstep/Time_ExCon))*tempneu[index_neuron].value[Stepsmooth_Con+3];
	
	tempneu[index_neuron].value[Stepsmooth_Con+3] = tempneu[index_neuron].value[Stepsmooth_Con+3]*exp(-subTstep/Time_ExConR);
//**********************************renew the Inhibitory conductance************************************** 
        tempneu[index_neuron].value[Stepsmooth_Con+4] = tempneu[index_neuron].value[Stepsmooth_Con+4]*exp(-subTstep/Time_InCon)
		+1.0*Time_InCon*Time_InConR/(Time_InConR-Time_InCon)*(exp(-subTstep/Time_InConR) - exp(-subTstep/Time_InCon))*tempneu[index_neuron].value[2*Stepsmooth_Con+3];

	tempneu[index_neuron].value[2*Stepsmooth_Con+3] = tempneu[index_neuron].value[2*Stepsmooth_Con+3]*exp(-subTstep/Time_InConR);
#endif
};

/*
void runge_kutta4(neuron *tempneu, int index_neuron, double subTstep,double t_evolution,vector<vector<double> >  &y,
        void (*dvdt)(double t,vector<double> y,double gE, double gI,double &dv_dt),
	void (*dmdt)(double t,double y_0, double y_1, double &dm_dt),
	void (*dhdt)(double t,double y_0, double y_2, double &dh_dt),
	void (*dndt)(double t,double y_0, double y_3,double &dn_dt))
*/

#if Autonomy_Use
void runge_kutta4(neuron *tempneu, int index_neuron, double subTstep,double t_evolution,vector<double> Omega,vector<double> &y,
		  void (*voltage_p_dt)(double t,vector<double> y,double gE, double gI,double &dv_dt),
	          void (*m_p_dt)(double t,double y_0, double y_1, double &dm_dt),
	          void (*h_p_dt)(double t,double y_0, double y_2, double &dh_dt),
	          void (*n_p_dt)(double t,double y_0, double y_3,double &dn_dt),
                  void (*q_p_dt)(double t,double Omega, double &dq_dt))
{
#if SMOOTH_CONDUCTANCE_USE
        vector<double>  temp(9);
	vector<double>  k1(9); 
	vector<double>  k2(9); 
	vector<double>  k3(9); 
	vector<double>  k4(9); 
        
	double *m1;
        double *m2;
        double *m3;
        double *m4;

	m1=(double *)malloc(9*sizeof(double));
        m2=(double *)malloc(9*sizeof(double));
        m3=(double *)malloc(9*sizeof(double));
        m4=(double *)malloc(9*sizeof(double));

        y.resize(9);// five solutions:v,m,n,h,q,g_e,g_i
        for (int i=0;i<9;i++)
        {
          y[i]=tempneu[index_neuron].value[i];// input the initial values y0 to the y
	}
        double newstep = subTstep; // time step needs to be changed for awaken neuron              
		 
		double g_E0 = tempneu[index_neuron].value[5]*exp((newstep-subTstep)/Time_ExCon)
			+ 1.0*Time_ExCon*Time_ExConR/(Time_ExConR-Time_ExCon)
			   *(exp((newstep-subTstep)/Time_ExConR) - exp((newstep-subTstep)/Time_ExCon))
			   *tempneu[index_neuron].value[4+Stepsmooth_Con];
		double H_E0 = tempneu[index_neuron].value[4+Stepsmooth_Con]*exp((newstep-subTstep)/Time_ExConR);

		double g_I0 = tempneu[index_neuron].value[5+Stepsmooth_Con]*exp((newstep-subTstep)/Time_InCon)
			+ 1.0*Time_InCon*Time_InConR/(Time_InConR-Time_InCon)
			   *(exp((newstep-subTstep)/Time_InConR) - exp((newstep-subTstep)/Time_InCon))
			   *tempneu[index_neuron].value[2*Stepsmooth_Con+4];
		double H_I0 = tempneu[index_neuron].value[2*Stepsmooth_Con+4]*exp((newstep-subTstep)/Time_InConR);

		double g_E1 = g_E0*exp(-newstep/2/Time_ExCon)
			+ 1.0*Time_ExCon*Time_ExConR/(Time_ExConR-Time_ExCon)
			   *(exp(-newstep/2/Time_ExConR) - exp(-newstep/2/Time_ExCon))*H_E0;
		double g_I1 = g_I0*exp(-newstep/2/Time_InCon)
			+ 1.0*Time_InCon*Time_InConR/(Time_InConR-Time_InCon)
			   *(exp(-newstep/2/Time_InConR) - exp(-newstep/2/Time_InCon))*H_I0;

		double g_E2 = g_E0*exp(-newstep/Time_ExCon)
			+ 1.0*Time_ExCon*Time_ExConR/(Time_ExConR-Time_ExCon)
			   *(exp(-newstep/Time_ExConR) - exp(-newstep/Time_ExCon))*H_E0;
		double g_I2 = g_I0*exp(-newstep/Time_InCon)
			+ 1.0*Time_InCon*Time_InConR/(Time_InConR-Time_InCon)
			   *(exp(-newstep/Time_InConR) - exp(-newstep/Time_InCon))*H_I0;
              
#else

        vector<double>  temp(7);
	vector<double>  k1(7); 
	vector<double>  k2(7); 
	vector<double>  k3(7); 
	vector<double>  k4(7); 
        
	double *m1;
        double *m2;
        double *m3;
        double *m4;

	m1=(double *)malloc(7*sizeof(double));
        m2=(double *)malloc(7*sizeof(double));
        m3=(double *)malloc(7*sizeof(double));
        m4=(double *)malloc(7*sizeof(double));

        y.resize(7);// five solutions:v,m,n,h,q,g_e,g_i
        for (int i=0;i<7;i++)
        {
          y[i]=tempneu[index_neuron].value[i];// input the initial values y0 to the y
	}
        double newstep = subTstep; // time step needs to be changed for awaken neuron
          
		double g_E0 = tempneu[index_neuron].value[5]*exp((newstep-subTstep)/Time_ExCon);
		double g_I0 = tempneu[index_neuron].value[Stepsmooth_Con+4]*exp((newstep-subTstep)/Time_InCon);
		double g_E1 = g_E0*exp(-newstep/2/Time_ExCon);
		double g_I1 = g_I0*exp(-newstep/2/Time_InCon);
		double g_E2 = g_E0*exp(-newstep/Time_ExCon);
		double g_I2 = g_I0*exp(-newstep/Time_InCon);
         
#endif

		double ini_time = t_evolution;
		double two_fourth_time = t_evolution+newstep/2;
		double end_time = t_evolution+newstep;

                if (y[4]>1)
			y[4]=fmod(y[4],1);

                 	// void (*dvdt)(double t,vector<double> y,double gE, double gI,double &dv_dt),
			(*voltage_p_dt)(ini_time,y,g_E0, g_I0,m1[0]);
			//(*dmdt)(double t,double y_0, double y_1, double &dm_dt)
			(*m_p_dt)(ini_time ,y[0],y[1],m1[1]);
			//void (*dhdt)(double t,double y_0, double y_2, double &dh_dt)
	                (*h_p_dt)(ini_time ,y[0],y[2],m1[2]);
			//(*dndt)(double t,double y_0, double y_3,double &dn_dt)
			(*n_p_dt)(ini_time ,y[0],y[3],m1[3]);
			//(*dqdt)(double t,double Omega, double &dq_dt)
	                (*q_p_dt)(ini_time ,Omega[0], m1[4]);
			//assign the m11,m12,m13,m14 to k1
                        k1[0]=m1[0];
			k1[1]=m1[1];
			k1[2]=m1[2];
			k1[3]=m1[3];
			k1[4]=m1[4];

                         // k2 = f(t(n)+h/2, y(n)+k1*h/2)
 
			for(int a=0;a<5;a++)
			{
				temp[a]=0.5*newstep*k1[a]+y[a];
			}
			
                        (*voltage_p_dt)(two_fourth_time,temp,g_E1,g_I1,m2[0]);
			(*m_p_dt)(two_fourth_time,temp[0],temp[1],m2[1]);
	                (*h_p_dt)(two_fourth_time,temp[0],temp[2],m2[2]);
			(*n_p_dt)(two_fourth_time,temp[0],temp[3],m2[3]);
	                (*q_p_dt)(two_fourth_time,Omega[0], m2[4]);
   
			k2[0]=m2[0];
			k2[1]=m2[1];
			k2[2]=m2[2];
			k2[3]=m2[3];
			k2[4]=m2[4];
			// k3 = f(t(n)+h/2, y(n)+k2*h/2)
			for(int a=0;a<5;a++)
			{
				temp[a]=0.5*newstep*k2[a]+y[a];
			}

			(*voltage_p_dt)(two_fourth_time,temp,g_E1,g_I1,m3[0]);
			(*m_p_dt)(two_fourth_time,temp[0],temp[1],m3[1]);
	                (*h_p_dt)(two_fourth_time,temp[0],temp[2],m3[2]);
			(*n_p_dt)(two_fourth_time,temp[0],temp[3],m3[3]);
	                (*q_p_dt)(two_fourth_time,Omega[0], m3[4]);

			k3[0]=m3[0];
			k3[1]=m3[1];
			k3[2]=m3[2];
			k3[3]=m3[3];
			k3[4]=m3[4];

			// k4 = f(t(n)+h, y(n)+k3*h)
			for(int a=0;a<5;a++)
			{
				temp[a]=newstep*k3[a]+y[a];
			}

			(*voltage_p_dt)(end_time,temp,g_E2,g_I2,m4[0]);
			(*m_p_dt)(end_time,temp[0],temp[1],m4[1]);
	                (*h_p_dt)(end_time,temp[0],temp[2],m4[2]);
			(*n_p_dt)(end_time,temp[0],temp[3],m4[3]);
	                (*q_p_dt)(end_time,Omega[0], m4[4]);

			k4[0]=m4[0];
			k4[1]=m4[1];
			k4[2]=m4[2];
			k4[3]=m4[3];
			k4[4]=m4[4];
			//The solution value
			
			for(int i=0;i<5;i++)
			{
				y[i]=y[i]+(newstep/6)*(k1[i]+2*k2[i]+2*k3[i]+k4[i]);
			}
//*********************** Release memory******************
   free(m1);
   free(m2);
   free(m3);
   free(m4);
    
};

 # else
void runge_kutta4(neuron *tempneu, int index_neuron, double subTstep,double t_evolution,vector<double> Omega,vector<double> &y,
		  void (*voltage_p_non_dt)(double t,vector<double> y,double Omega_1,double gE, double gI,double &dv_dt),
	          void (*m_p_dt)(double t,double y_0, double y_1, double &dm_dt),
	          void (*h_p_dt)(double t,double y_0, double y_2, double &dh_dt),
	          void (*n_p_dt)(double t,double y_0, double y_3,double &dn_dt))
{
#if SMOOTH_CONDUCTANCE_USE
        vector<double>  temp(8);
	vector<double>  k1(8); 
	vector<double>  k2(8); 
	vector<double>  k3(8); 
	vector<double>  k4(8); 
        
	double *m1;
        double *m2;
        double *m3;
        double *m4;

	m1=(double *)malloc(8*sizeof(double));
        m2=(double *)malloc(8*sizeof(double));
        m3=(double *)malloc(8*sizeof(double));
        m4=(double *)malloc(8*sizeof(double));

        y.resize(8);// five solutions:v,m,n,h,g_e,g_i
        for (int i=0;i<8;i++)
        {
          y[i]=tempneu[index_neuron].value[i];// input the initial values y0 to the y
	}
        double newstep = subTstep; // time step needs to be changed for awaken neuron


               double g_E0 = tempneu[index_neuron].value[4]*exp((newstep-subTstep)/Time_ExCon)
			+ 1.0*Time_ExCon*Time_ExConR/(Time_ExConR-Time_ExCon)
			   *(exp((newstep-subTstep)/Time_ExConR) - exp((newstep-subTstep)/Time_ExCon))
			   *tempneu[index_neuron].value[3+Stepsmooth_Con];
		double H_E0 = tempneu[index_neuron].value[3+Stepsmooth_Con]*exp((newstep-subTstep)/Time_ExConR);

		double g_I0 = tempneu[index_neuron].value[4+Stepsmooth_Con]*exp((newstep-subTstep)/Time_InCon)
			+ 1.0*Time_InCon*Time_InConR/(Time_InConR-Time_InCon)
			   *(exp((newstep-subTstep)/Time_InConR) - exp((newstep-subTstep)/Time_InCon))
			   *tempneu[index_neuron].value[2*Stepsmooth_Con+3];
		double H_I0 = tempneu[index_neuron].value[2*Stepsmooth_Con+3]*exp((newstep-subTstep)/Time_InConR);

		double g_E1 = g_E0*exp(-newstep/2/Time_ExCon)
			+ 1.0*Time_ExCon*Time_ExConR/(Time_ExConR-Time_ExCon)
			   *(exp(-newstep/2/Time_ExConR) - exp(-newstep/2/Time_ExCon))*H_E0;
		double g_I1 = g_I0*exp(-newstep/2/Time_InCon)
			+ 1.0*Time_InCon*Time_InConR/(Time_InConR-Time_InCon)
			   *(exp(-newstep/2/Time_InConR) - exp(-newstep/2/Time_InCon))*H_I0;

		double g_E2 = g_E0*exp(-newstep/Time_ExCon)
			+ 1.0*Time_ExCon*Time_ExConR/(Time_ExConR-Time_ExCon)
			   *(exp(-newstep/Time_ExConR) - exp(-newstep/Time_ExCon))*H_E0;
		double g_I2 = g_I0*exp(-newstep/Time_InCon)
			+ 1.0*Time_InCon*Time_InConR/(Time_InConR-Time_InCon)
			   *(exp(-newstep/Time_InConR) - exp(-newstep/Time_InCon))*H_I0;

# else
        vector<double>  temp(6);
	vector<double>  k1(6); 
	vector<double>  k2(6); 
	vector<double>  k3(6); 
	vector<double>  k4(6); 
        
	double *m1;
        double *m2;
        double *m3;
        double *m4;

	m1=(double *)malloc(6*sizeof(double));
        m2=(double *)malloc(6*sizeof(double));
        m3=(double *)malloc(6*sizeof(double));
        m4=(double *)malloc(6*sizeof(double));

        y.resize(6);// five solutions:v,m,n,h,g_e,g_i
        for (int i=0;i<6;i++)
        {
          y[i]=tempneu[index_neuron].value[i];// input the initial values y0 to the y
	}
                double newstep = subTstep; // time step needs to be changed for awaken neuron
                double g_E0 = tempneu[index_neuron].value[4]*exp((newstep-subTstep)/Time_ExCon);
		double g_I0 = tempneu[index_neuron].value[Stepsmooth_Con+3]*exp((newstep-subTstep)/Time_InCon);
		double g_E1 = g_E0*exp(-newstep/2/Time_ExCon);
		double g_I1 = g_I0*exp(-newstep/2/Time_InCon);
		double g_E2 = g_E0*exp(-newstep/Time_ExCon);
		double g_I2 = g_I0*exp(-newstep/Time_InCon);
     
#endif
                double ini_time = t_evolution + (subTstep - newstep);
		double two_fourth_time = t_evolution + (subTstep - newstep) + newstep/2;
		double end_time = t_evolution + (subTstep - newstep) + newstep;



                 	// void (*dvdt)(double t,vector<double> y,double gE, double gI,double &dv_dt),
			(*voltage_p_non_dt)(ini_time ,y,Omega[0],g_E0, g_I0,m1[0]);
			//(*dmdt)(double t,double y_0, double y_1, double &dm_dt)
			(*m_p_dt)(ini_time ,y[0],y[1],m1[1]);
			//void (*dhdt)(double t,double y_0, double y_2, double &dh_dt)
	                (*h_p_dt)(ini_time ,y[0],y[2],m1[2]);
			//(*dndt)(double t,double y_0, double y_3,double &dn_dt)
			(*n_p_dt)(ini_time ,y[0],y[3],m1[3]);
			//(*dqdt)(double t,double Omega, double &dq_dt)
	               
                        k1[0]=m1[0];
			k1[1]=m1[1];
			k1[2]=m1[2];
			k1[3]=m1[3];
			

                         // k2 = f(t(n)+h/2, y(n)+k1*h/2)
 
			for(int a=0;a<4;a++)
			{
				temp[a]=0.5*newstep*k1[a]+y[a];
			}
			
                        (*voltage_p_non_dt)(two_fourth_time,temp,Omega[0],g_E1,g_I1,m2[0]);
			(*m_p_dt)(two_fourth_time,temp[0],temp[1],m2[1]);
	                (*h_p_dt)(two_fourth_time,temp[0],temp[2],m2[2]);
			(*n_p_dt)(two_fourth_time,temp[0],temp[3],m2[3]);
	              
   
			k2[0]=m2[0];
			k2[1]=m2[1];
			k2[2]=m2[2];
			k2[3]=m2[3];
			
			// k3 = f(t(n)+h/2, y(n)+k2*h/2)
			for(int a=0;a<4;a++)
			{
				temp[a]=0.5*newstep*k2[a]+y[a];
			}

			(*voltage_p_non_dt)(two_fourth_time,temp,Omega[0],g_E1,g_I1,m3[0]);
			(*m_p_dt)(two_fourth_time,temp[0],temp[1],m3[1]);
	                (*h_p_dt)(two_fourth_time,temp[0],temp[2],m3[2]);
			(*n_p_dt)(two_fourth_time,temp[0],temp[3],m3[3]);
	               

			k3[0]=m3[0];
			k3[1]=m3[1];
			k3[2]=m3[2];
			k3[3]=m3[3];
			

			// k4 = f(t(n)+h, y(n)+k3*h)
			for(int a=0;a<4;a++)
			{
				temp[a]=newstep*k3[a]+y[a];
			}

			(*voltage_p_non_dt)(end_time,temp,Omega[0],g_E2,g_I2,m4[0]);
			(*m_p_dt)(end_time,temp[0],temp[1],m4[1]);
	                (*h_p_dt)(end_time,temp[0],temp[2],m4[2]);
			(*n_p_dt)(end_time,temp[0],temp[3],m4[3]);
	             

			k4[0]=m4[0];
			k4[1]=m4[1];
			k4[2]=m4[2];
			k4[3]=m4[3];
			
			//The solution value
			
			for(int i=0;i<4;i++)
			{
				y[i]=y[i]+(newstep/6)*(k1[i]+2*k2[i]+2*k3[i]+k4[i]);
			}
  //*********************** Release memory******************
   free(m1);
   free(m2);
   free(m3);
   free(m4);
                                
};
#endif  

//****************************************************************************************************************************
#if Autonomy_Use
void runge_kutta4_whole(neuron *tempneu, int index_neuron, double subTstep,double t_evolution,vector<double> Omega,vector<double> &y,
		  void (*voltage_p_dt)(double t,vector<double> y,double gE, double gI,double &dv_dt),
	          void (*m_p_dt)(double t,double y_0, double y_1, double &dm_dt),
	          void (*h_p_dt)(double t,double y_0, double y_2, double &dh_dt),
	          void (*n_p_dt)(double t,double y_0, double y_3,double &dn_dt),
                  void (*q_p_dt)(double t,double Omega, double &dq_dt))
{
#if SMOOTH_CONDUCTANCE_USE
	int j=0;
        double subbegin_time;
	double subend_time; // record the middle point of poisson input!
	double sub_tstep;
        vector<double>  temp(9);
	vector<double>  k1(9); 
	vector<double>  k2(9); 
	vector<double>  k3(9); 
	vector<double>  k4(9); 
        
	double *m1;
        double *m2;
        double *m3;
        double *m4;

	m1=(double *)malloc(9*sizeof(double));
        m2=(double *)malloc(9*sizeof(double));
        m3=(double *)malloc(9*sizeof(double));
        m4=(double *)malloc(9*sizeof(double));

        y.resize(9);// five solutions:v,m,n,h,q,g_e,g_i
        for (int i=0;i<9;i++)
        {
          y[i]=tempneu[index_neuron].value[i];// input the initial values y0 to the y
	}
        double newstep = subTstep; // time step needs to be changed for awaken neuron              


		double g_E0 = tempneu[index_neuron].value[5]*exp((newstep-subTstep)/Time_ExCon)
			+ 1.0*Time_ExCon*Time_ExConR/(Time_ExConR-Time_ExCon)
			   *(exp((newstep-subTstep)/Time_ExConR) - exp((newstep-subTstep)/Time_ExCon))
			   *tempneu[index_neuron].value[4+Stepsmooth_Con];
		double H_E0 = tempneu[index_neuron].value[4+Stepsmooth_Con]*exp((newstep-subTstep)/Time_ExConR);

		double g_I0 = tempneu[index_neuron].value[5+Stepsmooth_Con]*exp((newstep-subTstep)/Time_InCon)
			+ 1.0*Time_InCon*Time_InConR/(Time_InConR-Time_InCon)
			   *(exp((newstep-subTstep)/Time_InConR) - exp((newstep-subTstep)/Time_InCon))
			   *tempneu[index_neuron].value[2*Stepsmooth_Con+4];
		double H_I0 = tempneu[index_neuron].value[2*Stepsmooth_Con+4]*exp((newstep-subTstep)/Time_InConR);
//***************************************************************************************************
// The conductance at two_fourth_time 
      subbegin_time=0;
	while ((j<poisson_input[index_neuron].vect_size) 
			&& (poisson_input[index_neuron].vect_value[j]<=newstep/2))
		{			

                               subend_time = poisson_input[index_neuron].vect_value[j];
		               sub_tstep = subend_time - subbegin_time;

				conductance_evolve(tempneu, index_neuron, sub_tstep);
				force_inputR(tempneu, index_neuron);	
                      j++;
                    subbegin_time=subend_time;
		} // end of while (for poisson spikes)

		// finish the last sub-interval!
		
		sub_tstep = newstep/2.0 - subbegin_time;

				conductance_evolve(tempneu, index_neuron, sub_tstep);

		double g_E1 = tempneu[index_neuron].value[5];
		double g_I1 = tempneu[index_neuron].value[7];
//***************************************************************************************************
// The conductance at end_time
		subbegin_time=newstep/2.0;
		while ((j<poisson_input[index_neuron].vect_size) 
			&& (poisson_input[index_neuron].vect_value[j]<=newstep)&&(poisson_input[index_neuron].vect_value[j]>newstep/2))
		{			

                               subend_time = poisson_input[index_neuron].vect_value[j];
		               sub_tstep = subend_time - subbegin_time;

				conductance_evolve(tempneu, index_neuron, sub_tstep);
				force_inputR(tempneu, index_neuron);

                      j++;
                    subbegin_time=subend_time;
		} // end of while (for poisson spikes)

		// finish the last sub-interval!
		
		sub_tstep = newstep- subbegin_time;

				conductance_evolve(tempneu, index_neuron, sub_tstep);

		double g_E2 = tempneu[index_neuron].value[5];
		double g_I2 = tempneu[index_neuron].value[7];
              
#else

        vector<double>  temp(7);
	vector<double>  k1(7); 
	vector<double>  k2(7); 
	vector<double>  k3(7); 
	vector<double>  k4(7); 
        
	double *m1;
        double *m2;
        double *m3;
        double *m4;

	m1=(double *)malloc(7*sizeof(double));
        m2=(double *)malloc(7*sizeof(double));
        m3=(double *)malloc(7*sizeof(double));
        m4=(double *)malloc(7*sizeof(double));

        y.resize(7);// five solutions:v,m,n,h,q,g_e,g_i
        for (int i=0;i<7;i++)
        {
          y[i]=tempneu[index_neuron].value[i];// input the initial values y0 to the y
	}
        double newstep = subTstep; // time step needs to be changed for awaken neuron
          
		double g_E0 = tempneu[index_neuron].value[5]*exp((newstep-subTstep)/Time_ExCon);
		double g_I0 = tempneu[index_neuron].value[Stepsmooth_Con+5]*exp((newstep-subTstep)/Time_InCon);

// The conductance at two_fourth_time 
      subbegin_time=0;
	while ((j<poisson_input[index_neuron].vect_size) 
			&& (poisson_input[index_neuron].vect_value[j]<=newstep/2))
		{			

                               subend_time = poisson_input[index_neuron].vect_value[j];
		               sub_tstep = subend_time - subbegin_time;

				conductance_decay(tempneu, index_neuron, sub_tstep);
				force_input(tempneu, index_neuron);	
                      j++;
                    subbegin_time=subend_time;
		} // end of while (for poisson spikes)

		// finish the last sub-interval!
		
		sub_tstep = newstep/2 - subbegin_time;

				conductance_decay(tempneu, index_neuron, sub_tstep);


		double g_E1 = tempneu[index_neuron].value[5];
		double g_I1 = tempneu[index_neuron].value[6];
//***************************************************************************************************
// The conductance at end_time
		subbegin_time=newstep/2.0;
		while ((j<poisson_input[index_neuron].vect_size) 
			&& (poisson_input[index_neuron].vect_value[j]<=newstep)&&(poisson_input[index_neuron].vect_value[j]>newstep/2))
		{			

                               subend_time = poisson_input[index_neuron].vect_value[j];
		               sub_tstep = subend_time - subbegin_time;

				conductance_decay(tempneu, index_neuron, sub_tstep);
				force_input(tempneu, index_neuron);
	
                      j++;
                    subbegin_time=subend_time;
		} // end of while (for poisson spikes)

		// finish the last sub-interval!
		
		sub_tstep = newstep- subbegin_time;

				conductance_decay(tempneu, index_neuron, sub_tstep);

		double g_E2 = tempneu[index_neuron].value[5];
		double g_I2 = tempneu[index_neuron].value[6];
         
#endif

		double ini_time = t_evolution;
		double two_fourth_time = t_evolution+newstep/2.0;
		double end_time = t_evolution + newstep;

                if (y[4]>1)
			y[4]=fmod(y[4],1);

                 	// void (*dvdt)(double t,vector<double> y,double gE, double gI,double &dv_dt),
			(*voltage_p_dt)(ini_time ,y,g_E0, g_I0,m1[0]);
			//(*dmdt)(double t,double y_0, double y_1, double &dm_dt)
			(*m_p_dt)(ini_time ,y[0],y[1],m1[1]);
			//void (*dhdt)(double t,double y_0, double y_2, double &dh_dt)
	                (*h_p_dt)(ini_time ,y[0],y[2],m1[2]);
			//(*dndt)(double t,double y_0, double y_3,double &dn_dt)
			(*n_p_dt)(ini_time ,y[0],y[3],m1[3]);
			//(*dqdt)(double t,double Omega, double &dq_dt)
	                (*q_p_dt)(ini_time ,Omega[0], m1[4]);
			//assign the m11,m12,m13,m14 to k1
                        k1[0]=m1[0];
			k1[1]=m1[1];
			k1[2]=m1[2];
			k1[3]=m1[3];
			k1[4]=m1[4];

                         // k2 = f(t(n)+h/2, y(n)+k1*h/2)
 
			for(int a=0;a<5;a++)
			{
				temp[a]=0.5*newstep*k1[a]+y[a];
			}
			
                        (*voltage_p_dt)(two_fourth_time,temp,g_E1,g_I1,m2[0]);
			(*m_p_dt)(two_fourth_time,temp[0],temp[1],m2[1]);
	                (*h_p_dt)(two_fourth_time,temp[0],temp[2],m2[2]);
			(*n_p_dt)(two_fourth_time,temp[0],temp[3],m2[3]);
	                (*q_p_dt)(two_fourth_time,Omega[0], m2[4]);
   
			k2[0]=m2[0];
			k2[1]=m2[1];
			k2[2]=m2[2];
			k2[3]=m2[3];
			k2[4]=m2[4];
			// k3 = f(t(n)+h/2, y(n)+k2*h/2)
			for(int a=0;a<5;a++)
			{
				temp[a]=0.5*newstep*k2[a]+y[a];
			}

			(*voltage_p_dt)(two_fourth_time,temp,g_E1,g_I1,m3[0]);
			(*m_p_dt)(two_fourth_time,temp[0],temp[1],m3[1]);
	                (*h_p_dt)(two_fourth_time,temp[0],temp[2],m3[2]);
			(*n_p_dt)(two_fourth_time,temp[0],temp[3],m3[3]);
	                (*q_p_dt)(two_fourth_time,Omega[0], m3[4]);

			k3[0]=m3[0];
			k3[1]=m3[1];
			k3[2]=m3[2];
			k3[3]=m3[3];
			k3[4]=m3[4];

			// k4 = f(t(n)+h, y(n)+k3*h)
			for(int a=0;a<5;a++)
			{
				temp[a]=newstep*k3[a]+y[a];
			}

			(*voltage_p_dt)(end_time,temp,g_E2,g_I2,m4[0]);
			(*m_p_dt)(end_time,temp[0],temp[1],m4[1]);
	                (*h_p_dt)(end_time,temp[0],temp[2],m4[2]);
			(*n_p_dt)(end_time,temp[0],temp[3],m4[3]);
	                (*q_p_dt)(end_time,Omega[0], m4[4]);

			k4[0]=m4[0];
			k4[1]=m4[1];
			k4[2]=m4[2];
			k4[3]=m4[3];
			k4[4]=m4[4];
			//The solution value
			
			for(int i=0;i<5;i++)
			{
				y[i]=y[i]+(newstep/6)*(k1[i]+2*k2[i]+2*k3[i]+k4[i]);
			}
//*********************** Release memory******************
   free(m1);
   free(m2);
   free(m3);
   free(m4); 		
};

 # else
void runge_kutta4_whole(neuron *tempneu, int index_neuron, double subTstep,double t_evolution,vector<double> Omega,vector<double> &y,
		  void (*voltage_p_non_dt)(double t,vector<double> y,double Omega_1,double gE, double gI,double &dv_dt),
	          void (*m_p_dt)(double t,double y_0, double y_1, double &dm_dt),
	          void (*h_p_dt)(double t,double y_0, double y_2, double &dh_dt),
	          void (*n_p_dt)(double t,double y_0, double y_3,double &dn_dt))
{
#if SMOOTH_CONDUCTANCE_USE
	int j=0;
        double subbegin_time;
	double subend_time; // record the middle point of poisson input!
	double sub_tstep;
        vector<double>  temp(8);
	vector<double>  k1(8); 
	vector<double>  k2(8); 
	vector<double>  k3(8); 
	vector<double>  k4(8); 
        
	double *m1;
        double *m2;
        double *m3;
        double *m4;

	m1=(double *)malloc(8*sizeof(double));
        m2=(double *)malloc(8*sizeof(double));
        m3=(double *)malloc(8*sizeof(double));
        m4=(double *)malloc(8*sizeof(double));

        y.resize(8);// five solutions:v,m,n,h,g_e,g_i
        for (int i=0;i<8;i++)
        {
          y[i]=tempneu[index_neuron].value[i];// input the initial values y0 to the y
	}
        double newstep = subTstep; // time step needs to be changed for awaken neuron              


		double g_E0 = tempneu[index_neuron].value[4]*exp((newstep-subTstep)/Time_ExCon)
			+ 1.0*Time_ExCon*Time_ExConR/(Time_ExConR-Time_ExCon)
			   *(exp((newstep-subTstep)/Time_ExConR) - exp((newstep-subTstep)/Time_ExCon))
			   *tempneu[index_neuron].value[3+Stepsmooth_Con];
		double H_E0 = tempneu[index_neuron].value[3+Stepsmooth_Con]*exp((newstep-subTstep)/Time_ExConR);

		double g_I0 = tempneu[index_neuron].value[4+Stepsmooth_Con]*exp((newstep-subTstep)/Time_InCon)
			+ 1.0*Time_InCon*Time_InConR/(Time_InConR-Time_InCon)
			   *(exp((newstep-subTstep)/Time_InConR) - exp((newstep-subTstep)/Time_InCon))
			   *tempneu[index_neuron].value[2*Stepsmooth_Con+3];
		double H_I0 = tempneu[index_neuron].value[2*Stepsmooth_Con+3]*exp((newstep-subTstep)/Time_InConR);
//***************************************************************************************************
// The conductance at two_fourth_time 
      subbegin_time=0;
	while ((j<poisson_input[index_neuron].vect_size) 
			&& (poisson_input[index_neuron].vect_value[j]<=newstep/2))
		{			

                               subend_time = poisson_input[index_neuron].vect_value[j];
		               sub_tstep = subend_time - subbegin_time;

				conductance_evolve(tempneu, index_neuron, sub_tstep);
				force_inputR(tempneu, index_neuron);	
                      j++;
                    subbegin_time=subend_time;
		} // end of while (for poisson spikes)

		// finish the last sub-interval!
		
		sub_tstep = newstep/2 - subbegin_time;

				conductance_evolve(tempneu, index_neuron, sub_tstep);

		double g_E1 = tempneu[index_neuron].value[4];
		double g_I1 = tempneu[index_neuron].value[6];
//***************************************************************************************************
// The conductance at end_time
		subbegin_time=newstep/2.0;
		while ((j<poisson_input[index_neuron].vect_size) 
			&& (poisson_input[index_neuron].vect_value[j]<=newstep)&&(poisson_input[index_neuron].vect_value[j]>newstep/2))
		{			

                               subend_time = poisson_input[index_neuron].vect_value[j];
		               sub_tstep = subend_time - subbegin_time;

				conductance_evolve(tempneu, index_neuron, sub_tstep);
				force_inputR(tempneu, index_neuron);

                      j++;
                    subbegin_time=subend_time;
		} // end of while (for poisson spikes)

		// finish the last sub-interval!
		
		sub_tstep = newstep- subbegin_time;

				conductance_evolve(tempneu, index_neuron, sub_tstep);

		double g_E2 = tempneu[index_neuron].value[4];
		double g_I2 = tempneu[index_neuron].value[6];
              
#else

        vector<double>  temp(6);
	vector<double>  k1(6); 
	vector<double>  k2(6); 
	vector<double>  k3(6); 
	vector<double>  k4(6); 
        
	double *m1;
        double *m2;
        double *m3;
        double *m4;

	m1=(double *)malloc(6*sizeof(double));
        m2=(double *)malloc(6*sizeof(double));
        m3=(double *)malloc(6*sizeof(double));
        m4=(double *)malloc(6*sizeof(double));

        y.resize(6);// five solutions:v,m,n,h,q,g_e,g_i
        for (int i=0;i<6;i++)
        {
          y[i]=tempneu[index_neuron].value[i];// input the initial values y0 to the y
	}
        double newstep = subTstep; // time step needs to be changed for awaken neuron
          
		double g_E0 = tempneu[index_neuron].value[4]*exp((newstep-subTstep)/Time_ExCon);
		double g_I0 = tempneu[index_neuron].value[Stepsmooth_Con+4]*exp((newstep-subTstep)/Time_InCon);

// The conductance at two_fourth_time 
      subbegin_time=0;
	while ((j<poisson_input[index_neuron].vect_size) 
			&& (poisson_input[index_neuron].vect_value[j]<=newstep/2))
		{			

                               subend_time = poisson_input[index_neuron].vect_value[j];
		               sub_tstep = subend_time - subbegin_time;

				conductance_decay(tempneu, index_neuron, sub_tstep);
				force_input(tempneu, index_neuron);	
                      j++;
                    subbegin_time=subend_time;
		} // end of while (for poisson spikes)

		// finish the last sub-interval!
		
		sub_tstep = newstep/2 - subbegin_time;

				conductance_decay(tempneu, index_neuron, sub_tstep);


		double g_E1 = tempneu[index_neuron].value[4];
		double g_I1 = tempneu[index_neuron].value[5];
//***************************************************************************************************
// The conductance at end_time
		subbegin_time=newstep/2.0;
		while ((j<poisson_input[index_neuron].vect_size) 
			&& (poisson_input[index_neuron].vect_value[j]<=newstep)&&(poisson_input[index_neuron].vect_value[j]>newstep/2))
		{			

                               subend_time = poisson_input[index_neuron].vect_value[j];
		               sub_tstep = subend_time - subbegin_time;

				conductance_decay(tempneu, index_neuron, sub_tstep);
				force_input(tempneu, index_neuron);
	
                      j++;
                    subbegin_time=subend_time;
		} // end of while (for poisson spikes)

		// finish the last sub-interval!
		
		sub_tstep = newstep- subbegin_time;

				conductance_decay(tempneu, index_neuron, sub_tstep);

		double g_E2 = tempneu[index_neuron].value[4];
		double g_I2 = tempneu[index_neuron].value[5];
         
#endif

		double ini_time = t_evolution;
		double two_fourth_time = t_evolution + newstep/2;
		double end_time = t_evolution + newstep;

                       	// void (*dvdt)(double t,vector<double> y,double gE, double gI,double &dv_dt),
			(*voltage_p_non_dt)(ini_time ,y,Omega[0],g_E0, g_I0,m1[0]);
			//(*dmdt)(double t,double y_0, double y_1, double &dm_dt)
			(*m_p_dt)(ini_time ,y[0],y[1],m1[1]);
			//void (*dhdt)(double t,double y_0, double y_2, double &dh_dt)
	                (*h_p_dt)(ini_time ,y[0],y[2],m1[2]);
			//(*dndt)(double t,double y_0, double y_3,double &dn_dt)
			(*n_p_dt)(ini_time ,y[0],y[3],m1[3]);
			//(*dqdt)(double t,double Omega, double &dq_dt)
	                (*q_p_dt)(ini_time ,Omega[0], m1[4]);
			//assign the m11,m12,m13,m14 to k1
                        k1[0]=m1[0];
			k1[1]=m1[1];
			k1[2]=m1[2];
			k1[3]=m1[3];
			k1[4]=m1[4];

                         // k2 = f(t(n)+h/2, y(n)+k1*h/2)
 
			for(int a=0;a<5;a++)
			{
				temp[a]=0.5*newstep*k1[a]+y[a];
			}
			
                        (*voltage_p_non_dt)(two_fourth_time,temp,Omega[0],g_E1,g_I1,m2[0]);
			(*m_p_dt)(two_fourth_time,temp[0],temp[1],m2[1]);
	                (*h_p_dt)(two_fourth_time,temp[0],temp[2],m2[2]);
			(*n_p_dt)(two_fourth_time,temp[0],temp[3],m2[3]);
	                (*q_p_dt)(two_fourth_time,Omega[0], m2[4]);
   
			k2[0]=m2[0];
			k2[1]=m2[1];
			k2[2]=m2[2];
			k2[3]=m2[3];
			k2[4]=m2[4];
			// k3 = f(t(n)+h/2, y(n)+k2*h/2)
			for(int a=0;a<5;a++)
			{
				temp[a]=0.5*newstep*k2[a]+y[a];
			}

			(*voltage_p_non_dt)(two_fourth_time,temp,Omega[0],g_E1,g_I1,m3[0]);
			(*m_p_dt)(two_fourth_time,temp[0],temp[1],m3[1]);
	                (*h_p_dt)(two_fourth_time,temp[0],temp[2],m3[2]);
			(*n_p_dt)(two_fourth_time,temp[0],temp[3],m3[3]);
	                (*q_p_dt)(two_fourth_time,Omega[0], m3[4]);

			k3[0]=m3[0];
			k3[1]=m3[1];
			k3[2]=m3[2];
			k3[3]=m3[3];
			k3[4]=m3[4];

			// k4 = f(t(n)+h, y(n)+k3*h)
			for(int a=0;a<5;a++)
			{
				temp[a]=newstep*k3[a]+y[a];
			}

			(*voltage_p_non_dt)(end_time,temp,Omega[0],g_E2,g_I2,m4[0]);
			(*m_p_dt)(end_time,temp[0],temp[1],m4[1]);
	                (*h_p_dt)(end_time,temp[0],temp[2],m4[2]);
			(*n_p_dt)(end_time,temp[0],temp[3],m4[3]);
	                (*q_p_dt)(end_time,Omega[0], m4[4]);

			k4[0]=m4[0];
			k4[1]=m4[1];
			k4[2]=m4[2];
			k4[3]=m4[3];
			k4[4]=m4[4];
			//The solution value
			
			for(int i=0;i<5;i++)
			{
				y[i]=y[i]+(newstep/6)*(k1[i]+2*k2[i]+2*k3[i]+k4[i]);
			}
//*********************** Release memory******************
   free(m1);
   free(m2);
   free(m3);
   free(m4);
   	
};
#endif


void spiking_time(neuron *tempneu, int index_neuron, double t_evolution, double Ta, 
				  double Tb, vector<double> Vmhn, double &firing_time)
{
	vector<double> Temp_Vmhn;
        double subTstep = Tb - Ta;
#if Autonomy_Use
#if SMOOTH_CONDUCTANCE_USE
         for(int vmhn_i=0;vmhn_i<9;vmhn_i++)
	{
             Temp_Vmhn.push_back(tempneu[index_neuron].value[vmhn_i]);
	}
#else
    for(int vmhn_i=0;vmhn_i<7;vmhn_i++)
	{
             Temp_Vmhn.push_back(tempneu[index_neuron].value[vmhn_i]);
	}
#endif
#else
#if SMOOTH_CONDUCTANCE_USE
         for(int vmhn_i=0;vmhn_i<8;vmhn_i++)
	{
             Temp_Vmhn.push_back(tempneu[index_neuron].value[vmhn_i]);
	}
#else
    for(int vmhn_i=0;vmhn_i<6;vmhn_i++)
	{
             Temp_Vmhn.push_back(tempneu[index_neuron].value[vmhn_i]);
	}
#endif

#endif
        double va = tempneu[index_neuron].value[0];
	double dva = 0; // initialization
	double gEa = tempneu[index_neuron].value[1];
	double gIa = tempneu[index_neuron].value[Stepsmooth_Con+1];

	//voltage_dt(index_neuron,t_evolution,gEa,gIa,va,dva);
         voltage_p_dt(t_evolution,Temp_Vmhn,gEa,gIa,dva);

        double vb = Vmhn[0];
	double dvb = 0; // initialization

#if SMOOTH_CONDUCTANCE_USE
	double gEb = tempneu[index_neuron].value[5]*exp(-subTstep/Time_ExCon)
		+ 1.0*Time_ExCon*Time_ExConR/(Time_ExConR-Time_ExCon)
			   *(exp(-subTstep/Time_ExConR) - exp(-subTstep/Time_ExCon))
			   *tempneu[index_neuron].value[4+Stepsmooth_Con];
	double gIb = tempneu[index_neuron].value[Stepsmooth_Con+5]*exp(-subTstep/Time_InCon)
		+ 1.0*Time_InCon*Time_InConR/(Time_InConR-Time_InCon)
			   *(exp(-subTstep/Time_InConR) - exp(-subTstep/Time_InCon))
			   *tempneu[index_neuron].value[2*Stepsmooth_Con+4];
#else
	double gEb = tempneu[index_neuron].value[5]*exp(-subTstep/Time_ExCon);
	double gIb = tempneu[index_neuron].value[Stepsmooth_Con+5]*exp(-subTstep/Time_InCon);
#endif

	//void voltage_p_dt(double t,vector<double> y,double gE, double gI,double &dv_dt)
	//voltage_dt(index_neuron,(t_evolution+Tb-Ta),gEb,gIb,vb,dvb);
          voltage_p_dt((t_evolution+Tb-Ta),Vmhn,gEb,gIb,dvb);

	firing_time = root_search(hermit, Ta, Tb, va, vb, dva, dvb, root_acc);
        FREE_2(Temp_Vmhn);
}


// This is for poisson input case!!!
//***************** renewing conductance process is done outside this program!
void single_neuron_test(neuron *tempneu,int index_neuron,double begin_time,vector<double> Omega,vector<double> &y,
                             double end_time,int *begin_poisson_index)
{
	// because the system may need to be pulled back, therefore some variables are 
	// just temporal such as: *tempneu, *begin_poisson_index, end_time

	// record the starting point of poisson input in this interval!
		int j = begin_poisson_index[index_neuron]; 
	    // for each neuron i, [T1, T2] is divided by poisson input spikes t(i1),t(i2),...
		// evolve interval [T1, t(i1)] and then [t(i2), t(i3)], so on and so fourth
		double subbegin_time = begin_time;
		double subend_time = end_time; // record the middle point of poisson input!
		double sub_tstep = end_time - begin_time;

		// do hermit interpolation if a neuron fires
		double firing_time = 0;

		// if there is an external input current!
		  double time_evolution=begin_time;
		  double t_evolution=begin_time;
                //*********************************************************************************
		//**************  no poisson input in the whole interval! 
		if (j >= poisson_input[index_neuron].vect_size) 
		{
#if VOT_DEBUG			
			cout<<"No poisson spikes in this sub-time step! "<<endl;
			cout<<"The voltage before sub-time step "<<sub_tstep<<" is: "
				<<tempneu[index_neuron].value[0]<<endl;
#endif		
	
//runge_kutta4(tempneu, index_neuron, sub_tstep, t_evolution, temp_vot,voltage_dt);
#if Autonomy_Use
runge_kutta4(tempneu,index_neuron, sub_tstep,t_evolution,Omega,y,voltage_p_dt,m_p_dt,h_p_dt,n_p_dt,q_p_dt);
# else
runge_kutta4(tempneu,index_neuron, sub_tstep,t_evolution,Omega,y,voltage_p_non_dt,m_p_dt,h_p_dt,n_p_dt);
#endif
			
#if VOT_DEBUG
			cout<<"The voltage after: "<<y[0]<<endl;
#endif			
//******************************** Save ISI ****************************************
			// neuron is firing without poisson input spikes
if(ISI_SAVE==1)
{
	if((y[0] >= Vot_Threshold) && (Vot_Threshold>tempneu[0].value[0]))
	{
#if FIRE_DEBUG
				cout<<"determine the spike time 1: "<<endl;

				cout<<"index_neuron: "<<index_neuron<<endl;
#endif

#if DEBUG_OUTPUT_ALL
				cout<<"end_time: "<<end_time<<endl;
			cout<<"begining time: "<<subbegin_time<<"  "
				<<"voltage: "<<tempneu[index_neuron].value[0]<<endl;
			cout<<"ending time: "<<subend_time<<"  "
				<<"voltage: "<<y[0]<<endl;
#endif

	          spiking_time(tempneu, index_neuron, t_evolution, subbegin_time,subend_time,y,firing_time);
                    ISI0_P.push_back(firing_time);
#if FIRE_DEBUG
				cout<<"neuron "<<index_neuron<<" is firing!"<<endl;
				cout<<"firing time: "<<firing_time<<endl;
#endif

	}
}
//**********************************************************************************
			#if Autonomy_Use                   
                         for(int i_value=0;i_value<5;i_value++)
			   {
                               tempneu[index_neuron].value[i_value] = y[i_value];
                           }
			#else
		         for(int i_value=0;i_value<4;i_value++)
			   {
                              tempneu[index_neuron].value[i_value] = y[i_value];
                           }
			#endif

#if SMOOTH_CONDUCTANCE_USE
				conductance_evolve(tempneu, index_neuron, sub_tstep);
#else
				conductance_decay(tempneu, index_neuron, sub_tstep);
#endif

#if Autonomy_Use
#if SMOOTH_CONDUCTANCE_USE
           for(int i_value=5;i_value<9;i_value++)
	{
           y[i_value]=tempneu[index_neuron].value[i_value];
        }
#else
for(int i_value=5;i_value<7;i_value++)
	{
           y[i_value]=tempneu[index_neuron].value[i_value];
        }
#endif
#else
#if SMOOTH_CONDUCTANCE_USE
for(int i_value=4;i_value<8;i_value++)
	{
           y[i_value]=tempneu[index_neuron].value[i_value];
        }
#else
for(int i_value=4;i_value<6;i_value++)
	{
           y[i_value]=tempneu[index_neuron].value[i_value];
        }
#endif
#endif

        	return;
		} // end if there is no poisson spikes
		
//********************************* 2012.10.19 By Grant*********************************
                 subbegin_time=0;
		while ((j<poisson_input[index_neuron].vect_size) 
			&& (poisson_input[index_neuron].vect_value[j]<=(end_time-begin_time)))
		{			
			subend_time = poisson_input[index_neuron].vect_value[j];
			sub_tstep = subend_time - subbegin_time;
#if Autonomy_Use
runge_kutta4(tempneu,index_neuron, sub_tstep,t_evolution,Omega,y,voltage_p_dt,m_p_dt,h_p_dt,n_p_dt,q_p_dt);
# else
runge_kutta4(tempneu,index_neuron, sub_tstep,t_evolution,Omega,y,voltage_p_non_dt,m_p_dt,h_p_dt,n_p_dt);
#endif

#if VOT_DEBUG
			cout<<"The voltage after: "<<y[0]<<endl;
#endif			


//******************************** Save ISI ****************************************
			// neuron is firing without poisson input spikes
if(ISI_SAVE==1)
{
	if((y[0] >= Vot_Threshold) && (Vot_Threshold>tempneu[0].value[0]))
	{
#if FIRE_DEBUG
				cout<<"determine the spike time 1: "<<endl;

				cout<<"index_neuron: "<<index_neuron<<endl;
#endif

#if DEBUG_OUTPUT_ALL
				cout<<"end_time: "<<end_time<<endl;
			cout<<"begining time: "<<subbegin_time<<"  "
				<<"voltage: "<<tempneu[index_neuron].value[0]<<endl;
			cout<<"ending time: "<<subend_time<<"  "
				<<"voltage: "<<y[0]<<endl;
#endif

	          spiking_time(tempneu, index_neuron, t_evolution, subbegin_time,subend_time,y,firing_time);
                     ISI0_P.push_back(firing_time);
#if FIRE_DEBUG
				cout<<"neuron "<<index_neuron<<" is firing!"<<endl;
				cout<<"firing time: "<<firing_time<<endl;
#endif

	}
}

//**************************************************************************************
			// neuron is not firing at this sub-interval, 
			// renew the voltage and conductance, then go ahead to the next sub-interval
#if Autonomy_Use                   
                   for(int i_value=0;i_value<5;i_value++)
			{
                         tempneu[index_neuron].value[i_value] = y[i_value];
                        }
#else
		    for(int i_value=0;i_value<4;i_value++)
			{
                         tempneu[index_neuron].value[i_value] = y[i_value];
                        }

#endif
#if SMOOTH_CONDUCTANCE_USE
				conductance_evolve(tempneu, index_neuron, sub_tstep);
				force_inputR(tempneu, index_neuron);
#else
				conductance_decay(tempneu, index_neuron, sub_tstep);
				force_input(tempneu, index_neuron);
#endif


#if Autonomy_Use
#if SMOOTH_CONDUCTANCE_USE
           for(int i_value=5;i_value<9;i_value++)
	{
           y[i_value]=tempneu[index_neuron].value[i_value];
        }
#else
for(int i_value=5;i_value<7;i_value++)
	{
           y[i_value]=tempneu[index_neuron].value[i_value];
        }
#endif
#else
#if SMOOTH_CONDUCTANCE_USE
for(int i_value=4;i_value<8;i_value++)
	{
           y[i_value]=tempneu[index_neuron].value[i_value];
        }
#else
for(int i_value=4;i_value<6;i_value++)
	{
           y[i_value]=tempneu[index_neuron].value[i_value];
        }
#endif
#endif
				subbegin_time = subend_time;
				t_evolution += sub_tstep;
				j++;
		} // end of while (for poisson spikes)
		
//***************************************************************************************************
		// finish the last sub-interval!
		
		sub_tstep = end_time - begin_time-subbegin_time;
#if VOT_DEBUG
		        cout<<"finish the last sub-interval!"<<endl;
                 	cout<<"sub_tstep: "<<sub_tstep<<endl;
#endif	
#if Autonomy_Use
runge_kutta4(tempneu,index_neuron, sub_tstep,t_evolution,Omega,y,voltage_p_dt,m_p_dt,h_p_dt,n_p_dt,q_p_dt);
# else
runge_kutta4(tempneu,index_neuron, sub_tstep,t_evolution,Omega,y,voltage_p_non_dt,m_p_dt,h_p_dt,n_p_dt);
#endif

#if VOT_DEBUG
		        cout<<"The voltage after: "<<y[0]<<endl;
#endif			

//******************************** Save ISI ****************************************
			// neuron is firing without poisson input spikes
if(ISI_SAVE==1)
{
	if((y[0] >= Vot_Threshold) && (Vot_Threshold>tempneu[0].value[0]))
	{
#if FIRE_DEBUG
				cout<<"determine the spike time 1: "<<endl;

				cout<<"index_neuron: "<<index_neuron<<endl;
#endif

#if DEBUG_OUTPUT_ALL
				cout<<"end_time: "<<end_time<<endl;
			cout<<"begining time: "<<subbegin_time<<"  "
				<<"voltage: "<<tempneu[index_neuron].value[0]<<endl;
			cout<<"ending time: "<<subend_time<<"  "
				<<"voltage: "<<y[0]<<endl;
#endif

	          spiking_time(tempneu, index_neuron, t_evolution, subbegin_time,subend_time,y,firing_time);
                   ISI0_P.push_back(firing_time);
#if FIRE_DEBUG
				cout<<"neuron "<<index_neuron<<" is firing!"<<endl;
				cout<<"firing time: "<<firing_time<<endl;
#endif

	}
}
//**********************************************************************************

#if Autonomy_Use                   
                    for(int i_value=0;i_value<5;i_value++)
			{
                         tempneu[index_neuron].value[i_value] = y[i_value];
                        }
#else
		    for(int i_value=0;i_value<4;i_value++)
			{
                         tempneu[index_neuron].value[i_value] = y[i_value];
                        }

#endif

#if SMOOTH_CONDUCTANCE_USE
				conductance_evolve(tempneu, index_neuron, sub_tstep);
#else
				conductance_decay(tempneu, index_neuron, sub_tstep);
#endif
      
// Record the solutions after each step                  
#if Autonomy_Use
#if SMOOTH_CONDUCTANCE_USE
           for(int i_value=5;i_value<9;i_value++)
	{
           y[i_value]=tempneu[index_neuron].value[i_value];
        }
#else
for(int i_value=5;i_value<7;i_value++)
	{
           y[i_value]=tempneu[index_neuron].value[i_value];
        }
#endif
#else
#if SMOOTH_CONDUCTANCE_USE
for(int i_value=4;i_value<8;i_value++)
	{
           y[i_value]=tempneu[index_neuron].value[i_value];
        }
#else
for(int i_value=4;i_value<6;i_value++)
	{
           y[i_value]=tempneu[index_neuron].value[i_value];
        }
#endif
#endif
		// cortical force to conductance is done outside this function!
		begin_poisson_index[index_neuron] = j;			
};
//*******************************************************************************************************************


//**************Consider the whole poisson input, not consider the interval of poisson input*************************
void single_neuron_test_whole(neuron *tempneu,int index_neuron,double begin_time,vector<double> Omega,vector<double> &y,
                             double end_time,int *begin_poisson_index)
{
	// because the system may need to be pulled back, therefore some variables are 
	// just temporal such as: *tempneu, *begin_poisson_index, end_time

	 
	//************** cortical force to conductance is done outside this function!

	// record the starting point of poisson input in this interval!
		int j = begin_poisson_index[index_neuron]; 
	    // for each neuron i, [T1, T2] is divided by poisson input spikes t(i1),t(i2),...
		// evolve interval [T1, t(i1)] and then [t(i2), t(i3)], so on and so fourth
		double subbegin_time = begin_time;
		double subend_time = end_time; // record the middle point of poisson input!
		double sub_tstep = end_time - begin_time;

		// if there is an external input current!
		//double t_evolution = time_evolution+begin_time;
		  double t_evolution=begin_time;
		//*********************************************************************************
		//**************  no poisson input in the whole interval! 
		if (j >= poisson_input[index_neuron].vect_size) 
		{
#if VOT_DEBUG			
			cout<<"No poisson spikes in this sub-time step! "<<endl;
			cout<<"The voltage before sub-time step "<<sub_tstep<<" is: "
				<<tempneu[index_neuron].value[0]<<endl;
#endif		
	
//runge_kutta4(tempneu, index_neuron, sub_tstep, t_evolution, temp_vot,voltage_dt);
#if Autonomy_Use
runge_kutta4(tempneu,index_neuron, sub_tstep,t_evolution,Omega,y,voltage_p_dt,m_p_dt,h_p_dt,n_p_dt,q_p_dt);
# else
runge_kutta4(tempneu,index_neuron, sub_tstep,t_evolution,Omega,y,voltage_p_non_dt,m_p_dt,h_p_dt,n_p_dt);
#endif
			
#if VOT_DEBUG
			cout<<"The voltage after: "<<y[0]<<endl;
#endif			
//****************************************************************************************
			#if Autonomy_Use                   
                         for(int i_value=0;i_value<5;i_value++)
			   {
                               tempneu[index_neuron].value[i_value] = y[i_value];
                           }
			#else
		         for(int i_value=0;i_value<4;i_value++)
			   {
                              tempneu[index_neuron].value[i_value] = y[i_value];
                           }
			#endif
//****************************************************************************************
#if SMOOTH_CONDUCTANCE_USE
				conductance_evolve(tempneu, index_neuron, sub_tstep);
#else
				conductance_decay(tempneu, index_neuron, sub_tstep);
#endif
//****************************************************************************************
// Record the solutions after each step                  
#if Autonomy_Use
#if SMOOTH_CONDUCTANCE_USE
           for(int i_value=5;i_value<9;i_value++)
	{
           y[i_value]=tempneu[index_neuron].value[i_value];
        }
#else
for(int i_value=5;i_value<7;i_value++)
	{
           y[i_value]=tempneu[index_neuron].value[i_value];
        }
#endif
#else
#if SMOOTH_CONDUCTANCE_USE
for(int i_value=4;i_value<8;i_value++)
	{
           y[i_value]=tempneu[index_neuron].value[i_value];
        }
#else
for(int i_value=4;i_value<6;i_value++)
	{
           y[i_value]=tempneu[index_neuron].value[i_value];
        }
#endif
#endif
	return;
		} // end if there is no poisson spikes
		
//********************************* 2012.10.21 By Grant*********************************
else
{
#if VOT_DEBUG
		        cout<<"finish the last sub-interval!"<<endl;
                 	cout<<"sub_tstep: "<<sub_tstep<<endl;
#endif	

#if Autonomy_Use
runge_kutta4_whole(tempneu,index_neuron, sub_tstep,t_evolution,Omega,y,voltage_p_dt,m_p_dt,h_p_dt,n_p_dt,q_p_dt);
# else
runge_kutta4_whole(tempneu,index_neuron, sub_tstep,t_evolution,Omega,y,voltage_p_non_dt,m_p_dt,h_p_dt,n_p_dt);
#endif

#if VOT_DEBUG
		        cout<<"The voltage after: "<<y[0]<<endl;
#endif	
//****************************************************************************************
			#if Autonomy_Use                   
                         for(int i_value=0;i_value<5;i_value++)
			   {
                               tempneu[index_neuron].value[i_value] = y[i_value];
                           }
			#else
		         for(int i_value=0;i_value<4;i_value++)
			   {
                              tempneu[index_neuron].value[i_value] = y[i_value];
                           }
			#endif
//****************************************************************************************
// Record the solutions after each step                  
#if Autonomy_Use
#if SMOOTH_CONDUCTANCE_USE
           for(int i_value=5;i_value<9;i_value++)
	{
           y[i_value]=tempneu[index_neuron].value[i_value];
        }
#else
for(int i_value=5;i_value<7;i_value++)
	{
           y[i_value]=tempneu[index_neuron].value[i_value];
        }
#endif
#else
#if SMOOTH_CONDUCTANCE_USE
for(int i_value=4;i_value<8;i_value++)
	{
           y[i_value]=tempneu[index_neuron].value[i_value];
        }
#else
for(int i_value=4;i_value<6;i_value++)
	{
           y[i_value]=tempneu[index_neuron].value[i_value];
        }
#endif
#endif
}	
};
//*************************************************************************************************************************
void Neuron_Solution(int N,double h,double begin_time,vector<double> Omega,vector<vector<double> >&y,vector<double> y_0)
{
int totalnum=1;
int *tempbegin_poisson_index=(int *)malloc(sizeof(int)*totalnum);
double end_time=h+begin_time;


  y.resize(N);
	
/*
       for (int j=0;j<N;j++)
		{
#if SMOOTH_CONDUCTANCE_USE
#if Autonomy_Use 
			y[j].resize(9);// five solutions:v,m,n,h,q,ge,ge1,gi,gi1
#else
                        y[j].resize(8);// five solutions:v,m,n,h,ge,ge1,gi,gi1
#endif
#else
#if Autonomy_Use 
			y[j].resize(7);// five solutions:v,m,n,h,q,ge,gi
#else
                        y[j].resize(6);// five solutions:v,m,n,h,ge,gi
#endif

#endif
                 }
*/

#if SMOOTH_CONDUCTANCE_USE
#if Autonomy_Use 
   for (int i_num=0;i_num<totalnum;i_num++)
	{
           for (int j_num=0;j_num<9;j_num++)
 		{           
		      neu[i_num].value[j_num]=y_0[j_num];
		}
         }
#else
   for (int i_num=0;i_num<totalnum;i_num++)
	{
           for (int j_num=0;j_num<8;j_num++)
 		{           
		      neu[i_num].value[j_num]=y_0[j_num];
		}
         }
#endif
#else
#if Autonomy_Use 
for (int i_num=0;i_num<totalnum;i_num++)
	{
           for (int j_num=0;j_num<7;j_num++)
 		{           
		      neu[i_num].value[j_num]=y_0[j_num];
		}
         }
#else
for (int i_num=0;i_num<totalnum;i_num++)
	{
           for (int j_num=0;j_num<6;j_num++)
 		{           
		      neu[i_num].value[j_num]=y_0[j_num];
		}
         }
#endif

#endif
           neuron *tempneu = (neuron *)malloc(sizeof(neuron)*totalnum);
    for (int i_num=0;i_num<totalnum;i_num++)
	{
           neuron_initialize(tempneu[i_num]);
           tempbegin_poisson_index[i_num]=0;
           neuron_copy(tempneu[i_num],neu[i_num]);
        }    
                 

for(int j=0;j<N;j++)
{
 // last_input is dynamically distributed space outside this function
 	for (int i_num=0;i_num<totalnum;i_num++)
 	{
  		poisson_generator(i_num,poisson_input[i_num],h);
 	}
	for (int i_num=0;i_num<totalnum;i_num++)
	{
    		single_neuron_test(tempneu,i_num,begin_time,Omega,y[j],end_time,tempbegin_poisson_index);
        }
	for (int i_num=0;i_num<totalnum;i_num++)
	{
  		tempbegin_poisson_index[i_num]=0;
        }

	begin_time=end_time;
	end_time=h+begin_time;
	
	for (int i_num=0;i_num<totalnum;i_num++)
	{
		vector_destroy(poisson_input[i_num]);
	}

}

for(int i_num=0;i_num<totalnum;i_num++)
	{
  		neuron_destroy(tempneu[i_num]);
	}
free(tempneu);
tempneu=NULL;
free(tempbegin_poisson_index);
}

//*************************************************************************************************************************
void Neuron_Solution_whole(int N,double h,double begin_time,vector<double> Omega,vector<vector<double> >&y,vector<double> y_0)
{
int totalnum=1;
int *tempbegin_poisson_index=(int *)malloc(sizeof(int)*totalnum);
double end_time=h*N+begin_time;


  y.resize(1);
	
/*
       for (int j=0;j<N;j++)
		{
#if SMOOTH_CONDUCTANCE_USE
#if Autonomy_Use 
			y[j].resize(9);// five solutions:v,m,n,h,q,ge,ge1,gi,gi1
#else
                        y[j].resize(8);// five solutions:v,m,n,h,ge,ge1,gi,gi1
#endif
#else
#if Autonomy_Use 
			y[j].resize(7);// five solutions:v,m,n,h,q,ge,gi
#else
                        y[j].resize(6);// five solutions:v,m,n,h,ge,gi
#endif

#endif
                 }
*/

#if SMOOTH_CONDUCTANCE_USE
#if Autonomy_Use 
   for (int i_num=0;i_num<totalnum;i_num++)
	{
           for (int j_num=0;j_num<9;j_num++)
 		{           
		      neu[i_num].value[j_num]=y_0[j_num];
		}
         }
#else
   for (int i_num=0;i_num<totalnum;i_num++)
	{
           for (int j_num=0;j_num<8;j_num++)
 		{           
		      neu[i_num].value[j_num]=y_0[j_num];
		}
         }
#endif
#else
#if Autonomy_Use 
for (int i_num=0;i_num<totalnum;i_num++)
	{
           for (int j_num=0;j_num<7;j_num++)
 		{           
		      neu[i_num].value[j_num]=y_0[j_num];
		}
         }
#else
for (int i_num=0;i_num<totalnum;i_num++)
	{
           for (int j_num=0;j_num<6;j_num++)
 		{           
		      neu[i_num].value[j_num]=y_0[j_num];
		}
         }
#endif

#endif
           neuron *tempneu = (neuron *)malloc(sizeof(neuron)*totalnum);
    for (int i_num=0;i_num<totalnum;i_num++)
	{
           neuron_initialize(tempneu[i_num]);
           tempbegin_poisson_index[i_num]=0;
           neuron_copy(tempneu[i_num],neu[i_num]);
        }    
                 
// last_input is dynamically distributed space outside this function
 	for (int i_num=0;i_num<totalnum;i_num++)
 	{
  		poisson_generator(i_num,poisson_input[i_num],N*h);
 	}
	for (int i_num=0;i_num<totalnum;i_num++)
	{
    		single_neuron_test_whole(tempneu,i_num,begin_time,Omega,y[0],end_time,tempbegin_poisson_index);
        }
	for (int i_num=0;i_num<totalnum;i_num++)
	{
  		tempbegin_poisson_index[i_num]=0;
        }

	begin_time=end_time;
	end_time=h+begin_time;
	
	for (int i_num=0;i_num<totalnum;i_num++)
	{
		vector_destroy(poisson_input[i_num]);
	}

for(int i_num=0;i_num<totalnum;i_num++)
	{
  		neuron_destroy(tempneu[i_num]);
	}
free(tempneu);
tempneu=NULL;
free(tempbegin_poisson_index);
}

//*************************************************************************************************************************
void Neuron_Solution_ISIjin(int N,double h,double begin_time,vector<double> Omega,vector<vector<double> >&y,vector<double> y_0,int Flage)
{
int totalnum=1;
int *tempbegin_poisson_index=(int *)malloc(sizeof(int)*totalnum);
double end_time=h+begin_time;

/*
if(Flage==2)
{
ISI_SAVE=1;
}
*/

#if SMOOTH_CONDUCTANCE_USE
#if Autonomy_Use 
   for (int i_num=0;i_num<totalnum;i_num++)
	{
           for (int j_num=0;j_num<9;j_num++)
 		{           
		      neu[i_num].value[j_num]=y_0[j_num];
		}
         }
#else
   for (int i_num=0;i_num<totalnum;i_num++)
	{
           for (int j_num=0;j_num<8;j_num++)
 		{           
		      neu[i_num].value[j_num]=y_0[j_num];
		}
         }
#endif
#else
#if Autonomy_Use 
for (int i_num=0;i_num<totalnum;i_num++)
	{
           for (int j_num=0;j_num<7;j_num++)
 		{           
		      neu[i_num].value[j_num]=y_0[j_num];
		}
         }
#else
for (int i_num=0;i_num<totalnum;i_num++)
	{
           for (int j_num=0;j_num<6;j_num++)
 		{           
		      neu[i_num].value[j_num]=y_0[j_num];
		}
         }
#endif

#endif
           neuron *tempneu = (neuron *)malloc(sizeof(neuron)*totalnum);
    for (int i_num=0;i_num<totalnum;i_num++)
	{
           neuron_initialize(tempneu[i_num]);
           tempbegin_poisson_index[i_num]=0;
           neuron_copy(tempneu[i_num],neu[i_num]);
        }    
    

for(int j=0;j<N;j++)
{             
		

 			if(Flage==0) //Compute Lyapunov Exponent refrence trace
			{
// last_input is dynamically distributed space outside this function
 				for (int i_num=0;i_num<totalnum;i_num++)
 				{
  					poisson_generator(i_num,poisson_input[i_num],h);
 				}

				 if(poisson_input[0].vect_size >0)
                         	    {
                                        vector_copy(poisson_input_ml[j], poisson_input[0]);
                                    }

				for (int i_num=0;i_num<totalnum;i_num++)
				{
    					 single_neuron_test(tempneu,i_num,begin_time,Omega,y[j],end_time,tempbegin_poisson_index);
                                        //single_neuron_test_whole(tempneu,i_num,begin_time,Omega,y[j],end_time,tempbegin_poisson_index);
       				}

					begin_time=end_time;
					end_time=h+begin_time;

                                        for (int i_num=0;i_num<totalnum;i_num++)
						{
  							tempbegin_poisson_index[i_num]=0;
      						}
                        	     
					for (int i_num=0;i_num<totalnum;i_num++)
				{
					vector_destroy(poisson_input[i_num]);
				}
			}

			else if(Flage==1) // Compute Lyapunove Exponent Perturb trace

			{
				if(poisson_input_ml[j].vect_size >0)
                          	  { vector_copy(poisson_input[0],poisson_input_ml[j]);}
                               

				for (int i_num=0;i_num<totalnum;i_num++)
				{
    					  single_neuron_test(tempneu,i_num,begin_time,Omega,y[j],end_time,tempbegin_poisson_index);
                                          //single_neuron_test_whole(tempneu,i_num,begin_time,Omega,y[j],end_time,tempbegin_poisson_index);
       				}

					begin_time=end_time;
					end_time=h+begin_time;

                                        for (int i_num=0;i_num<totalnum;i_num++)
						{
  							tempbegin_poisson_index[i_num]=0;
      						}

				for (int i_num=0;i_num<totalnum;i_num++)
				{
				vector_destroy(poisson_input[i_num]);
				}

			}

		else if(Flage==2)  // Compute the solution of HH model
		{
                                 for (int i_num=0;i_num<totalnum;i_num++)
 				{
  					poisson_generator(i_num,poisson_input[i_num],h);
 				}
				for (int i_num=0;i_num<totalnum;i_num++)
				{
    					single_neuron_test(tempneu,i_num,begin_time,Omega,y[j],end_time,tempbegin_poisson_index);
                                       //single_neuron_test_whole(tempneu,i_num,begin_time,Omega,y[j],end_time,tempbegin_poisson_index);
       				}

					begin_time=end_time;
					end_time=h+begin_time;
                        	       
                                        for (int i_num=0;i_num<totalnum;i_num++)
						{
  							tempbegin_poisson_index[i_num]=0;
      						}

					for (int i_num=0;i_num<totalnum;i_num++)
				{
					vector_destroy(poisson_input[i_num]);
				}

		}          

		else if(Flage==3)
		{
                                 for (int i_num=0;i_num<totalnum;i_num++)
 				{
  					poisson_generator(i_num,poisson_input[i_num],h);
 				}
				for (int i_num=0;i_num<totalnum;i_num++)
				{
    					single_neuron_test(tempneu,i_num,begin_time,Omega,y[j],end_time,tempbegin_poisson_index);
                                       //single_neuron_test_whole(tempneu,i_num,begin_time,Omega,y[j],end_time,tempbegin_poisson_index);
       				}

					begin_time=end_time;
					end_time=h+begin_time;
                        	       
                                        for (int i_num=0;i_num<totalnum;i_num++)
						{
  							tempbegin_poisson_index[i_num]=0;
      						}

					for (int i_num=0;i_num<totalnum;i_num++)
				{
					vector_destroy(poisson_input[i_num]);
				}

		}          

} //end? for(int j=0;j<N;j++)

for(int i_num=0;i_num<totalnum;i_num++)
	{
  		neuron_destroy(tempneu[i_num]);
	}
free(tempneu);
tempneu=NULL;

free(tempbegin_poisson_index);

if(ISI_SAVE==1)
{
for(int z=0;z<ISI0_P.size();z++)
	{ 
		if(z==0)
		{
			ISI_P.push_back(ISI0_P[z]);
		}
		else
        	{
	        	ISI_P.push_back(ISI0_P[z]-ISI0_P[z-1]);
        	}
	}
}


}
