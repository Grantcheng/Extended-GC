#include <cstdlib>
#include <vector>
#include <string>
#include <iostream>
#include<cmath>
#include<iomanip>
#include"HHconst.h"
#include"SHHfunction.h"

using namespace std;

    double v_p;
    double alphan_p,betan_p,alpham_p,betam_p,alphah_p,betah_p;
    
void voltage_p_dt(double t,vector<double> y,double gE, double gI,double &dv_dt)
{
/*	
dv_dt=(Current_0 + Current_1*sin(2*pi*y[4]))-(g_na_max*(pow(y[1],3))*y[2]*(y[0]-115) + g_k_max*(pow(y[3],4))*(y[0]+12) + g_l*(-10.6+y[0]))-gE*(y[0]-(Vot_Excitatory+65))-gI*(y[0]-(Vot_Inhibitory+65)); 
*/
dv_dt=(Current_0 + Current_1*sin(2*pi*y[4]))-(g_na_max*(pow(y[1],3))*y[2]*(y[0]-50) + g_k_max*(pow(y[3],4))*(y[0]+77) + g_l*(y[0]+54.387))-gE*(y[0]-(Vot_Excitatory))-gI*(y[0]-(Vot_Inhibitory)); 
}

void voltage_p_non_dt(double t,vector<double> y,double Omega,double gE, double gI,double &dv_dt)
{	
dv_dt=(Current_0 + Current_1*sin(2*pi*Omega*t))-(g_na_max*(pow(y[1],3))*y[2]*(y[0]-115) + g_k_max*(pow(y[3],4))*(y[0]+12) + g_l*(-10.6+y[0]))-gE*(y[0]-(Vot_Excitatory+65))-gI*(y[0]-(Vot_Inhibitory+65)); 
}

void m_p_dt(double t,double y_0, double y_1, double &dm_dt)
{
	/*
        v_p=y_0;
	//m channel
        alpham_p=0.1*(25-v_p)/(exp((25-v_p)/10)-1);
	      
	betam_p=4*exp(-v_p/18);
	dm_dt=(alpham_p-(alpham_p+betam_p)*y_1);
       */
        v_p=y_0;
	//m channel
        alpham_p=0.1*(v_p+40)/(1-exp(-(v_p+40)/10));
	      
	betam_p=4*exp(-(v_p+65)/18);
	dm_dt=(alpham_p-(alpham_p+betam_p)*y_1);
}

void h_p_dt(double t,double y_0, double y_2, double &dh_dt)
{
	/*
        v_p=y_0;
	//h channel
	alphah_p=0.07*exp(-v_p/20);
	betah_p=1/(exp((30-v_p)/10)+1);

	dh_dt=(alphah_p-(alphah_p+betah_p)*y_2);
        */
	v_p=y_0;
	//h channel
	alphah_p=0.07*exp(-(v_p+65)/20);
	betah_p=1/(exp(-(v_p+35)/10)+1);

	dh_dt=(alphah_p-(alphah_p+betah_p)*y_2);
}

void n_p_dt(double t,double y_0, double y_3,double &dn_dt)
	{
	/*
        v_p=y_0;
	//n channel
	alphan_p=0.01*(10-v_p)/(exp((10-v_p)/10)-1);
	
	betan_p=0.125*exp(-v_p/80);
	dn_dt=(alphan_p-(alphan_p+betan_p)*y_3);
	*/
        v_p=y_0;
	//n channel
	alphan_p=0.01*(v_p+55)/(1-exp(-(v_p+55)/10));
	
	betan_p=0.125*exp(-(v_p+65)/80);
	dn_dt=(alphan_p-(alphan_p+betan_p)*y_3);
       }


void q_p_dt(double t,double Omega_1, double &dqp_dt)
	{   
		dqp_dt=Omega_1;
	}
