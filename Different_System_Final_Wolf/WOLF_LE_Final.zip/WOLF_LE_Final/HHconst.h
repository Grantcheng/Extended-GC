#ifndef _HHconst_h_
#define _HHconst_h_
#include <cstdlib>
#include <stdio.h>
#include <vector>
#include <string>
#include <iostream>
#include <cmath>
#include <fstream>
#include <assert.h>
#include "neuron.h"
#include "loop.h"
#include <memory.h>
#include <fftw3.h>
using namespace std;

#define CM 1.0
#define e_na 50.0
#define e_k (-77.0)
#define e_l (-54.387)
#define e_vr (-65.0)
#define g_na_max 120.0
#define g_k_max 36.0
#define g_l 0.3
/*  Morris Lecar Model Parameters */
#define ML_C 0.05
#define ML_vca 120.0
#define ML_vk (-84.0)
#define ML_vl (-60.0)
#define ML_gca 4.4
#define ML_gk 8.0
#define ML_gl 2.0
#define ML_v1 (-1.2)
#define ML_v2 18.0
#define ML_v3 2.0
#define ML_v4 30.0
#define ML_phi (0.04)
/* Fitzhugh Nagumo Model Parameters */
#define FN_a 0.7
#define FN_b 0.8
#define FN_C 10.0
//--------------------------------------------
#define pi 3.141592653589793

#define Vot_Threshold -50.0
#define PI 3.14159265
#define Threshold_ML -56.365
#define Threshold_FN 3.0
#define f0 1/3
#define Convergence_Test 0//if =1 convergence elseif =0 formal run
#define Convergence_Test_0 1
#define Autonomy_Use 1
#define NumNeuron1 1 //0 ����Runge_Kutta4M����,1 ����Runge_Kutta4����
#define Runmainhh 0  // run one neuron HH system equation
#define Runmain_each_solution 1 // it is use to obtain each solution of system equation
#define Runmain_each_solution_range 0// index that the results is only one omega or a range of omega: 0 is one omega, 1 is range of omega
#define RunMumainHH 0 //double neuron program
#define Same_f 0 //if Same_f==0 is run the same omega; if Same_f==1 is run the different omega;
/* Follows is Compute Lyap exponents */
#define Lya_Computing_Start 1
#define Lya_Computing_Start_2 0//1 is the two neurons Lya

#define MUL_LYAPUNOV_EVOLUTION 1
#define HH_MUL_NUM_LYA 10
#define HH_MUL_NUM_LYA_SCI 4
#define FIRE_DEBUG 0
#define DEBUG_OUTPUT_ALL 0

#if Autonomy_Use
#define HH_Poisson_MUL_NUM_LYA 9
#else
#define HH_Poisson_MUL_NUM_LYA 8
#endif

#define ROOT_FIND_DEBUG 0

#define MUL_NUM_LYA 3 /* number of LE you want to compute;In single neuron
there exist five possible lyap exponents; In Multiple  neurons equation, there
exist multiple of seven */
#define Single_Neuron 1 //0 ʱ����MumainHH����,1 ����mainHH����
#define SMALL_DISPLACE (1.0e-8)
// this uses different orders of Runge-Kutta algorithm
#define RK4M 1
#define RK4 0

// the final stopping time of computation
//prevent the status of alpham1,alphan1
#define Epsilon (1.0e-16)
// whether use poisson input or current input
#define POISSON_INPUT_USE 0//-----------------------------------------------------------1 or 0
// whether use the smoothed conductance (meaning that we use more than one ODE to
// describe the rising and decay time scale of conductance)
#define SMOOTH_CONDUCTANCE_USE 1
#define FFTW_USE 0
#define NONE_INHIBITORY 0

// estimated maximum numerber of poisson input in each time step , if the input rate is really high,
// we should choose much larger number!
#define Maxnum_input 200
// estimated maximum times for searching a root, it is used in root_search function
#define Maxnum_search  50
//
//Channel Noise
#define Na_max 120000
#define K_max 36000
#define Channel_Noise 1
//*******************************8
extern int MUL_VAR_NUM; /* number of perturbed variables, the order is: voltagei, mi,hi,ni,Gi,G1i,qi,
where the i index the i th neuron*/
extern int Choice_HH_Ori;
extern int save_LLE_classic;//whether save the local lyapunov exponent in Lyapunov exponent computation.
extern double Tstep;

extern int Neuron_Type;
extern int Strength_Change;

extern vector<vector<double> > Lyapunov;
extern vector<double> Lp;
extern vector<string> sloution_name;
extern double OmegaStart;
extern double OmegaFinal;
extern int Save_each_solution;
extern double amp1;
// Morris Lecar: W_inf  ML_tauw  M_inf
extern double W_inf;
extern double ML_tauw;
extern double M_inf;
extern double chose_current_change;
//------------------------------------------------------------------------------------
string   double_to_str(   double   x   );
void FREE_1(vector<vector<double> > &Initial_1);
void FREE_2(vector<double> &Initial_2);
void setglobals_whitenoise();

// the following variables are the input reading from input file!
// this is time step used in the run
extern double Tstep;
// this is the ratre either in the current input case or poisson input case
extern double Rate_input;
// this is the Poisson input strength to ecitatory conductance
// it is not used in current unput case
extern double Strength_Exinput;
// the same as above but the Poisson input strength to inhibitory conductance
// normally, it is chosen as zero
extern double Strength_Ininput;
// in curren input case , the sinusoidal drive is given by
// Current_0+Current_1*sin(2*pi*Rate_input)
extern double Current_0;
extern double Current_1;
extern int COMP_TIME;
extern int choose_Sine_Poisson_SciF_SciW;
extern int Multi_Experiments;
extern int mul_exp_Final;
extern int mul_exp_Start;
//Channel Noise
extern double m_std;
extern double h_std;
extern double n_std;
//------------------------------------------------------------------------------------
#define NTAB 32 // ran1() using
// the resting value of excitatory conductance
#define Vot_Excitatory 0
// the resting value of inhibitory conductance
#define Vot_Inhibitory -80.0
// macro definition for neurons with excitatory type and inhibitory type
#define Type_Exneuron 1
#define Type_Inneuron 0
//------------------------------------------------------------------------------------

// this saves neuronal network information
extern struct neuron *neu;
// This saves the generated Poisson spike train for each neuron
extern struct vector_v *poisson_input;
// This saves the poisson spike train which use to computes the solutions after mul_lya_perturb_0
extern struct vector_v *poisson_input_ml;
// random seed for generating Poisson process
extern long *initialseed_neuron;
// this saves the first spike time of Poisson input outside the current time step
extern double *last_input;

extern int Lyap;
// these are used for generating random variables
extern long initial_pertub_Vot;
extern long initial_pertub_m;
extern long initial_pertub_h;
extern long initial_pertub_n;
#if POISSON_INPUT_USE
extern long initial_pertub_Ex;
extern long initial_pertub_In;
#if SMOOTH_CONDUCTANCE_USE
extern long initial_pertub_Ex_H;
extern long initial_pertub_In_H;
#endif
#endif
extern long initial_seed;
extern long* ran_iy;
extern long** ran_iv;
extern long gauss_seed;
extern int iset;
extern double gset;
extern long *initialseed_neuron_w;
extern long *ran_iy_w;
extern long **ran_iv_w;
//this saves the current time of computation, the dimension is "ms"
extern double time_evolution;
extern double last_time;

//Save ISI
extern int ISI_SAVE;
extern vector<double> ISI0_P; //Record the firetime
extern vector<double> ISI_P; // Record the ISI
extern vector<double> f_omega;

// The parameters that used in SCI1995 paper
extern double *WhiteNoise;
extern double *WhiteNoise_1;
extern double Mean_white;
extern double Sigma_white;
extern double tau;
extern double Omega_F_Sine;;
extern double FNN_Threshold;
extern int Caiyang;
extern int Sample_Step;
// the number of excitatory neurons
#define Number_Exneuron 2
// the number of inhibitory neurons
#define Number_Inneuron 0
// NumNeuron=Number_Exneuron+Number_Inneuron
#define NumNeuron 2

#define Time_ExCon 0.5  // decay time scale of Ex_conductance
// if we use smoothed excitatory conductance instead of jump conductance, we
// sholud have another ODE. this is the time scale in that ODE
#define Time_ExConR 3
#define Time_InCon 0.5  // decay time scale of In_conductance
// the same thing but for inhibitory conductance
#define Time_InConR 7
// the length of refractory period
#define TIME_FRACTORY 2.0

#if SMOOTH_CONDUCTANCE_USE
// this means using two ODEs to describe the dynamics of conductance
// therefore, the conductance is smooth with both rising and decay time scale
#define Stepsmooth_Con 2
#else
// this means using only one ODE to describe the dynamics of conductance
// therefore, the conductance only has decay time scale and inifinitely fast
// rising time scale (instantaneous jump)
#define Stepsmooth_Con 1
#endif


// the tolerance error for root searching
#define root_acc  (1.0e-12)

// the length of "data" stored in the neuron structure
// the first is saving voltage,
// the others saves the m,h,n and
// conductance part, there are maybe three case:
// (1) Ex_conductance after two step of smoothness (2) Ex_conductance after one step of smoothness, (3) Ex_conductance without smoothness
// (1) In_conductance after two step of smoothness (2) In_conductance after one step of smoothness, (3) In_conductance without smoothness
#if Autonomy_Use
#define size_neuronvar (2*Stepsmooth_Con+5) // there condier the autonomy part
#else
#define size_neuronvar (2*Stepsmooth_Con+4) // there not condier the autonomy part
#endif

// macro definition for neurons's state, whether it is ouside refractory or inside it
#define STATE_ACTIVE 1
#define STATE_RECFRACTORY 0

// macro definition for random number generating fuctions
#define RANDOM ran1
#define VOT_DEBUG 0

//additional assigned space for vectory structure
#define VECTOR_ADD_SIZE 50

#endif // _HHconst_h_
