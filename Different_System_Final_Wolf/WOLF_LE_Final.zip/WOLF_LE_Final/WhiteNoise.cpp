#include <iostream>
#include <math.h>
#include <fstream>
#include <cstdlib>
#include <stdio.h>
#include <time.h>
#include "random.h"
#include "HHconst.h"
#include <fftw3.h>
// #define	FRAME		50000
#define	VARIANCE	1.0
using namespace std;
//double	WhiteNoise[FRAME];

int	PdfCount[16];

//白噪声子程序
void	F_CreatWhiteNoise(double fSigma,int FRAME_1,int flage_channel)
{
	int		i;
	//int		nTemp;
	double	*RandomData1,*RandomData2;
        //srand(initial_seed);

        RandomData1=(double*)malloc(sizeof(double)*FRAME_1);
        RandomData2=(double*)malloc(sizeof(double)*FRAME_1);

	for(i=0;i<FRAME_1;i++)
	{
		/*
                do
		{	
			nTemp = rand();
		}
		while((nTemp==0)||(nTemp==RAND_MAX));
                */
		//RandomData1[i]=(double)nTemp/(double)RAND_MAX;
                 // RandomData1[i]=ran0(&initial_seed); 
               RandomData1[i]=ran1(initialseed_neuron_w+0,ran_iy_w,ran_iv_w,0); 
	}
	for(i=0;i<FRAME_1;i++)
	{
                /*
		do
		{	
			nTemp = rand();
		}
		while((nTemp==0)||(nTemp==RAND_MAX));
		RandomData2[i]=(double)nTemp/(double)RAND_MAX;
                */
                //RandomData2[i]=ran0(&initial_seed); 
                 RandomData2[i]=ran1(initialseed_neuron_w+0,ran_iy_w,ran_iv_w,0); 
	}

       if(flage_channel==0)
	{
             for(i=0;i<FRAME_1;i++)
	      {
		WhiteNoise[i] = sqrt(-2.0*fSigma*log(RandomData1[i]))*cos(2.0*PI*RandomData2[i]);
               // WhiteNoise_1[i] = sqrt(-2.0*fSigma*log(RandomData1[i]))*sin(2.0*PI*RandomData2[i]);
              }
        }
       else if(flage_channel==1)
	{
             for(i=0;i<FRAME_1;i++)
	      {
		WhiteNoise_1[i] = sqrt(-2.0*fSigma*log(RandomData1[i]))*sin(2.0*PI*RandomData2[i]);
              }
        }

//cout<<"RAND_MAX = "<<RAND_MAX<<endl;
cout<<endl;
}
double	F_ComputeMean(double* pData ,int nCount)
{
	int		i;
	double	LSum,LMean;
	LSum = 0.0;
	for(i=0;i<nCount;i++)
	{
		LSum += *pData;
		pData ++;
	}
	LMean = LSum/(double)nCount;
	return	LMean;
}
double	F_ComputeVar(double* pData ,int nCount)
{
	int		i;
	double	LSum,LPower,LData;
	double	LMean,LVariance;
	LSum = 0.0;
	LPower = 0.0;
	for(i=0;i<nCount;i++)
	{
		LData = *pData;
		LSum += LData;
		LPower += LData*LData;
		pData ++;
	}
	LMean = LSum/double(nCount);
	LVariance = LPower/double(nCount) - LMean*LMean;
	return	LVariance;
}
void	F_ComputePdf(int FRAME_2)
{
	int		i;
	double	LData;
	double	LSigma,LMean;
	LMean = F_ComputeMean(&WhiteNoise[0],FRAME_2);
	LSigma = sqrt(F_ComputeVar(&WhiteNoise[0],FRAME_2));
	for(i=0;i<16;i++)
	{
		PdfCount[i] = 0;
	}
	for(i=0;i<FRAME_2;i++)
	{
		LData = WhiteNoise[i];
		if(LData < (LMean - 3.5*LSigma))
		{
			PdfCount[0] ++;			
		}
		if((LData>(LMean-3.5*LSigma)) && (LData<(LMean-3.0*LSigma)))
		{
			PdfCount[1] ++;			
		}
		if((LData>(LMean-3.0*LSigma)) && (LData<(LMean-2.5*LSigma)))
		{
			PdfCount[2] ++;			
		}
		if((LData>(LMean-2.5*LSigma)) && (LData<(LMean-2.0*LSigma)))
		{
			PdfCount[3] ++;			
		}
		if((LData>(LMean-2.0*LSigma)) && (LData<(LMean-1.5*LSigma)))
		{
			PdfCount[4] ++;			
		}
		if((LData>(LMean-1.5*LSigma)) && (LData<(LMean-1.0*LSigma)))
		{
			PdfCount[5] ++;			
		}
		if((LData>(LMean-1.0*LSigma)) && (LData<(LMean-0.5*LSigma)))
		{
			PdfCount[6] ++;			
		}
		if((LData>(LMean-0.5*LSigma)) && (LData<LMean))
		{
			PdfCount[7] ++;			
		}
		if((LData>LMean) && (LData<(LMean+0.5*LSigma)))
		{
			PdfCount[8] ++;			
		}
		if((LData>(LMean+0.5*LSigma)) && (LData<(LMean+1.0*LSigma)))
		{
			PdfCount[9] ++;
		}
		if((LData>(LMean+1.0*LSigma)) && (LData<(LMean+1.5*LSigma)))
		{
			PdfCount[10] ++;
		}
		if((LData>(LMean+1.5*LSigma)) && (LData<(LMean+2.0*LSigma)))
		{
			PdfCount[11] ++;
		}
		if((LData>(LMean+2.0*LSigma)) && (LData<(LMean+2.5*LSigma)))
		{
			PdfCount[12] ++;
		}
		if((LData>(LMean+2.5*LSigma)) && (LData<(LMean+3.0*LSigma)))
		{
			PdfCount[13] ++;
		}
		if((LData>(LMean+3.0*LSigma)) && (LData<(LMean+3.5*LSigma)))
		{
			PdfCount[14] ++;
		}
		if(LData>(LMean+3.5*LSigma))
		{
			PdfCount[15] ++;
		}
	}
}

double WhilteNoise_fun(int FRAME)
{
	// FILE	*fp1,*fp2;;
	int		i;
        //double Variance;
        WhiteNoise=(double*)malloc(sizeof(double)*FRAME);
        //cout<<"The VARIANCE is "<<endl;
        //cin>>Variance;
        //setglobals_whitenoise();
	F_CreatWhiteNoise(1,FRAME,0);
	F_ComputePdf(FRAME);

/* 
	//存储噪声的采样值
	if((fp1 = fopen("noise.dat","w+")) == NULL)
	{
		printf("Open file error !");
		exit(1);
	};
	for(i=0;i<FRAME;i++)
	{
		fprintf(fp1,"%d %f\n",i,WhiteNoise[i]);
	}
	fclose(fp1);
	//存储噪声的概率分布
	if((fp2 = fopen("gausspdf.dat","w+")) == NULL)
	{
		printf("Open file 'gausspdf.dat' error !");
		exit(1);
	};
	for(i=0;i<16;i++)
	{
		fprintf(fp2,"%d %d\n",i-7,PdfCount[i]);
	}
	fclose(fp2); 
*/
}

double WhilteNoise_fun1(int FRAME)
{
	// FILE	*fp1,*fp2;;
	int		i;
        //double Variance;
        WhiteNoise_1=(double*)malloc(sizeof(double)*FRAME);
        //cout<<"The VARIANCE is "<<endl;
        //cin>>Variance;
        //setglobals_whitenoise();
	F_CreatWhiteNoise(1,FRAME,1);
}
