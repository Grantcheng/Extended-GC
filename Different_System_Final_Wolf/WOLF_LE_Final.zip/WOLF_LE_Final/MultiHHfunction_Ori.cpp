#include <cstdlib>
#include <vector>
#include <string>
#include <iostream>
#include <cmath>
#include "HHconst.h"
#include"THHfunciton.h"
using namespace std;
double v_2;
double alphan2,betan2,alpham2,betam2,alphah2,betah2;
double SUM2(double x, double y);
/*double vectordoubleSum(vector<double>::iterator first, vector<double>::size_type size);vector ÇóºÍ*/

void voltageio_dt(double t,vector<double> y,vector<double> amp,vector<double> &dv_dt)
{
		for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
		{
		int y6=7*NumNeuronth-1;
		int y1=1+7*(NumNeuronth-1);
		int y0=7*(NumNeuronth-1);
		int y2=2+7*(NumNeuronth-1);
		int y3=3+7*(NumNeuronth-1);
		int y4=4+7*(NumNeuronth-1);
		dv_dt[NumNeuronth-1]=(amp[NumNeuronth-1]+sin(2*pi*y[y6]))-(g_na_max*(pow(y[y1],3))*y[y2]*(y[y0]-50) + g_k_max*(pow(y[y3],4))*(y[y0]+77) + g_l*(54.387+y[y0]))-y[y4]*(y[y0]);
	       }
}
    void mio_dt(double t,vector<double> y, vector<double> &dm_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
	      int y1=1+7*(NumNeuronth-1);
	      v_2=y[7*(NumNeuronth-1)];
	      //m channel
	      alpham2=0.1*(v_2+40)/(1-exp(-(v_2+40)/10));
	      betam2=4*exp(-(v_2+65)/18);
	      dm_dt[NumNeuronth-1]=(alpham2-(alpham2+betam2)*y[y1]);
	}
}
	void hio_dt(double t,vector<double> y,vector<double> &dh_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
	      int y2=2+7*(NumNeuronth-1);
	      v_2=y[7*(NumNeuronth-1)];
	      //h channel
	      alphah2=0.07*exp(-(v_2+65)/20);
	      betah2=1/(exp(-(35+v_2)/10)+1);
	      dh_dt[NumNeuronth-1]=(alphah2-(alphah2+betah2)*y[y2]);
	}
}
	void nio_dt(double t,vector<double> y, vector<double> &dn_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
	      int y3=3+7*(NumNeuronth-1);
	      v_2=y[7*(NumNeuronth-1)];
	      //n channel
	      alphan2=0.01*(v_2+55)/(1-exp(-(v_2+55)/10));
	      betan2=0.125*exp(-(v_2+65)/80);
	      dn_dt[NumNeuronth-1]=(alphan2-(alphan2+betan2)*y[y3]);
	}
}
	void Gio_dt(double t,vector<double> y,vector<double> &G_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
		int y4=4+7*(NumNeuronth-1);
		int y5=5+7*(NumNeuronth-1);
		G_dt[NumNeuronth-1]=y[y5]-y[y4]/Time_ExCon;
	}

}
	void G1io_dt(double t,vector<double> y,vector<vector<double> >  Couple,vector<double> &G_dt)
{
	
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
		double sum=0;
		int y5=5+7*(NumNeuronth-1);
		for(int PreNeuron=0;PreNeuron<NumNeuron;PreNeuron++)
		{
		int y7=7*(PreNeuron);
		sum=SUM2(Couple[NumNeuronth-1][PreNeuron]*(1/(1+exp(-(y[y7]-20)/2))),sum);
		}
		G_dt[NumNeuronth-1]= -(y[y5]/Time_ExConR)+sum;
	}
}
	void qio_dt(double t,vector<double> Omega,vector<double> &dq_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
	   dq_dt[NumNeuronth-1]=Omega[NumNeuronth-1];
	}
}

	double SUM2(double x, double y)
	{
		return (x+y);
	}
