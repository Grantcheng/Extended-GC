#include <cstdlib>
#include <vector>
#include <string>
#include <iostream>
#include <cmath>
#include <iomanip>
#include "Duffing_Equation.h"
#include "HHconst.h"
#include "tau_const.h"
using namespace std;

//revised 13/06/2012 by GrantCheng   SJTU  
/*
function dy=duffing(t,y) 
% duffing equation for integration 
global alpha beta gamma f omega 
dy=[y(2);-alpha*y(1)-beta*y(1)^3-gamma*y(2)+f*cos(y(3));Omega];
*/
// Morris Lecar: W_inf  ML_tauw  M_inf
double W_inf;
double ML_tauw;
double M_inf;
double Wm_inf;
double MLm_tauw;
double SUML2(double x, double y);
//---------------------Duffing Equation------------------------------------
void x_dt(double t,double y_2,double &dx_dt)
{
	dx_dt=y_2;
}

void y_dt(double t,double y_2, double y_1,double y_3, double alpha,double beta,double gamma,double force,double &dy_dt)
{        
	dy_dt=alpha*y_1-beta*pow(y_1,3)-gamma*y_2+force*cos(y_3);
}

void q_dt(double t,double Omega, double &dq_dt)
{   
	dq_dt=Omega;
}

//-------------------------Lorenz Equation --------------------------------
void Lx_dt(double t, vector<double> Ly, double &dx_dt)
{
   dx_dt=16*(Ly[1]-Ly[0]);
}

void Ly_dt(double t, vector <double> Ly,double &dy_dt)
{
 dy_dt=Ly[0]*(45.92-Ly[2])-Ly[1];
}

void Lz_dt(double t, vector<double> Ly, double &dz_dt)
{
 dz_dt=Ly[0]*Ly[1]-(4)*Ly[2];
}


//-------------------------Rossler Equation --------------------------------
void Rx_dt(double t, vector<double> Ly, double &dx_dt)
{
   dx_dt=-Ly[2]-Ly[1];
}

void Ry_dt(double t, vector <double> Ly,double &dy_dt)
{
 dy_dt=Ly[0]+0.15*Ly[1];
}

void Rz_dt(double t, vector<double> Ly, double &dz_dt)
{
 dz_dt=0.2+Ly[2]*(Ly[0]-10);
}

//-------------------------Morris Lecar --------------------------------

// Single Neuron
//Chaotic state:
/*
void MLv0_dt(double t, vector<double> ML_y, double Omega_ml, double &dv_dt)
{
 M_inf=0.5*(1.0+tanh((ML_y[0]-ML_v1)/ML_v2));
 //dv_dt=((amp1+Current_1*sin(2*pi*ML_y[2]))-(ML_gca*(M_inf)*(ML_y[0]-ML_vca) + ML_gk*(ML_y[1])*(ML_y[0]-ML_vk) + ML_gl*(ML_y[0]-ML_vl)))*ML_C/Omega_ml; 
 dv_dt=((amp1+Current_0*sin(2*pi*t)+Current_1*sin(2*pi*ML_y[2]))-(ML_gca*(M_inf)*(ML_y[0]-ML_vca) + ML_gk*(ML_y[1])*(ML_y[0]-ML_vk) + ML_gl*(ML_y[0]-ML_vl)))*ML_C/Omega_ml; 
}

void MLw0_dt(double t, vector <double> ML_y,double Omega_ml,double &dw_dt)
{
 W_inf=0.5*(1.0+tanh((double)(ML_y[0]-ML_v3)/(double)ML_v4));
 ML_tauw=1.0/(double)(cosh((ML_y[0]-ML_v3)/(2.0*ML_v4)));
 dw_dt=(double)ML_phi*(double)(W_inf-ML_y[1])/(ML_tauw*Omega_ml);
}

void Mqq0_dt(double t,vector<double> ML_y,double Omega, double &Mqq_dt)
{   
Mqq_dt=ML_y[1];
}
*/

// Original ML

void MLv0_dt(double t, vector<double> ML_y, double Omega_ml, double &dv_dt)
{
 M_inf=0.5*(1.0+tanh((ML_y[0]-ML_v1)/ML_v2));
 dv_dt=((amp1+Current_0*sin(2*pi*ML_y[2]))-(ML_gca*(M_inf)*(ML_y[0]-ML_vca) + ML_gk*(ML_y[1])*(ML_y[0]-ML_vk) + ML_gl*(ML_y[0]-ML_vl)))*ML_C; 
}

void MLw0_dt(double t, vector <double> ML_y,double Omega_ml,double &dw_dt)
{
 W_inf=0.5*(1.0+tanh((double)(ML_y[0]-ML_v3)/(double)ML_v4));
 ML_tauw=1.0/(double)(cosh((ML_y[0]-ML_v3)/(2.0*ML_v4)));
 dw_dt=(double)ML_phi*(double)(W_inf-ML_y[1])/(ML_tauw);
}

void Mqq0_dt(double t,vector<double> ML_y,double Omega, double &Mqq_dt)
{   
Mqq_dt=Omega;
}


// Two Neurons

//Lim 2009 Paper:
void MLv0_mdt(double t,vector<double> ML_y,vector<double> amp,vector<double> Omega,vector<double> &dv_dt)
{

for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
 {
 int y3=4*NumNeuronth-1;
 int y1=1+4*(NumNeuronth-1);
 int y0=4*(NumNeuronth-1);
 int y2=2+4*(NumNeuronth-1);
 
 M_inf=0.5*(1.0+tanh((ML_y[y0]-ML_v1)/ML_v2));
 dv_dt[NumNeuronth-1]=((amp[NumNeuronth-1]+Current_0*sin(2*pi*t)+Current_1*sin(2*pi*ML_y[y3]))-(ML_y[y2]*(ML_y[y0]))-(ML_gca*(M_inf)*(ML_y[y0]-ML_vca) + ML_gk*(ML_y[y1])*(ML_y[y0]-ML_vk) + ML_gl*(ML_y[y0]-ML_vl)))*ML_C/Omega[NumNeuronth-1];
 
 }

}

    void MLw0_mdt(double t,vector<double> ML_y, vector<double> Omega,vector<double> &dw_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
	      int y0=4*(NumNeuronth-1);
	      int y1=1+4*(NumNeuronth-1);

              Wm_inf=0.5*(1.0+tanh((double)(ML_y[y0]-ML_v3)/(double)ML_v4));
              MLm_tauw=1.0/(double)(cosh((ML_y[y0]-ML_v3)/(2*ML_v4)));
              dw_dt[NumNeuronth-1]=(double)ML_phi*(double)(Wm_inf-ML_y[y1])/(MLm_tauw*Omega[NumNeuronth-1]);
	}
}

	void Gm0_dt(double t,vector<double> y,vector<vector<double> >  Couple,vector<double> &G_dt)
{
	
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
		double sum=0;
		int y2=2+4*(NumNeuronth-1);
		for(int PreNeuron=0;PreNeuron<NumNeuron;PreNeuron++)
		{
		int y4=4*(PreNeuron);
		sum=SUML2(Couple[NumNeuronth-1][PreNeuron]*(1/(1+exp(-(y[y4]-20)/2))),sum);
		}
		G_dt[NumNeuronth-1]= -(y[y2]/0.5)+sum;
	}
}

	void Mqqm0_dt(double t,vector<double> ML_y,vector<double> Omega,vector<double> &dq_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
	   dq_dt[NumNeuronth-1]=ML_y[4*(NumNeuronth-1)+1];
	}
}

	double SUML2(double x, double y)
	{
		return (x+y);
	}




//***************************************************************************************
/*
void MLv0_mdt(double t,vector<double> ML_y,vector<double> amp,double Omega_ml,vector<double> &dv_dt)
{

for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
 {
 int y3=4*NumNeuronth-1;
 int y1=1+4*(NumNeuronth-1);
 int y0=4*(NumNeuronth-1);
 int y2=2+4*(NumNeuronth-1);
 M_inf=0.5*(1.0+tanh((ML_y[y0]-ML_v1)/ML_v2));
 dv_dt[NumNeuronth-1]=((amp[NumNeuronth-1]+Current_0*sin(2*pi*ML_y[y3]))-(ML_y[y2]*(ML_y[y0]))-(ML_gca*(M_inf)*(ML_y[y0]-ML_vca) + ML_gk*(ML_y[y1])*(ML_y[y0]-ML_vk) + ML_gl*(ML_y[y0]-ML_vl)))*ML_C; 
 }

}

    void MLw0_mdt(double t,vector<double> ML_y, double Omega_ml,vector<double> &dw_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
	      int y0=4*(NumNeuronth-1);
	      int y1=1+4*(NumNeuronth-1);

              Wm_inf=0.5*(1.0+tanh((double)(ML_y[y0]-ML_v3)/(double)ML_v4));
              MLm_tauw=1.0/(double)(cosh((ML_y[y0]-ML_v3)/(2*ML_v4)));
              dw_dt[NumNeuronth-1]=(double)ML_phi*(double)(Wm_inf-ML_y[y1])/(MLm_tauw);
	}
}

	void Gm0_dt(double t,vector<double> y,vector<vector<double> >  Couple,vector<double> &G_dt)
{
	
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
		double sum=0;
		int y2=2+4*(NumNeuronth-1);
		for(int PreNeuron=0;PreNeuron<NumNeuron;PreNeuron++)
		{
		int y4=4*(PreNeuron);
		sum=SUML2(Couple[NumNeuronth-1][PreNeuron]*(1/(1+exp(-(y[y4]-20)/2))),sum);
		}
		G_dt[NumNeuronth-1]= -(y[y2]/0.5)+sum;
	}
}

	void Mqqm0_dt(double t,vector<double> ML_y,vector<double> Omega,vector<double> &dq_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
	   dq_dt[NumNeuronth-1]=Omega[NumNeuronth-1];
	}
}

	double SUML2(double x, double y)
	{
		return (x+y);
	}
*/

//-------------------------Fithugh Nagumo --------------------------------
void FNv_dt(double t, vector<double> FN_y, double &dv_dt)
{
  
 dv_dt=((amp1+sin(2*pi*FN_y[2]))-FN_y[1]+FN_y[0]-pow(FN_y[0],3)/3.0)*FN_C; 
}

void FNw_dt(double t, vector <double> FN_y,double &dw_dt)
{
  dw_dt=FN_a+FN_y[0]-FN_b*FN_y[1];
}

void Fqq_dt(double t,double Omega, double &Fqq_dt)
{   
Fqq_dt=Omega;
}

