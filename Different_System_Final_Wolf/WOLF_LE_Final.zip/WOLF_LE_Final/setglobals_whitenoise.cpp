#include <iostream>
#include <math.h>
#include <fstream>
#include <cstdlib>
#include <stdio.h>
#include <time.h>
#include "random.h"
#include "HHconst.h"
#include <fftw3.h>
using namespace std;

void setglobals_whitenoise()
{

	// record the initial random seed for each neuron!
	initialseed_neuron_w = (long *)malloc(sizeof(long)*1); 
	assert(initialseed_neuron_w);
	 

	ran_iy_w = (long *)malloc(sizeof(long)*1);
	ran_iv_w = (long **)malloc(sizeof(long*)*1);
	for (int ii=0; ii<1; ii++)
	{
		ran_iy_w[ii] = 0;
		ran_iv_w[ii] = (long*)malloc(sizeof(long)*32);
	}
     
/*
       srand(initial_seed);
	for(int ii = 0; ii < 1; ii++ )
	{
		initialseed_neuron_w[ii] = (long) -rand();
        }
*/
}
