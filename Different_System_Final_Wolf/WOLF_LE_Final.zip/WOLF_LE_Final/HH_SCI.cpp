#include <iostream>
#include <cmath>
#include <iomanip>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <sstream>
#include <vector>
#include <fftw3.h>
#include "HHconst.h"
#include "SHHfunction.h"
#include "THHfunciton.h"
#include "convergence.h"
#include "RK4.h"
#include "Lya_input.h"
#include "save.h"
#include "poisson_input.h"
#include "datainput.h"
#include "neuron.h"
#include "loop.h"
#include "Hermit_RootSearch.h"
#include "random.h"
#include "WhiteNoise.h"
#include "Convolutional.h"
#include "Different_System_RK4.h"
#include "malloc.h" 
using namespace std;
/*
fftw_complex *out;
fftw_complex *out1;
fftw_complex *out2;
fftw_complex  *in;
fftw_complex  *in1;
fftw_complex  *in2;
fftw_plan p;
fftw_plan p1;
fftw_plan p2;
*/
int Non_Convergence=0;
void save_solution(vector<double> DATA,string fname);
void spiking_time_SCI(vector<vector<double> > y_spike,int index,double Ta,double Tb,double &firing_time)
{
	double va=y_spike[index-1][0];
	 double dva = 0; // initialization
	
	//void voltage_sci_dt(double t,vector<double> y,double Input,double &dv_dt)
            voltage_sci_dt(Ta,y_spike[index-1],0,dva);
	
        double vb=y_spike[index][0];
	double dvb = 0; // initialization

	//voltage_dt(index_neuron,(t_evolution+Tb-Ta),gEb,gIb,vb,dvb);
          voltage_sci_dt(Tb,y_spike[index],0,dvb);

	firing_time = root_search(hermit, Ta, Tb, va, vb, dva, dvb, root_acc);
}

//*********************************************************************************
void HH_SCI_ISIJin(int N, double Dt,int Flage_sci_flat_white,vector<double> y_0, vector<double> Omega,double *out_y)
{
fftw_plan ph;
fftw_plan ph1;
fftw_plan ph2;
fftw_complex *outh;
fftw_complex *outh1;
fftw_complex *outh2;
fftw_complex  *inh;
fftw_complex  *inh1;
fftw_complex  *inh2;
int Frame;
double Tstart=0;
//double h=0.01;
double h=Dt;
int i;
int solution_num=1;
//double h_0=pow(0.5,(14));// convergence test ,the time evolution,RK4 step
double h_0=(double)1/1024;
vector<double> SpikeTime;
vector<vector<double> > HH_solution;
vector<vector<double> > HH_solution_Mean;

vector<double> T0;
vector<vector<double> > y;
vector<string> sloution_name;
vector<string> sloution_name_mean;
int Time=128;//convergence test ,the time evolution
int N_0;//convergence test ,the time evolution
N_0=1204*Time;//convergence test ,the time evolution
int totalnum=1;
int num_neuron = Number_Exneuron + Number_Inneuron;
double *Flate_Current=(double *)malloc((2*N+1)*sizeof(double));
int N_Length;
double h_white;
struct array lbq;
//struct array a,lbq,Lbq_WhiteNoise;
double *White_Noise;
double Varance;
vector<double> ISI0;
vector<vector<double> > ISI;
vector<double> ISI0_Mean;
vector<vector<double> > ISI_Mean;

cout<<"Convergence_Test_0 = "<<Convergence_Test_0<<endl;
cout<<"Vot_Threshold = "<<Vot_Threshold<<endl;
if(Non_Convergence==0)
{
#if Convergence_Test_0  //Test convergence of the single neuron program
double T0_convergence;
vector<double> y_convergence;
cout<<" Running Convergence Test "<<endl;

cout<<"Test Sci Convergence "<<endl;
cout<<endl;
//Convergence_Sci(y_0,Tstart,N_0,h_0,Flage_sci_flat_white,y_convergence,T0_convergence,Time);

#endif
}

#if Channel_Noise
cout<<"Na_max = "<<Na_max<<endl;
cout<<"K_max = "<<K_max<<endl;
#endif
//***********************Multiple Experiments**********************************
if(Flage_sci_flat_white==2 || Flage_sci_flat_white==3)
{
       Frame=2*N-1;

        inh=(fftw_complex *) fftw_malloc(sizeof(fftw_complex)*Frame);
        inh1=(fftw_complex *) fftw_malloc(sizeof(fftw_complex )*Frame);
        
        outh=(fftw_complex*)fftw_malloc(sizeof(fftw_complex)*Frame);
        outh1=(fftw_complex*)fftw_malloc(sizeof(fftw_complex)*Frame);

        ph=fftw_plan_dft_1d(Frame,inh,outh,FFTW_FORWARD,FFTW_ESTIMATE);
        ph1=fftw_plan_dft_1d(Frame,inh1,outh1,FFTW_FORWARD,FFTW_ESTIMATE);

        inh2=(fftw_complex *)fftw_malloc(sizeof(fftw_complex )*Frame);
        outh2=(fftw_complex*)fftw_malloc(sizeof(fftw_complex)*Frame);
        ph2 = fftw_plan_dft_1d(Frame,outh2,inh2,FFTW_BACKWARD,FFTW_ESTIMATE);

}
setglobals_whitenoise();
/*
srand(initial_seed);
	for(int ii = 0; ii < 1; ii++ )
	{
		initialseed_neuron_w[ii] = (long) -rand();
        }
*/
if(Multi_Experiments==2)
{
 initial_seed=time(NULL);
 cout<<"initial_seed = "<<initial_seed<<endl;
}
else
{
initial_seed=20072007;
cout<<"initial_seed = "<<initial_seed<<endl;
}
// Compute the HH dynamical system, and obtain the solution of the HH model
if(Flage_sci_flat_white==1)
{
  
  //N_Length=2*(N-10000);
  
  //产生Flate Current
  for (i=0;i<(2*N+1);i++)
   {
      
          Flate_Current[i]=Mean_white;
       
    }
     /*
     cout<<" Now is running the SCI_Flate_Current case! "<<endl;
     //Runge_Kutta4(y_0,Omega,Tstart,N,h,y,T0,voltageo_dt,mo_dt,ho_dt,no_dt,qqo_dt);
     HH_Sci_Flate_RK4(y_0,Tstart,N,h,y,T0,Flate_Current,voltage_sci_dt,m_sci_dt,h_sci_dt,n_sci_dt);
     */
}
else if(Flage_sci_flat_white==2 || Flage_sci_flat_white==3)
{
        //setglobals_whitenoise();

        White_Noise=(double *)malloc((N+1)*sizeof(double));
        h_white=h;
        // 产生高斯白噪声
        WhilteNoise_fun(N);
        //free(initialseed_neuron_w);
        //initialseed_neuron_w=NULL;
        // 高斯噪声通过一个滤波器 f(t)=t*exp(-t/ts)
        

        //a.length =2*N;
       // lbq.length =N;
        //a.pStart =new float [a.length ];
       // lbq.pStart =new float [lbq.length ];
        //for (i=0;i<lbq.length;i++)
	//{
	//*(lbq.pStart+i)=(i*h_white)*exp(-i*h_white/tau);
	// cout<<*(a.pStart+i)<<"   ";
	//}
/*
        for (i=0;i<a.length;i++)
	{
	*(a.pStart+i)=Mean_white+Sigma_white*WhiteNoise[i];//obey mean=Mean_white and Sigma=Sgima_white norm distribution;
	// cout<<*(a.pStart+i)<<"   ";
	}
        Lbq_WhiteNoise=conv(a,lbq);
*/


      for(i=0;i<N;i++)
        {
            //inh[i][0]=Sigma_white*sqrt(h_white)*WhiteNoise[i]; //The incretement
            inh[i][0]=WhiteNoise[i]; //The incretement
            inh[i][1]=0;
            inh1[i][1]=0;
            inh1[i][0]=h_white*(i*h_white)*exp(-i*h_white/tau);  //奥本海姆《《离散时间信号处理》》130页，连续时间冲击相应函数和离散时间单位脉冲相应之间存在关系：h[n]=T*h_c[n*T]
          //inh1[i][0]=(i*h_white)*exp(-i*h_white/tau); 
         }            
      for(i=N;i<Frame;i++)
        {
            inh[i][0]=0;
            inh[i][1]=0;
            inh1[i][1]=0;
           // in1[i][0]=h_white*(i*h_white)*exp(-i*h_white/tau);  //奥本海姆《《离散时间信号处理》》130页，连续时间冲击相应函数和离散时间单位脉冲相应之间存在关系：h[n]=T*h_c[n*T]
            inh1[i][0]=0; 
         }          

        fftw_execute(ph); 
        fftw_execute(ph1); 



        for(i=0;i<Frame;i++)
         {
           outh2[i][0]=outh[i][0]*outh1[i][0]-outh[i][1]*outh1[i][1];
           outh2[i][1]=outh[i][0]*outh1[i][1]+outh[i][1]*outh1[i][0];
          }

        

        fftw_execute(ph2); 

        

        for (i=0;i<(N+1);i++)
        {
            White_Noise[i]=inh2[i][0]/(Frame);
            //White_Noise[i]=sqrt(h_white)*White_Noise[i];
           // White_Noise[i]=Mean_white+Sigma_white*White_Noise[i];
         }

        
        Varance=F_ComputeVar(White_Noise ,N+1);
       for (i=0;i<(N+1);i++)
        {
           White_Noise[i]=Mean_white+(Sigma_white/sqrt(Varance))*White_Noise[i];
        }

        // test the white noise
        FILE	*fp1,*fp2,*fp4;
        FILE    *fp0;
        int FRAME=N;
     //存储滤波器件采样数
        if((fp4 = fopen("lbq.dat","w+")) == NULL)
	{
		printf("Open file error !");
		exit(1);
	};
	for(i=0;i<FRAME;i++)
	{
		fprintf(fp4,"%d %f\n",i,inh1[i][0]);
	}
	fclose(fp4);

        //存储滤波后的高斯白噪声
        if((fp0 = fopen("afterlbnoise.dat","w+")) == NULL)
	{
		printf("Open file error !");
		exit(1);
	};
	for(i=0;i<FRAME;i++)
	{
		fprintf(fp0,"%d %f\n",i,White_Noise[i]);
	}
	fclose(fp0);
	//存储噪声的采样值
	if((fp1 = fopen("noise.dat","w+")) == NULL)
	{
		printf("Open file error !");
		exit(1);
	};
	for(i=0;i<FRAME;i++)
	{
		fprintf(fp1,"%d %f\n",i,inh[i][0]);
	}
	fclose(fp1);
/*
        //存储噪声的概率分布
	if((fp2 = fopen("gausspdf.dat","w+")) == NULL)
	{
		printf("Open file 'gausspdf.dat' error !");
		exit(1);
	};
	for(i=0;i<16;i++)
	{
		fprintf(fp2,"%d %d\n",i-7,PdfCount[i]);
	}
	fclose(fp2); 
*/
/*
   if(Flage_sci_flat_white==2)
     {
      cout<<" Now is running the SCI_White_Noise case! "<<endl;
      HH_Sci_White_Milstein(y_0,Tstart,N,h,y,T0,White_Noise,voltage_sci_dt,m_sci_dt,h_sci_dt,n_sci_dt);
     }
   else if(Flage_sci_flat_white==3)
     {
      cout<<" Now is running the SCI_White_Noise + Sine case! "<<endl;
      HH_Sci_White_Sine_Milstein(y_0,Tstart,N,h,y,T0,White_Noise,voltage_sci_1_dt,m_sci_dt,h_sci_dt,n_sci_dt);
     }
*/
      free(WhiteNoise);
      WhiteNoise=NULL;
      
      //free(White_Noise);
     // White_Noise=NULL;
}

for(int mul_ex_1=(mul_exp_Start-1); mul_ex_1<mul_exp_Final;mul_ex_1=(mul_ex_1+1))
{

if(Multi_Experiments==2)
{
 initial_seed=time(NULL);
 cout<<"initial_seed = "<<initial_seed<<endl;
}
else
{
initial_seed=20072007;
cout<<"initial_seed = "<<initial_seed<<endl;
}

cout<<"Na_max = "<<Na_max<<endl;
#if Runmain_each_solution_range
for (int a=0;a<solution_num;a++)
{
sloution_name.push_back("HH_Solution("+double_to_str(3*OmegaStart)+"-"+double_to_str(3*OmegaFinal)+")w1_"+double_to_str(a)+"_"+double_to_str(Omega[0]));
}
#else
for (int a=0;a<solution_num;a++)
{
     if(Flage_sci_flat_white==2)
      {
         sloution_name.push_back("HH_Solution_w1_"+double_to_str(Omega[0])+"_"+double_to_str(mul_ex_1)+"_"+double_to_str(a));
         if(mul_ex_1==0)
           {
              sloution_name_mean.push_back("HH_Solution_Mean_w1_"+double_to_str(Omega[0])+"_"+double_to_str(a));
           }
       }
     else if(Flage_sci_flat_white==3)
       {
          sloution_name.push_back("HH_Solution_w1_White_Sine_"+double_to_str(Omega[0])+"_"+double_to_str(mul_ex_1)+"_"+double_to_str(a));
          if(mul_ex_1==0)
            {
              sloution_name_mean.push_back("HH_Solution_Mean_w1_White_Sine_"+double_to_str(Omega[0])+"_"+double_to_str(a));
            }
        }
}
#endif
//*****************************************************************************************
        srand(initial_seed);
	for(int ii = 0; ii < 1; ii++ )
	{
		initialseed_neuron_w[ii] = (long) -rand();
        }
        cout<<"White Noise: Mean_white=  "<<Mean_white<<"  Sigma_white=  "<<Sigma_white<<"  tau=   "<<tau<<endl;
        WhilteNoise_fun1(N);

if(Flage_sci_flat_white==1)
{
     cout<<" Now is running the SCI_Flate_Current case! "<<endl;
     //Runge_Kutta4(y_0,Omega,Tstart,N,h,y,T0,voltageo_dt,mo_dt,ho_dt,no_dt,qqo_dt);
     HH_Sci_Flate_RK4(y_0,Tstart,N,h,y,T0,Flate_Current,voltage_sci_dt,m_sci_dt,h_sci_dt,n_sci_dt);
}
else if(Flage_sci_flat_white==2 || Flage_sci_flat_white==3)
{
   if(Flage_sci_flat_white==2)
     {
      cout<<" Now is running the SCI_White_Noise case! "<<endl;
      HH_Sci_White_Milstein(y_0,Tstart,N,h,y,T0,White_Noise,voltage_sci_dt,m_sci_dt,h_sci_dt,n_sci_dt);
     }
   else if(Flage_sci_flat_white==3)
     {
      cout<<" Now is running the SCI_White_Noise + Sine case! "<<endl;
      HH_Sci_White_Sine_Milstein(y_0,Tstart,N,h,y,T0,White_Noise,voltage_sci_1_dt,m_sci_dt,h_sci_dt,n_sci_dt);
     }
}
        free(WhiteNoise_1); 
        WhiteNoise_1=NULL;
//*****************************************************************************************
HH_solution.resize(solution_num);

for (int Num=0;Num<solution_num;Num++)
    {
	HH_solution[Num].resize(T0.size());
       
    }
//***************************************************

SpikeTime.resize(T0.size());

ISI.resize(1);
ISI_Mean.resize(1);
//int i=0;

for (int k=0;k<T0.size();k++)
{
	SpikeTime[k]=y[k][0]-Vot_Threshold;//Vot_Threshold
	for (int s_num=0;s_num<solution_num;s_num++)
		{
			
			HH_solution[s_num][k]=y[k][s_num];
                        out_y[k]=y[k][s_num];
	
	    }
}


// save each solution of the HH system equation
#if Runmain_each_solution
for (int s_num=0;s_num<solution_num;s_num++)
{save_solution(HH_solution[s_num],sloution_name[s_num]);}
#endif

if(mul_ex_1==0)
{
HH_solution_Mean.resize(solution_num);
for (int Num=0;Num<solution_num;Num++)
    { 
      HH_solution_Mean[Num].resize(T0.size());
    }
for (int Num=0;Num<solution_num;Num++)
    { 
       for(int hh_solu_i=0;hh_solu_i<T0.size();hh_solu_i++)
        {
          HH_solution_Mean[Num][hh_solu_i]=0;
        }
    }
}

for (int Num=0;Num<solution_num;Num++)
    { 
for(int hh_solu_i=0;hh_solu_i<T0.size();hh_solu_i++)
        {
          HH_solution_Mean[Num][hh_solu_i]+=HH_solution[Num][hh_solu_i];
        }
     }

while (!sloution_name.empty())
				{
					sloution_name.pop_back();
				}

FREE_1(HH_solution);
//*************************************************************************************************************
// Compute ISI and Save ISI
int compute_ISI_HH=1;

//*************Save ISI**********

if(compute_ISI_HH==1)
{
double firing_time = 0;
vector<double>f_omega;
//*********************************************************************************************
string ISI_fname;
string ISI_f_fname;
string Spike_Timing;

if(Flage_sci_flat_white==2)
{
ISI_fname="ISI_SCI_White("+double_to_str(OmegaStart)+"_"+double_to_str(OmegaFinal)+")";
ISI_f_fname="ISI_SCI_White("+double_to_str(OmegaStart)+"_"+double_to_str(OmegaFinal)+")_f";
Spike_Timing="Spike_Timing("+double_to_str(Omega[0])+"_"+double_to_str(mul_ex_1)+")SCI_White";
}	
else if(Flage_sci_flat_white==3)
{
ISI_fname="ISI_SCI_White_Sine("+double_to_str(OmegaStart)+"_"+double_to_str(OmegaFinal)+")";
ISI_f_fname="ISI_SCI_White_Sine("+double_to_str(OmegaStart)+"_"+double_to_str(OmegaFinal)+")_f";
Spike_Timing="Spike_Timing("+double_to_str(Omega[0])+"_"+double_to_str(mul_ex_1)+")SCI_White_Sine";
}
//********************************************************************************************	

int spike_i=0;
for (int j=1;j<SpikeTime.size();j++)
{
	/*
      if (SpikeTime[j]>=0 && SpikeTime[j-1]<0)
	{
		ISI0.push_back(T0[j]);
		i++;
	}
       */
if ((SpikeTime[j]>=0) &&(SpikeTime[j-1]<0) )
{
spiking_time_SCI(y,j,T0[j-1],T0[j],firing_time);//(double va,double vot_cross,double Ta,double Tb,double &firing_time)
ISI0.push_back(firing_time); // Record the spiking time
spike_i++;
}

}

for(int z=0; z<spike_i;z++)
{
	if(z==0)
	{
		ISI[0].push_back(ISI0[z]);
	}
	else
        {
	        ISI[0].push_back(ISI0[z]-ISI0[z-1]);
        }
}
//return ISI;
if(mul_ex_1==0)
{
ISI_Mean[0].resize(ISI[0].size());
ISI0_Mean.resize(ISI0.size());
for(int isi_i=0;isi_i<ISI[0].size();isi_i++)
    {
      ISI_Mean[0][isi_i]=0;
    }
for(int isi_i=0;isi_i<ISI0.size();isi_i++)
    {
      ISI0_Mean[isi_i]=0;
    }
}

for(int isi_i=0;isi_i<ISI_Mean[0].size();isi_i++)
   {
     ISI_Mean[0][isi_i]+=ISI[0][isi_i];
   }
for(int isi_i=0;isi_i<ISI0_Mean.size();isi_i++)
   {
     ISI0_Mean[isi_i]+=ISI0[isi_i];
   }
  save(ISI,ISI_fname);
  save_f(f_omega,ISI_f_fname);
  save_solution(ISI0,Spike_Timing);
  FREE_1(ISI);
  FREE_2(ISI0);
 }
  FREE_2(SpikeTime);

cout<<endl;
cout<<"How Many Experiments Done "<<(mul_ex_1+1)<<endl;
cout<<endl;
//*********************************************************************************
}
if(Flage_sci_flat_white==2)
{
int compute_ISI_HH=1;
if(compute_ISI_HH==1)
{
    for(int isi_i=0;isi_i<ISI_Mean[0].size();isi_i++)
     {
      ISI_Mean[0][isi_i]=ISI_Mean[0][isi_i]/mul_exp_Final;
     }
      for(int isi_i=0;isi_i<ISI0_Mean.size();isi_i++)
     {
       ISI0_Mean[isi_i]=ISI0_Mean[isi_i]/mul_exp_Final;
     }

  string ISI_fname_Mean;
  string ISI_f_fname_Mean;
  string Spike_Timing_Mean;

if(Flage_sci_flat_white==2)
{
  ISI_fname_Mean="ISI_Mean("+double_to_str(OmegaStart)+"_"+double_to_str(OmegaFinal)+")";
  ISI_f_fname_Mean="ISI_Mean("+double_to_str(OmegaStart)+"_"+double_to_str(OmegaFinal)+")_f";
  Spike_Timing_Mean="Spike_Timing_Mean("+double_to_str(Omega[0])+")SCI_White";
}
else if(Flage_sci_flat_white==3)
{
  ISI_fname_Mean="ISI_Mean_White_Sine("+double_to_str(OmegaStart)+"_"+double_to_str(OmegaFinal)+")";
  ISI_f_fname_Mean="ISI_White_Sine("+double_to_str(OmegaStart)+"_"+double_to_str(OmegaFinal)+")_f";
  Spike_Timing_Mean="Spike_Timing_Mean("+double_to_str(Omega[0])+")SCI_White";

}

  save(ISI_Mean,ISI_fname_Mean); 
  save_solution(ISI0_Mean,Spike_Timing_Mean);
  FREE_1(ISI_Mean);
  FREE_2(ISI0_Mean);
}
for (int Num=0;Num<solution_num;Num++)
    { 
        for(int hh_solu_i=0;hh_solu_i<HH_solution_Mean[Num].size();hh_solu_i++)
        {
          HH_solution_Mean[Num][hh_solu_i]=HH_solution_Mean[Num][hh_solu_i]/mul_exp_Final;
        }
     }
#if Runmain_each_solution
for (int s_num=0;s_num<solution_num;s_num++)
{save_solution(HH_solution_Mean[s_num],sloution_name_mean[s_num]);}
while (!sloution_name_mean.empty())
	{
		sloution_name_mean.pop_back();
	}
FREE_1(HH_solution_Mean);
FREE_3(sloution_name_mean);
FREE_3(sloution_name);
#endif
}
      fftw_destroy_plan(ph);
      fftw_destroy_plan(ph1);
      fftw_free(inh);
      inh=NULL;
      fftw_free(inh1);
      inh1=NULL;
      fftw_free(outh);
      outh=NULL;
      fftw_free(outh1);
      outh1=NULL;

      fftw_destroy_plan(ph2);

      fftw_free(outh2);
      outh2=NULL;
      fftw_free(inh2);
      inh2=NULL;
}
