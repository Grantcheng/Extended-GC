#include <cstdlib>
#include <stdlib.h>
#include <vector>
#include <iostream>
#include<fstream>
#include<iomanip>
#include <string.h>
#include<cmath>
#include <time.h>
#include <unistd.h>
#include<sstream>
#include"HHconst.h"
#include"SHHfunction.h"
#include <stdarg.h>  
#include <sys/stat.h>  
#define ACCESS access  
#define MKDIR(a) mkdir((a),0755)  

char Filename[256];
char COMMAND[128];
char Data[256];
int CreatDir(char *pDir);
char Data_f[256];
void save(vector<vector<double> > DATA,string fname)
{
	snprintf(Filename, sizeof(Filename), "%s", fname.c_str());
	sprintf(COMMAND,"RK4/%s",Filename);
	CreatDir(COMMAND);
	snprintf(Data, sizeof(Filename),"RK4/%s/%s.txt",fname.c_str() ,fname.c_str());
	// ofstream outfile("ISI(0.34600-0.34602).txt", ios::app); 
	ofstream outfile(Data); 
 
if(!outfile)
{cout<<"File couldn't open\n";
return;
}

for(unsigned int i=0;i<DATA.size();i++)
{
for (vector<double>::iterator iter=DATA[i].begin();iter !=DATA[i].end();++iter)
{
	outfile<<setprecision(16)<<*iter<<" ";
	
}
outfile << endl;
//outfile<<" \r"<<endl;
}
outfile.close();}
/*for(int j=0;j<DATA.size();j++){
for(int i=0;i<DATA[j].size();i++)
	
	{outfile<<DATA[j][i]<<endl;}

outfile<<" \r"<<endl;}
outfile.close();
}*/


void save_f(vector<double>FData,string fname)
{
	snprintf(Filename, sizeof(Filename), "%s", fname.c_str());
	sprintf(COMMAND,"RK4/%s",Filename);
	CreatDir(COMMAND);
	snprintf(Data_f, sizeof(Filename),"RK4/%s/%s.txt",fname.c_str() ,fname.c_str());
	// ofstream outfile("ISI(0.34600-0.34602).txt", ios::app);//���ļ������ļ����ݺ�����������
	ofstream outfile(Data_f);//
		
if(!outfile)
{cout<<"Save Omega File_f couldn't open\n";
return;
}

for (vector<double>::iterator iter=FData.begin();iter !=FData.end();++iter)
{
	outfile<<*iter<<" ";
}
outfile << endl;
//outfile<<" \r"<<endl;
outfile.close();
}


void save_solution(vector<double> DATA,string fname)
{
	snprintf(Filename, sizeof(Filename), "%s", fname.c_str());
	sprintf(COMMAND,"RK4/Solution/%s",Filename);
	CreatDir(COMMAND);
        //system(COMMAND);
	//snprintf(Data, sizeof(Filename),"RK4/Solution/%s/%s.txt",fname.c_str(),fname.c_str());
	 snprintf(Data, sizeof(Filename),"RK4/Solution/%s.txt",fname.c_str());
	ofstream outfile(Data); 
		
if(!outfile)
{cout<<"Save Solution File couldn't open\n";
return;
}

for (vector<double>::iterator iter=DATA.begin();iter !=DATA.end();++iter)
{
	outfile<<setprecision(16)<<*iter<<" ";
	
}
outfile.close();
}


void save_solution_Strength(vector<double> DATA,string fname1, string fname)
{
	snprintf(Filename, sizeof(Filename), "%s", fname1.c_str());
	sprintf(COMMAND,"RK4/Solution/%s",Filename);
	CreatDir(COMMAND);
        //system(COMMAND);
	//snprintf(Data, sizeof(Filename),"RK4/Solution/%s/%s.txt",fname.c_str(),fname.c_str());
	 snprintf(Data, sizeof(Filename),"RK4/Solution/%s/%s.txt",fname1.c_str(),fname.c_str());
	ofstream outfile(Data); 
		
if(!outfile)
{cout<<"Save Solution File couldn't open\n";
return;
}

for (vector<double>::iterator iter=DATA.begin();iter !=DATA.end();++iter)
{
	outfile<<setprecision(16)<<*iter<<" ";
	
}
outfile.close();
}

int CreatDir(char *pDir)  
    {  
        int i = 0;  
        int iRet;  
        int iLen;  
        char* pszDir;  
      
        if(NULL == pDir)  
        {  
            return 0;  
        }  
          
        pszDir = strdup(pDir);  
        iLen = strlen(pszDir); 
      
         
        for (i = 0;i < iLen;i ++)  
        {  
            if (pszDir[i] == '\\'|| pszDir[i] =='/')  
            {   
                pszDir[i] = '\0';  
      
                
                iRet = ACCESS(pszDir,0);  
                if (iRet != 0)  
                {  
                    iRet = MKDIR(pszDir);  
                    if (iRet != 0)  
                    {  
                        return -1;  
                    }   
                }  
                 
                pszDir[i] = '/'; 
            }   
        }  
      
        iRet = MKDIR(pszDir);  
        free(pszDir);  
        return iRet;  
    }  
