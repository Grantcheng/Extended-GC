#ifndef _Duffing_Equation_h_
#define _Duffing_Equation_h_
#include <iostream>
#include <string>
using namespace std;

//---------------------Duffing Equation------------------------------------
void x_dt(double t,double y_2,double &dx_dt);
void y_dt(double t,double y_2, double y_1, double y_3,double alpha,double beta,double gamma,double force,double &dy_dt);
void q_dt(double t,double Omega, double &dq_dt);

//-------------------------Lorenz Equation --------------------------------
void Lx_dt(double t, vector<double> Ly, double &dx_dt);
void Ly_dt(double t, vector <double> Ly,double &dy_dt);
void Lz_dt(double t, vector<double> Ly, double &dz_dt);


//-------------------------Rossler Equation --------------------------------
void Rx_dt(double t, vector<double> Ly, double &dx_dt);
void Ry_dt(double t, vector <double> Ly,double &dy_dt);
void Rz_dt(double t, vector<double> Ly, double &dz_dt);

//-------------------------Morris Lecar --------------------------------
void MLv0_dt(double t, vector<double> Ly,double Omega, double &dv_dt);
void MLw0_dt(double t, vector <double> Ly,double Omega, double &dw_dt);
void Mqq0_dt(double t,vector<double> ML_y,double Omega, double &Mqq_dt);

void MLv0_mdt(double t,vector<double> ML_y,vector<double> amp,vector<double> Omega,vector<double> &dv_dt);
void MLw0_mdt(double t,vector<double> ML_y, vector<double> Omega,vector<double> &dw_dt);
void Gm0_dt(double t,vector<double> y,vector<vector<double> >  Couple,vector<double> &G_dt);
void Mqqm0_dt(double t,vector<double> ML_y,vector<double> Omega,vector<double> &dq_dt);
//-------------------------Fithugh Nagumo --------------------------------
void FNv_dt(double t, vector<double> FN_y, double &dv_dt);
void FNw_dt(double t, vector <double> ML_y,double &dw_dt);
void Fqq_dt(double t,double Omega, double &Fqq_dt);

#endif // _Duffing_Equation_h_
