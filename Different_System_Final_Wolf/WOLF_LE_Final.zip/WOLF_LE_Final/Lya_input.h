#ifndef _Lya_input_H_
#define _Lya_input_H_

#include <iostream>
#include <vector>
#include <string>

using namespace std;

double scalar_product(const vector<double>& a,const vector<double>& b);   
vector<vector<double> > MGS(vector<vector<double> > mul_lya_perturb);  // use the stable Gram-Schmidt algorithm
void LyaHH (vector<double> y_0, vector<double> Omega);
void LyaML (vector<double> y_0, vector<double> Omega);
void Mul_LyaML (vector<double> y_0, vector<double> Omega,vector<vector<double> >Couple,vector<double> amp);
void LyaFN (vector<double> y_0, vector<double> Omega); //Compute Fitzhugh Nagumo Model neuron lyapunove exponent
void Mul_LyaHH (vector<double> y_0, vector<double> Omega,vector<vector<double> >Couple,vector<double> amp);
void Lya (vector<double> y_0, vector<double> Omega,double alpha,double beta,double gamma,double force);
void Lya_Sys (vector<double> y_0, vector<double> Omega, int E_C);
void mul_lya_record(vector<double> Omega);
void FREE_1(vector<vector<double> > &Initial_1);
void FREE_2(vector<double> &Initial_2);
void FREE_3(vector<string> &Initial_3);
void LyaHH_Poisson (vector<double> y_0, vector<double> Omega,double Dt);
void LyaHH_SCI(vector<double> y_0, vector<double> Omega,int Flage_sci_flat_white); 
void Save_Local_Global_LE(vector<double> Omega,int multiples);
#endif //_Lya_input_H_
