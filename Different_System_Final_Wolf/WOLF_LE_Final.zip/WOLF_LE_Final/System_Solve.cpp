#include <iostream>
#include <cmath>
#include <iomanip>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <sstream>
#include <vector>
#include "Duffing_Equation.h"
#include "Different_System_RK4.h"
#include "Lya_input.h"
#include "HHconst.h"
#include "save.h"
#include "convergence.h"
using namespace std;
double OmegaStart;
double OmegaFinal;
//int Save_each_solution;
string   double_to_str(   double   x   ) // double to string
{ 
    string   str; 
    stringstream   ss; 
    ss<<x   ; 
    ss>>str   ; 
    return   str; 
}

void System_Solve(int N, vector<double> y_0, vector<double> Omega, double alpha,double beta,double gamma,double force,double *out_y)
{
double Tstart=0;
//double h=2*pi/Omega[0]/630;
double h=0.01;
cout<<"System_Solve step =   "<<h<<endl;
int solution_num=1;
vector<double> T0;
vector<double> solution;
vector<vector<double> > y_D;
vector<string> sloution_name;

#if Runmain_each_solution_range
for (int a=0;a<solution_num;a++)
{sloution_name.push_back("Solution("+double_to_str(3*OmegaStart)+"-"+double_to_str(3*OmegaFinal)+")w1_"+double_to_str(a)+"_"+double_to_str(Omega[0]));}
#else
for (int a=0;a<solution_num;a++)
{sloution_name.push_back("Solution_w1_"+double_to_str(Omega[0])+"_"+double_to_str(a));}
#endif

System_Duffing_RK4(y_0,Omega,Tstart,N,h,alpha, beta, gamma, force,y_D,T0,x_dt,y_dt,q_dt);

/*
solution.resize(solution_num);
for (int Num=0;Num<solution_num;Num++)
{
solution[Num].resize(T0.size());
}

*/
//int i=0;
for (int k=0;k<T0.size();k++)
{
	
	for (int s_num=0;s_num<solution_num;s_num++)
		{
                        out_y[k]=y_D[k][s_num];
	    }
}

// save each solution of the HH system equation
/*#if Runmain_each_solution
for (int s_num=0;s_num<solution_num;s_num++)
{save_solution(solution[s_num],sloution_name[s_num]);}
#endif
*/
/*
while (!sloution_name.empty())
				{
					sloution_name.pop_back();
				}
				
*/
FREE_1(y_D);
FREE_2(T0);
T0.clear();
}



void Lorenz_System_Solve(int N,vector<double> y_0, vector<double> Omega,double h,double *out_y)
{
double Tstart=0;
int solution_num=1;
vector<double> T0;
vector<double> solution;
vector<vector<double> > y_D;
vector<string> sloution_name;

#if Runmain_each_solution_range
for (int a=0;a<solution_num;a++)
{sloution_name.push_back("Solution("+double_to_str(3*OmegaStart)+"-"+double_to_str(3*OmegaFinal)+")w1_"+double_to_str(a)+"_"+double_to_str(Omega[0]));}
#else
for (int a=0;a<solution_num;a++)
{sloution_name.push_back("Solution_w1_"+double_to_str(Omega[0])+"_"+double_to_str(a));}
#endif

System_Lorenz_RK4(y_0,Omega,Tstart,N,h,y_D,T0,Lx_dt,Ly_dt,Lz_dt);

for (int k=0;k<T0.size();k++)
{
	
	for (int s_num=0;s_num<solution_num;s_num++)
		{
                        out_y[k]=y_D[k][s_num];
	    }
}

FREE_1(y_D);
FREE_2(T0);
T0.clear();

}



void Rossler_System_Solve(int N,vector<double> y_0, vector<double> Omega,double h, double *out_y)
{
double Tstart=0;
int solution_num=1;
vector<double> T0;
vector<double> solution;
vector<vector<double> > y_D;

System_Rossler_RK4(y_0,Omega,Tstart,N,h,y_D,T0,Rx_dt,Ry_dt,Rz_dt);

for (int k=0;k<T0.size();k++)
{
	
	for (int s_num=0;s_num<solution_num;s_num++)
		{
                        out_y[k]=y_D[k][s_num];
	    }
}

FREE_1(y_D);
FREE_2(T0);
T0.clear();

}


vector<vector<double> > Morris_Lecar_Solve(int N,vector<double> y_0, vector<double> Omega,double h, double *out_y)
{
double Tstart=0;
int solution_num=1;
//double h_0=pow(0.5,(14));// convergence test ,the time evolution,RK4 step
double h_0=(double)1/4096;
vector<double> SpikeTime;
vector<vector<double> > Morris_Lecar_solution;
vector<double> Compare_Th;
vector<vector<double> > y_D;
vector<double> T0;
vector<string> sloution_name;
double Time=1024;//convergence test ,the time evolution
double N_0;//convergence test ,the time evolution
N_0=Time/h_0;//convergence test ,the time evolution


vector<double> ISI0;
vector<vector<double> > ISIout;

/*
#if Convergence_Test_0  //Test convergence of the single neuron program
double T0_convergence;
vector<double> y_convergence;
Convergence_1(y_0,Omega,Tstart,N_0,h_0,y_convergence,T0_convergence,Time);
#endif
*/

#if Runmain_each_solution_range
for (int a=0;a<solution_num;a++)
{
   if (chose_current_change==0)
    {
      sloution_name.push_back("Morris_Lecar_Solution("+double_to_str(3*OmegaStart)+"-"+double_to_str(3*OmegaFinal)+")w1_"+double_to_str(a)+"_"+double_to_str(Omega[0]));
    }
   else if (chose_current_change==1)
    {
      sloution_name.push_back("Morris_Lecar_Solution("+double_to_str(3*OmegaStart)+"-"+double_to_str(3*OmegaFinal)+")w1_"+double_to_str(a)+"_"+double_to_str(Current_0));
    }

#else
for (int a=0;a<solution_num;a++)
{
 if (chose_current_change==0)
  {
    sloution_name.push_back("Morris_Lecar_Solution_w1_"+double_to_str(Omega[0])+"_"+double_to_str(a));
  }
 else if(chose_current_change==1)
  { 
    sloution_name.push_back("Morris_Lecar_Solution_w1_"+double_to_str(Current_0)+"_"+double_to_str(a));
  }
}
#endif

System_Morris_Lecar_RK4(y_0,Omega,Tstart,N,h,y_D,T0,MLv0_dt,MLw0_dt,Mqq0_dt);

Morris_Lecar_solution.resize(solution_num);
for (int Num=0;Num<solution_num;Num++)
{
Morris_Lecar_solution[Num].resize(T0.size());
}
SpikeTime.resize(T0.size());
ISIout.resize(1);
int i=0;
for (int k=0;k<T0.size();k++)
{
	SpikeTime[k]=y_D[k][0]-Threshold_ML;
	for (int s_num=0;s_num<solution_num;s_num++)
		{
			
			Morris_Lecar_solution[s_num][k]=y_D[k][s_num];
                        out_y[k]=y_D[k][s_num];
	
	    }
}
// save each solution of the Morris_Lecar system equation
if (Save_each_solution==1)
{
for (int s_num=0;s_num<solution_num;s_num++)
{save_solution(Morris_Lecar_solution[s_num],sloution_name[s_num]);}
}

while (!sloution_name.empty())
				{
					sloution_name.pop_back();
				}
				
for (int j=1;j<SpikeTime.size();j++)
{
	if (SpikeTime[j]>=0 && SpikeTime[j-1]<0)
	{
		ISI0.push_back(T0[j]);
		i++;
	}
}

if(i!=0)
{
for(int z=0; z<i;z++){
	if(z==0)
	{
		ISIout[0].push_back(ISI0[z]);
	}
	else
    {
	ISIout[0].push_back(ISI0[z]-ISI0[z-1]);
    }
}
}
else
{
ISIout[0].resize(0);
}

return ISIout;
//************************* release the capacity
FREE_1(y_D);
FREE_2(T0);
T0.clear();
}


vector<vector<double> > Fitzhugh_Nagumo_Solve(int N,vector<double> y_0, vector<double> Omega,double h, double *out_y)
{
double Tstart=0;
int solution_num=1;
//double h_0=pow(0.5,(14));// convergence test ,the time evolution,RK4 step
double h_0=(double)1/4096;
vector<double> SpikeTime;
vector<vector<double> > Fitzhugh_Nagumo_solution;
vector<double> Compare_Th;
vector<vector<double> > y_D;
vector<double> T0;
vector<string> sloution_name;
double Time=1024;//convergence test ,the time evolution
double N_0;//convergence test ,the time evolution
N_0=Time/h_0;//convergence test ,the time evolution

#if NumNeuron1
vector<double> ISI0;
vector<vector<double> > ISIout;

#if Convergence_Test_0  //Test convergence of the single neuron program
double T0_convergence;
vector<double> y_convergence;
Convergence_1(y_0,Omega,Tstart,N_0,h_0,y_convergence,T0_convergence,Time);
#else

#if Runmain_each_solution_range
for (int a=0;a<solution_num;a++)
{sloution_name.push_back("Fitzhugh_Nagumo_Solution("+double_to_str(3*OmegaStart)+"-"+double_to_str(3*OmegaFinal)+")w1_"+double_to_str(a)+"_"+double_to_str(Omega[0]));}
#else
for (int a=0;a<solution_num;a++)
{sloution_name.push_back("Fitzhugh_Nagumo_Solution_w1_"+double_to_str(Omega[0])+"_"+double_to_str(a));}
#endif

System_Fitzhugh_Nagumo_RK4(y_0,Omega,Tstart,N,h,y_D,T0,FNv_dt,FNw_dt,Fqq_dt);

Fitzhugh_Nagumo_solution.resize(solution_num);
for (int Num=0;Num<solution_num;Num++)
{
Fitzhugh_Nagumo_solution[Num].resize(T0.size());
}
SpikeTime.resize(T0.size());
ISIout.resize(1);
int i=0;
for (int k=0;k<T0.size();k++)
{
	SpikeTime[k]=y_D[k][0]-Threshold_FN;
	for (int s_num=0;s_num<solution_num;s_num++)
		{
			
			Fitzhugh_Nagumo_solution[s_num][k]=y_D[k][s_num];
                        out_y[k]=y_D[k][s_num];
	
	    }
}
// save each solution of the Fitzhugh_Nagumo system equation
if (Save_each_solution==1)
{
for (int s_num=0;s_num<solution_num;s_num++)
{save_solution(Fitzhugh_Nagumo_solution[s_num],sloution_name[s_num]);}
}

while (!sloution_name.empty())
				{
					sloution_name.pop_back();
				}
				
for (int j=1;j<SpikeTime.size();j++)
{
	if (SpikeTime[j]>=0 && SpikeTime[j-1]<0)
	{
		ISI0.push_back(T0[j]);
		i++;
	}
}

if(i!=0)
{
for(int z=0; z<i;z++){
	if(z==0)
	{
		ISIout[0].push_back(ISI0[z]);
	}
	else
    {
	ISIout[0].push_back(ISI0[z]-ISI0[z-1]);
    }
}
}
else
{
ISIout[0].resize(0);
}

return ISIout;
#endif
#endif
//************************* release the capacity
FREE_1(y_D);
FREE_2(T0);
T0.clear();
}
