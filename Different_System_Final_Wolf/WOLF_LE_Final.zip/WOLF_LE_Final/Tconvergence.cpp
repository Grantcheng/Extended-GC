#include<iostream>
#include<cmath>
#include<iomanip>
#include<fstream>
#include <stdio.h>
#include <stdlib.h>
#include <sstream>
#include <vector>
#include <fftw3.h>
#include "HHconst.h"
#include "SHHfunction.h"
#include "THHfunciton.h"
#include "RK4.h"
#include "poisson_input.h"
#include "neuron.h"
#include "loop.h"
#include "datainput.h"
#include "random.h"
#include "WhiteNoise.h"
#include "Convolutional.h"
#include "Different_System_RK4.h"

using namespace std;
void save(vector<vector<double> > DATA,string fname);
string   double_to_str(double x) ;

void Convergence_1(vector<double> y_0,vector<double> Omega,double Tstart,double N_0,double h_0,vector<double> &y_convergence,
	double &T0_convergence,double Time) // Convergence Tests for Single Neuron
{
	vector<vector<double> >Y_C ; //save the convergence value at Time=1024ms;

        int N_1;
        double h_1;
int num_neuron = Number_Exneuron + Number_Inneuron;

//Convergence test
int N=(int)N_0;
ModfyRunge_Kutta4(y_0,Omega,Tstart,N,h_0,y_convergence,T0_convergence,voltageo_dt,mo_dt,ho_dt,no_dt,qqo_dt);

cout<<"The reference value"<<endl;
cout<<setprecision(16)<<y_convergence[0]<<endl;
Y_C.resize(1);
Y_C[0].push_back(y_convergence[0]);
FREE_2(y_convergence);
cout<<"The y value"<<endl;
long double H=pow(512.00,(-1));

for (int lm=1;lm<6;lm++)
{
     h_1=pow(2.0,(lm-1))*H;
     N_1=N/pow(2.0,lm);

  cout<<"h_1 is "<<h_1<<endl;
  cout<<"N_1 is "<<N_1<<endl;
ModfyRunge_Kutta4(y_0,Omega,Tstart,N_1,h_1,y_convergence,T0_convergence,voltageo_dt,mo_dt,ho_dt,no_dt,qqo_dt);
cout<<setprecision(16)<<T0_convergence<<endl;
cout<<setprecision(16)<<y_convergence[0]<<endl;
Y_C[0].push_back(y_convergence[0]);
FREE_2(y_convergence);
}
string fname="convergence1test";     //
save(Y_C,fname);

}


void Convergence_2(vector<double> y_0,vector<double> Omega,double Tstart,double N_0,double h_0,vector<double> &y_convergence,
	double &T0_convergence,	vector<vector<double> >Couple,vector<double> amp,double Time)  // Convergence Tests for Two Neurons
{
vector<vector<double> >Y_C ; //save the convergence value at Time=1024ms;

int N_1;
double h_1;
int num_neuron = Number_Exneuron + Number_Inneuron;
int N=(int)N_0;
//Convergence test
 ModfyRunge_Kutta4M(y_0,Omega,Tstart,N,h_0,y_convergence,T0_convergence,Couple,amp,voltageio_dt,mio_dt,hio_dt,nio_dt,Gio_dt,G1io_dt,qio_dt);
 //ModfyRunge_Kutta4M(y_0,Omega,Tstart,N_0,h_0,y_convergence,T0_convergence,Couple,amp,voltagei_1_dt,mi_1_dt,hi_1_dt,ni_1_dt,Gi_1_dt,G1i_1_dt,qi_1_dt);
cout<<"The reference value "<<endl;
cout<<setprecision(16)<<y_convergence[0]<<endl<<setprecision(16)<<y_convergence[7]<<endl;
Y_C.resize(2);
Y_C[0].push_back(y_convergence[0]);
Y_C[1].push_back(y_convergence[7]);
FREE_2(y_convergence);
cout<<"The y value"<<endl;
long double H=pow(512.00,(-1));

for (int lm=1;lm<6;lm++)
{
     y_convergence.clear();
     T0_convergence=0;
     h_1=pow(2.0,(lm-1))*H;
     N_1=N/pow(2.0,lm);

  cout<<"h_1 is "<<h_1<<endl;


ModfyRunge_Kutta4M(y_0,Omega,Tstart,N_1,h_1,y_convergence,T0_convergence,Couple,amp,voltageio_dt,mio_dt,hio_dt,nio_dt,Gio_dt,G1io_dt,qio_dt);
//ModfyRunge_Kutta4M(y_0,Omega,Tstart,N_1,h,y_convergence,T0_convergence,Couple,amp,voltagei_1_dt,mi_1_dt,hi_1_dt,ni_1_dt,Gi_1_dt,G1i_1_dt,qi_1_dt);
cout<<T0_convergence<<endl;
cout<<setprecision(16)<<y_convergence[0]<<endl<<setprecision(16)<<y_convergence[7]<<endl;
Y_C[0].push_back(y_convergence[0]);
Y_C[1].push_back(y_convergence[7]);
FREE_2(y_convergence);
}
string fname="convergence2test";     //
save(Y_C,fname);
}


void Convergence_P(vector<double> y_0,vector<double> Omega,double Tstart,double N_0,double h_0,vector<double> &y_convergence,
	double &T0_convergence,double Time)
{
	vector<vector<double> >Y_C ; //save the convergence value at Time=1024ms;
        vector<vector<double> >Y_Convergence;
	int N_1;
        double h_1;
int num_neuron = Number_Exneuron + Number_Inneuron;
Y_Convergence.resize(N_0);
//Convergence test
#if Autonomy_Use
 y_convergence.resize(9);
#else
 y_convergence.resize(8);
#endif

	srand(initial_seed);
	for( int i = 0; i < num_neuron; i++ )
	{
		initialseed_neuron[i] = (long) -rand();

		last_input[i] = -log(RANDOM(initialseed_neuron+i,ran_iy,ran_iv,i))/Rate_input;

	}

cout<<"h_0 is "<<h_0<<endl;
int N=(int)N_0;
Neuron_Solution_ISIjin(N,h_0,Tstart,Omega,Y_Convergence,y_0,3);
y_convergence=Y_Convergence.back();
FREE_1(Y_Convergence);

cout<<"The reference value"<<endl;
cout<<setprecision(16)<<y_convergence[0]<<endl;
Y_C.resize(1);
Y_C[0].push_back(y_convergence[0]);
cout<<"The y value"<<endl;
long double H=pow(512.00,(-1));


for (int lm=1;lm<6;lm++)
{

	srand(initial_seed);
	for( int i = 0; i < num_neuron; i++ )
	{
		initialseed_neuron[i] = (long) -rand();

		last_input[i] = -log(RANDOM(initialseed_neuron+i,ran_iy,ran_iv,i))/Rate_input;
	}


  h_1=pow(2.0,(lm-1))*H;
  N_1=N/pow(2.0,lm);

  cout<<"h_1 is "<<h_1<<endl;

Y_Convergence.resize(N_1);
Neuron_Solution_ISIjin(N_1,h_1,Tstart,Omega,Y_Convergence,y_0,3);

y_convergence=Y_Convergence.back();
cout<<setprecision(16)<<y_convergence[0]<<endl;

FREE_1(Y_Convergence);
Y_C[0].push_back(y_convergence[0]);
}

string fname="convergence1test_Poisson";     //
save(Y_C,fname);

}

void Convergence_Sci(vector<double> y_0,double Tstart,int N_0,double h_0,int Flage_sci_flat_white,vector<double> &y_convergence,
	double &T0_convergence,double Time)  // Convergence Tests for SCI1995
{
	vector<vector<double> >Y_C ; //save the convergence value at Time=1024ms;
int Frame;
int N_1;
double h_1;
int temp_i;
int temp_ii;
//Convergence test
double *Flate_Current;
double *White_Noise;
int N_Length;
double h_white;
double *Temp_White_Noise;
fftw_complex *out;
fftw_complex *out1;
fftw_complex *out2;
fftw_complex  *in;
fftw_complex  *in1;
fftw_complex  *in2;
fftw_plan p;
fftw_plan p1;
fftw_plan p2;
//struct array a,lbq,Lbq_WhiteNoise;

// Compute the HH dynamical system, and obtain the solution of the HH model
int i;
     cout<<"N_0 is "<<N_0<<endl;
     cout<<"h_0 is "<<h_0<<endl;
if(Flage_sci_flat_white==1)
{
  Flate_Current=(double *)malloc((2*N_0+1)*sizeof(double));

  //产生Flate Current
  for (i=0;i<(2*N_0+1);i++)
   {
          Flate_Current[i]=Mean_white;
    }
     cout<<" Now is running the SCI_Flate_Current case! "<<endl;

    ModfyHH_Sci_Flate_RK4(y_0,Tstart,N_0,h_0,y_convergence,T0_convergence,Flate_Current,voltage_sci_dt,m_sci_dt,h_sci_dt,n_sci_dt);
    free(Flate_Current);
}
else if(Flage_sci_flat_white==2)
{
        setglobals_whitenoise();
        Frame=2*N_0-1;
        White_Noise=(double *)malloc((N_0+1)*sizeof(double));
        in=(fftw_complex *) fftw_malloc(sizeof(fftw_complex )*Frame);
        in1=(fftw_complex *) fftw_malloc(sizeof(fftw_complex )*Frame);

        out=(fftw_complex*)fftw_malloc(sizeof(fftw_complex)*Frame);
        out1=(fftw_complex*)fftw_malloc(sizeof(fftw_complex)*Frame);

        h_white=h_0;
        // 产生高斯白噪声
        WhilteNoise_fun(N_0);
        // 高斯噪声通过一个滤波器 f(t)=t*exp(-t/ts)
        p=fftw_plan_dft_1d(Frame,in,out,FFTW_FORWARD,FFTW_ESTIMATE);
        p1=fftw_plan_dft_1d(Frame,in1,out1,FFTW_FORWARD,FFTW_ESTIMATE);

      for(i=0;i<N_0+1;i++)
        {
            in[i][0]=sqrt(h_white)*WhiteNoise[i];
            in[i][1]=0;
            in1[i][1]=0;
           //in1[i][0]=h_white*(i*h_white)*exp(-i*h_white/tau);
            in1[i][0]=h_white*(i*h_white)*exp(-i*h_white/tau);
         }
      for(i=N_0+1;i<Frame;i++)
        {
            in[i][0]=0;
            in[i][1]=0;
            in1[i][1]=0;
           //in1[i][0]=h_white*(i*h_white)*exp(-i*h_white/tau);
            in1[i][0]=0;
         }
        fftw_execute(p);
        fftw_execute(p1);

        in2=(fftw_complex *) fftw_malloc(sizeof(fftw_complex )*Frame);
        out2=(fftw_complex*)fftw_malloc(sizeof(fftw_complex)*Frame);
        p2 = fftw_plan_dft_1d(Frame,out2,in2,FFTW_BACKWARD,FFTW_ESTIMATE);

        for(i=0;i<Frame;i++)
         {
           out2[i][0]=out[i][0]*out1[i][0]-out[i][1]*out1[i][1];
           out2[i][1]=out[i][0]*out1[i][1]+out[i][1]*out1[i][0];
          }
        fftw_destroy_plan(p);
        fftw_destroy_plan(p1);

	fftw_free(in);
        in=NULL;
        fftw_free(in1);
        in1=NULL;
        fftw_free(out);
        out=NULL;
        fftw_free(out1);
        out1=NULL;
        fftw_execute(p2);

        for (i=0;i<(N_0+1);i++)
        {
            White_Noise[i]=in2[i][0]/(Frame);
         }
        //a.length =2*N_0;
        //lbq.length =2*N_0;
        //a.pStart =new float [a.length ];
        //lbq.pStart =new float [lbq.length ];
        //for (i=0;i<lbq.length;i++)
	//{
	//*(lbq.pStart+i)=(i*h_white)*exp(-i*h_white/tau);
	// //cout<<*(a.pStart+i)<<"   ";
	//}

        /*for (i=0;i<a.length;i++)
	{
	*(a.pStart+i)=Mean_white+Sigma_white*WhiteNoise[i];//obey mean=Mean_white and Sigma=Sgima_white norm distribution;
	// cout<<*(a.pStart+i)<<"   ";
	}
        Lbq_WhiteNoise=conv(a,lbq);
*/
      ModyHH_Sci_White_Milstein(y_0,Tstart,N_0,h_0,y_convergence,T0_convergence,White_Noise,voltage_sci_dt,m_sci_dt,h_sci_dt,n_sci_dt);
      //free(White_Noise);
      free(WhiteNoise);
      fftw_free(out2);
      out2=NULL;
      fftw_free(in2);
      in2=NULL;
      fftw_destroy_plan(p2);
/*
     delete [] a.pStart;
     delete [] lbq.pStart;
     delete [] Lbq_WhiteNoise.pStart;
      */
}

cout<<"The reference value"<<endl;
cout<<setprecision(16)<<y_convergence[0]<<endl;
Y_C.resize(1);
Y_C[0].push_back(y_convergence[0]);

long double H=pow(512.00,(-1));
cout<<"****************************"<<endl;
int N_1_temp=N_0;
for (int lm=1;lm<6;lm++)
{
     h_1=pow(2.0,(lm-1))*H;
     N_1=N_1_temp/2;
     N_1_temp=N_1;
     cout<<"The "<<lm<<" results "<<endl;
     cout<<"N_1 is "<<N_1<<endl;
     cout<<"h_1 is "<<h_1<<endl;

if(Flage_sci_flat_white==1)
{
   Flate_Current=(double *)malloc((2*N_1+1)*sizeof(double));
   //N_Length=2*(N_1-10000/pow(2.0,lm));

  //产生Flate Current
  for (i=0;i<(2*N_1+1);i++)
   {
      Flate_Current[i]=Mean_white;
    }
     cout<<" Now is running the SCI_Flate_Current case! "<<endl;
     //Runge_Kutta4(y_0,Omega,Tstart,N,h,y,T0,voltageo_dt,mo_dt,ho_dt,no_dt,qqo_dt);
     ModfyHH_Sci_Flate_RK4(y_0,Tstart,N_1,h_1,y_convergence,T0_convergence,Flate_Current,voltage_sci_dt,m_sci_dt,h_sci_dt,n_sci_dt);
}
else if(Flage_sci_flat_white==2)
{
        //White_Noise=(double *)malloc(2*N_1*sizeof(double));
        Temp_White_Noise=(double *)malloc((N_1+1)*sizeof(double));
        temp_i=1;
        Frame=2*N_1-1;
        h_white=h_1;
//*******************************************************************
 /*     for(int pow_i=0;pow_i<lm;pow_i++)
          {
              temp_i=2*temp_i;
           }

        for(i=0;i<(N_1+1);i++)
        {
            temp_ii=i*temp_i;
            Temp_White_Noise[i]=White_Noise[temp_ii];
        }

        WhilteNoise_fun(2*N_1);
        for(i=0;i<2*N_1;i++)
        {
            Temp_White_Noise[i]=WhiteNoise[i];
        }
 */
//*******************************************************************

        in=(fftw_complex *) fftw_malloc(sizeof(fftw_complex )*Frame);
        in1=(fftw_complex *) fftw_malloc(sizeof(fftw_complex )*Frame);

        out=(fftw_complex*)fftw_malloc(sizeof(fftw_complex)*Frame);
        out1=(fftw_complex*)fftw_malloc(sizeof(fftw_complex)*Frame);

        p=fftw_plan_dft_1d(Frame,in,out,FFTW_FORWARD,FFTW_MEASURE);
        p1=fftw_plan_dft_1d(Frame,in1,out1,FFTW_FORWARD,FFTW_MEASURE);

        for(i=0;i<N_1;i++)
        {
            in[i][0]=sqrt(h_white)*WhiteNoise[i];
            in[i][1]=0;
            in1[i][1]=0;
            in1[i][0]=h_white*(i*h_white)*exp(-i*h_white/tau);
         }

        fftw_execute(p);
        fftw_execute(p1);

        in2=(fftw_complex *) fftw_malloc(sizeof(fftw_complex )*Frame);
        out2=(fftw_complex*)fftw_malloc(sizeof(fftw_complex)*Frame);
        p2 = fftw_plan_dft_1d(Frame,out2,in2,FFTW_BACKWARD,FFTW_MEASURE);

        for(i=0;i<Frame;i++)
         {
           out2[i][0]=out[i][0]*out1[i][0]-out[i][1]*out1[i][1];
           out2[i][1]=out[i][0]*out1[i][1]+out[i][1]*out1[i][0];
          }
        fftw_destroy_plan(p);
        fftw_destroy_plan(p1);

	fftw_free(in);
        fftw_free(in1);
        fftw_free(out);
        fftw_free(out1);

        fftw_execute(p2);

        for (i=0;i<N_1;i++)
        {
            Temp_White_Noise[i]=in2[i][0]/(Frame);
         }
/*
       // Test
       FILE	*fp1;
       FILE	*fp0;
       if((fp1 = fopen("noise_Tcon.dat","w+")) == NULL)
	{
		printf("Open file error !");
		exit(1);
	};
	for(i=0;i<N_1;i++)
	{
		fprintf(fp1,"%d %f\n",i,Temp_White_Noise[i]);
	}
	fclose(fp1);

    /*    if((fp0 = fopen("noise.dat","w+")) == NULL)
	{
		printf("Open file error !");
		exit(1);
	};
	for(i=0;i<2*N_1;i++)
	{
		fprintf(fp1,"%d %f\n",i,Temp_White_Noise[i]);
	}
	fclose(fp0);
*/
        //
/*
        White_Noise=(double *)malloc(2*N_1*sizeof(double));
        in=(fftw_complex *) fftw_malloc(sizeof(fftw_complex )*2*N_1);
        in1=(fftw_complex *) fftw_malloc(sizeof(fftw_complex )*2*N_1);

        out=(fftw_complex*)fftw_malloc(sizeof(fftw_complex)*2*N_1);
        out1=(fftw_complex*)fftw_malloc(sizeof(fftw_complex)*2*N_1);

        h_white=h_1/2;
        // 产生高斯白噪声
        WhilteNoise_fun(2*N_1);
        // 高斯噪声通过一个滤波器 f(t)=t*exp(-t/ts)
      */
/*
        a.length =2*N_1;
        lbq.length =2*N_1;
        a.pStart =new float [a.length ];
        lbq.pStart =new float [lbq.length ];
        for (i=0;i<lbq.length;i++)
	{
	*(lbq.pStart+i)=(i*h_white)*exp(-i*h_white/tau);
	// cout<<*(a.pStart+i)<<"   ";
	}

        for (i=0;i<a.length;i++)
	{
	*(a.pStart+i)=Mean_white+Sigma_white*WhiteNoise[i];//obey mean=Mean_white and Sigma=Sgima_white norm distribution;
	// cout<<*(a.pStart+i)<<"   ";
	}
        Lbq_WhiteNoise=conv(a,lbq);
*/
 /*       p=fftw_plan_dft_1d(2*N_1,in,out,FFTW_FORWARD,FFTW_MEASURE);
        p1=fftw_plan_dft_1d(2*N_1,in1,out1,FFTW_FORWARD,FFTW_MEASURE);

      for(i=0;i<2*N_1;i++)
        {
            in[i][0]=Mean_white+Sigma_white*WhiteNoise[i];
            in[i][1]=0;
            in1[i][1]=0;
            in1[i][0]=(i*h_white)*exp(-i*h_white/tau);
         }

        fftw_execute(p);

        in2=(fftw_complex *) fftw_malloc(sizeof(fftw_complex )*2*N_1);
        out2=(fftw_complex*)fftw_malloc(sizeof(fftw_complex)*2*N_1);
        p2 = fftw_plan_dft_1d(2*N_1,out2,in2,FFTW_BACKWARD,FFTW_MEASURE);

        for(i=0;i<2*N_1;i++)
         {
           out2[i][0]=out[i][0]*out1[i][0]-out[i][1]*out1[i][1];
           out2[i][1]=out[i][0]*out1[i][1]+out[i][1]*out1[i][0];
          }
        fftw_destroy_plan(p);
        fftw_destroy_plan(p1);

	fftw_free(in);
        fftw_free(in1);
        fftw_free(out);
        fftw_free(out1);

        fftw_execute(p2);

        for (i=0;i<2*N_1;i++)
        {
            White_Noise[i]=in2[i][0]/(2*N_1);
         }
*/

      ModyHH_Sci_White_Milstein(y_0,Tstart,N_1,h_1,y_convergence,T0_convergence,Temp_White_Noise,voltage_sci_dt,m_sci_dt,h_sci_dt,n_sci_dt);
    /*
     delete [] a.pStart;
     delete [] lbq.pStart;
     delete [] Lbq_WhiteNoise.pStart;
    */
      //free(White_Noise);
      //fftw_free(out2);
     // fftw_free(in2);
      free(Temp_White_Noise);
    // free(WhiteNoise);
}

cout<<setprecision(16)<<y_convergence[0]<<endl;
cout<<endl;

Y_C[0].push_back(y_convergence[0]);
FREE_2(y_convergence);

}
cout<<"*****************************"<<endl;
string fname="convergence1test_Sci";     //
save(Y_C,fname);
if(Flage_sci_flat_white==2)
{
free(WhiteNoise);
WhiteNoise=NULL;
free(White_Noise);
White_Noise=NULL;
}
}
