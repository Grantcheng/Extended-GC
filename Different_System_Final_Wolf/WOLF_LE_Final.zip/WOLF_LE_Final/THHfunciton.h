#ifndef _THHfunciton_h_
#define _THHfunciton_h_
#include <iostream>
#include <vector>
#include <string>
using namespace std;

/*class MHH
{
public:
	MHH();*/
	void voltagei_dt(double t,vector<double> y,vector<double> amp,vector<double> &dv_dt);
    void mi_dt(double t,vector<double> y, vector<double>  &dmi_dt);
	void hi_dt(double t,vector<double> y,vector<double>  &dhi_dt);
	void ni_dt(double t,vector<double> y, vector<double>  &dni_dt);
	void Gi_dt(double t,vector<double> y,vector<double>  &Gi_dt);
	void G1i_dt(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt);
	void qi_dt(double t,vector<double> Omega,vector<double>  &dqi_dt);

	void voltagei_1_dt(double t,vector<double> y,vector<double> amp,vector<double> &dv_dt);
    void mi_1_dt(double t,vector<double> y, vector<double>  &dmi_dt);
	void hi_1_dt(double t,vector<double> y,vector<double>  &dhi_dt);
	void ni_1_dt(double t,vector<double> y, vector<double>  &dni_dt);
	void Gi_1_dt(double t,vector<double> y,vector<double>  &Gi_dt);
	void G1i_1_dt(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt);
	void qi_1_dt(double t,vector<double> Omega,vector<double>  &dqi_dt);

    vector<vector<double> > ISIJin2(int N, double Dt,vector<double> y_0, vector<double> Omega,vector<vector<double> >Couple,vector<double> amp, double *out_y,double *out_y2,int Length_NN);
    void Morris_Lecar_Solve2(int N,double Dt, vector<double> y_0, vector<double> Omega,vector<vector<double> >Couple,vector<double> amp, double *out_y,double *out_y2,int Length_NN);
    void voltageio_dt(double t,vector<double> y,vector<double> amp,vector<double> &dv_dt);
    void mio_dt(double t,vector<double> y, vector<double>  &dmi_dt);
	void hio_dt(double t,vector<double> y,vector<double>  &dhi_dt);
	void nio_dt(double t,vector<double> y, vector<double>  &dni_dt);
	void Gio_dt(double t,vector<double> y,vector<double>  &Gi_dt);
	void G1io_dt(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt);
	void qio_dt(double t,vector<double> Omega,vector<double>  &dqi_dt);



//}

#endif // _THHfunciton_h_
