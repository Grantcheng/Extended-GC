#include "HHconst.h"
#include "neuron.h"

using namespace std;

void neuron_destroy (neuron &neu)
{
	if(neu.is_allocated == true)
	{
		free(neu.value);
		
		neu.value = NULL;

		neu.is_allocated = false;
	}
};

void neuron_initialize(neuron& neu)
{
	neu.value = NULL;

	neu.is_allocated = false;
};

void neuron_set_value(neuron& neu, int typ, int state_neu, int step_con)
{
	neuron_destroy(neu);
	
	neu.type = typ; 
	neu.state_neuron = state_neu; 
	neu.step_conductance = step_con;
 #if Autonomy_Use
	neu.value = (double *)malloc(sizeof(double)*(2*step_con+5));
        assert(neu.value);

	for (int i = 0; i < (2*step_con+5); i++)
	{
		neu.value[i] = 0; 
	}
#else
        neu.value = (double *)malloc(sizeof(double)*(2*step_con+4));
        assert(neu.value);
	for (int i = 0; i < (2*step_con+4); i++)
	{
		neu.value[i] = 0; 
	}
#endif
	neu.is_allocated = true;
};

void neuron_copy(neuron &neu, const neuron &src) 
{
	// free the allocated memory for neu first
	if(neu.is_allocated == true)
	{
		neuron_destroy(neu);
	}
	
	neu.is_allocated = src.is_allocated;

	if(neu.is_allocated == false)
	{
		cout<<"the source neuron is null!"<<endl;
		return;
	}
	else
	{
		neu.type = src.type;

		neu.state_neuron = src.state_neuron;

		neu.step_conductance = src.step_conductance;

#if Autonomy_Use
		neu.value = (double *)malloc(sizeof(double)*(2*src.step_conductance+5));
		assert(neu.value);

		memcpy(neu.value,src.value,sizeof(double)*(2*src.step_conductance+5));
#else
                neu.value = (double *)malloc(sizeof(double)*(2*src.step_conductance+4));
		assert(neu.value);

		memcpy(neu.value,src.value,sizeof(double)*(2*src.step_conductance+4));

#endif
	}
};

void neuron_output(neuron &neu, int index)
{
	cout<<index<<"th neuron: "<<endl;
	cout<<"type: "<<neu.type<<endl;
	cout<<"state: "<<neu.state_neuron<<endl;
	cout<<"step of smoothness for conductance: "<<neu.step_conductance<<endl;
	cout<<"voltage, conductance, refractory period: "<<endl;
#if Autonomy_Use
#if SMOOTH_CONDUCTANCE_USE
	cout<<neu.value[0]<<" "
		<<neu.value[1]<<" "<<neu.value[2]<<" "<<neu.value[3]<<" "<<neu.value[4]<<" "<<neu.value[3+Stepsmooth_Con]<<" "
		<<neu.value[Stepsmooth_Con+4]<<" "<<neu.value[2*Stepsmooth_Con+3]<<" "
		<<neu.value[size_neuronvar-1]<<endl;
#else
	cout<<neu.value[0]<<" "
		<<neu.value[1]<<" "<<neu.value[2]<<" "<<neu.value[3]<<" "<<neu.value[4]<<" "<<neu.value[Stepsmooth_Con+4]<<" "
		<<neu.value[size_neuronvar-1]<<endl;
#endif
#else
#if SMOOTH_CONDUCTANCE_USE
	cout<<neu.value[0]<<" "
		<<neu.value[1]<<" "<<neu.value[2]<<" "<<neu.value[3]<<" "<<neu.value[2+Stepsmooth_Con]<<" "
		<<neu.value[Stepsmooth_Con+3]<<" "<<neu.value[2*Stepsmooth_Con+2]<<" "
		<<neu.value[size_neuronvar-1]<<endl;
#else
	cout<<neu.value[0]<<" "
		<<neu.value[1]<<" "<<neu.value[2]<<" "<<neu.value[3]<<" "<<neu.value[Stepsmooth_Con+3]<<" "
		<<neu.value[size_neuronvar-1]<<endl;
#endif

#endif
	cout<<"is_allocated: "<<neu.is_allocated<<endl;
}
