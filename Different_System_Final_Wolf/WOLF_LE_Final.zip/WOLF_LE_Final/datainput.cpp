#include <vector>
#include <iostream>
#include <cmath>
#include <iomanip>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <sstream>
#include "HHconst.h"
#include "random.h"
#include "datainput.h"
#include "poisson_input.h"
#include "neuron.h"
#include "loop.h"

using namespace std;
long initial_pertub_Ex = 0;
long initial_pertub_In = 0;
#if SMOOTH_CONDUCTANCE_USE
long initial_pertub_Ex_H;
long initial_pertub_In_H;
#endif
//*************************************************************************************************************
void readinput(char *filename)
{
	int verbose = 1;
        char varname[64];
	double temp = 0.0;

	ifstream data_readin;
	data_readin.open(filename, ios::in);
	
	while (!data_readin.eof())
	{
		data_readin>>varname;
		data_readin.ignore(2);
	
		if (strcmp(varname,"Tstep")==0)
		{
			data_readin>>Tstep;
			if (verbose)
			{
				cout<<"Time step read to be: "<<Tstep<<endl;
			}
			continue;
		}
		 
                if (strcmp(varname,"Rate_input")==0)
		{
			data_readin>>Rate_input;
			if (verbose)
			{
				cout<<"Poisson input rate read to be: "<<Rate_input<<endl;
			}
			continue;
		}

		if (strcmp(varname,"Strength_Exinput")==0)
		{
			data_readin>>Strength_Exinput;
			if (verbose)
			{
				cout<<"Poisson input strength to Ex. neurons read to be: "
					<<Strength_Exinput<<endl;
			}
			continue;
		}
		if (strcmp(varname,"Strength_Ininput")==0)
		{
			data_readin>>Strength_Ininput;
			if (verbose)
			{
				cout<<"Poisson input strength to In. neurons read to be: "
					<<Strength_Ininput<<endl;
			}
			continue;
		}
		 
		if (strcmp(varname,"initial_pertub_Ex")==0)
		{
			data_readin>>initial_pertub_Ex;
			if (verbose)
			{
				cout<<"initial random seed for excitatory conductance read to be: "
					<<initial_pertub_Ex<<endl;
			}
			continue;
		}
#if SMOOTH_CONDUCTANCE_USE
		if (strcmp(varname,"initial_pertub_Ex_H")==0)
		{
			data_readin>>initial_pertub_Ex_H;
			if (verbose)
			{
				cout<<"initial random seed for subexcitatory conductance read to be: "
					<<initial_pertub_Ex_H<<endl;
			}
			continue;
		}
#endif
		if (strcmp(varname,"initial_pertub_In")==0)
		{
			data_readin>>initial_pertub_In;
			if (verbose)
			{
				cout<<"initial random seed for inhibitory conductance read to be: "
					<<initial_pertub_In<<endl;
			}
			continue;
		}
#if SMOOTH_CONDUCTANCE_USE
		if (strcmp(varname,"initial_pertub_In_H")==0)
		{
			data_readin>>initial_pertub_In_H;
			if (verbose)
			{
				cout<<"initial random seed for subinhibitory conductance read to be: "
					<<initial_pertub_In_H<<endl;
			}
			continue;
		}
#endif
		if (strcmp(varname,"initial_seed")==0)
		{
			data_readin>>initial_seed;
			if (verbose)
			{
				cout<<"initial seed for poisson input generator read to be: "
					<<initial_seed<<endl;
			}
			continue;
		}
		if (strcmp(varname,"average_current")==0)
		{
			data_readin>>Current_0;
			if (verbose)
			{
				cout<<"Current_0 read to be: "
					<<Current_0<<endl;
			}
			continue;
		}
		if (strcmp(varname,"amplitude_current")==0)
		{
			data_readin>>Current_1;
			if (verbose)
			{
				cout<<"Current_1 read to be: "
					<<Current_1<<endl;
			}
			continue;
		}
		if (strcmp(varname,"last_time")==0)
		{
			data_readin>>last_time;
			if (verbose)
			{
				cout<<"ending time of the last run read to be: "
					<<last_time<<endl;
			}
			continue;
		}
		// if there is no corresponding variable, just go to the next line to read!!!
		data_readin>>temp;
		if (verbose)
		{
			cout<<"no variables to match!"<<endl;
		}
	}
	data_readin.close();
	data_readin.clear();
};

//*************************************************************************************************************
void setglobals()
{
	int i,n;
        int totalnum = Number_Exneuron + Number_Inneuron; // number of neurons

#if FFTW_USE
// each neuron's voltage doing Fourier transform and also the average voltage
    fftw_voltage = (struct loop*)malloc(sizeof(loop)*(totalnum+1));
	
	POWER_SPECTRUM_VOT = (double**)malloc(sizeof(double*)*(totalnum+1));
#endif


	neu = (neuron *)malloc(sizeof(neuron)*totalnum);

	for (i=0; i<totalnum; i++)
	{
		neuron_initialize(neu[i]);
	}

	// intialize the voltage, Exconductance and Inconductance
	for( i = 0; i < totalnum; i++ )
	{
		if ( i < Number_Exneuron ) 
		{
			neuron_set_value(neu[i], Type_Exneuron, STATE_ACTIVE, Stepsmooth_Con);
		}
		else 
		{
			neuron_set_value(neu[i], Type_Inneuron, STATE_ACTIVE, Stepsmooth_Con);
		}
	}

#if POISSON_INPUT_USE
	// poission_input[i] records the timing of poisson input spikes in some time interval for i'th neuron!
	poisson_input = (vector_v *)malloc(sizeof(vector_v)*totalnum);
        
	for (i=0; i<totalnum; i++)
	{
		vector_initialize(poisson_input[i]);
	}

	// record the initial random seed for each neuron!
	initialseed_neuron = (long *)malloc(sizeof(long)*totalnum); 
	assert(initialseed_neuron);
	last_input = (double *)malloc(sizeof(double)*totalnum);
	assert(last_input);

	ran_iy = (long *)malloc(sizeof(long)*totalnum);
	ran_iv = (long **)malloc(sizeof(long*)*totalnum);
	for (i=0; i<totalnum; i++)
	{
		ran_iy[i] = 0;
		ran_iv[i] = (long*)malloc(sizeof(long)*NTAB);
	}
#endif

#if FFTW_USE
	FFT_DATA_LENGTH = static_cast<int>((FFT_TIME_LENGTH/Tstep)+0.5f);

	for (i=0; i<=totalnum; i++)
	{
		loop_initialize(fftw_voltage[i]);
		loop_allocate(fftw_voltage[i], FFT_DATA_LENGTH);

	}

	FFTW_IN = (fftw_complex*)fftw_malloc(sizeof(fftw_complex)*FFT_DATA_LENGTH);
	FFTW_OUT = (fftw_complex*)fftw_malloc(sizeof(fftw_complex)*FFT_DATA_LENGTH);
	PLAN_FORWARD_FFT = fftw_plan_dft_1d(FFT_DATA_LENGTH,FFTW_IN,FFTW_OUT,FFTW_FORWARD,FFTW_MEASURE);
	PLAN_BACKWARD_FFT = fftw_plan_dft_1d(FFT_DATA_LENGTH,FFTW_IN,FFTW_OUT,FFTW_BACKWARD,FFTW_MEASURE);

	for (i=0; i<=totalnum; i++)
	{
		POWER_SPECTRUM_VOT[i] = (double*)calloc(FFT_DATA_LENGTH,sizeof(double));

	}
#endif
};
//*************************************************************************************************************
void input_initialization(vector<double> y_0)
{
	int i,j;
	int num_neuron = Number_Exneuron + Number_Inneuron;

#if Autonomy_Use 
for( int i= 0; i< num_neuron; i++ )
	{
           for(j = 0; j < y_0.size(); j++ )
		{
                   neu[i].value[j] = y_0[j];
                }
         }
cout<<endl;
#else
for( int i= 0; i< num_neuron; i++ )
	{
           for( j = 0; j< (y_0.size()-1); j++ )
		{
                neu[i].value[j] = y_0[j];
                }
         }
cout<<endl;
#endif

#if Autonomy_Use 
for( int i= 0; i< num_neuron; i++ )
	{
  neu[i].value[5] = ran0(&initial_pertub_Ex);
        }
cout<<endl;
#else
for( int i= 0; i< num_neuron; i++ )
	{
  neu[i].value[4] = ran0(&initial_pertub_Ex);
        }
cout<<endl;
#endif

#if SMOOTH_CONDUCTANCE_USE
#if Autonomy_Use 
	for( i = 0; i < num_neuron; i++ )
	{
		neu[i].value[4+Stepsmooth_Con] = ran0(&initial_pertub_Ex_H);
	}	
	cout<<endl;
#else
	for( i = 0; i < num_neuron; i++ )
	{
		neu[i].value[3+Stepsmooth_Con] = ran0(&initial_pertub_Ex_H);
	}	
	cout<<endl;
#endif // end of using smooth conductance!
#endif

#if Autonomy_Use 
	for( i = 0; i < num_neuron; i++ )
	{
		neu[i].value[Stepsmooth_Con+5] = (1 - NONE_INHIBITORY)*ran0(&initial_pertub_In);
	}
#else
	for( i = 0; i < num_neuron; i++ )
	{
		neu[i].value[Stepsmooth_Con+4] = (1 - NONE_INHIBITORY)*ran0(&initial_pertub_In);
	}
#endif

#if SMOOTH_CONDUCTANCE_USE
#if Autonomy_Use 
	for( i = 0; i < num_neuron; i++ )
	{
		neu[i].value[2*Stepsmooth_Con+4] = (1 - NONE_INHIBITORY)*ran0(&initial_pertub_In_H);
	}
#else
	for( i = 0; i < num_neuron; i++ )
	{
		neu[i].value[2*Stepsmooth_Con+3] = (1 - NONE_INHIBITORY)*ran0(&initial_pertub_In_H);
	}
#endif
#endif // end of using smooth conductance!

#if POISSON_INPUT_USE
	srand(initial_seed);
	for( i = 0; i < num_neuron; i++ )
	{
		initialseed_neuron[i] = (long) -rand();

		last_input[i] = -log(RANDOM(initialseed_neuron+i,ran_iy,ran_iv,i))/Rate_input;
//		cout<<last_input[i]<<endl;
//		getchar();
	}
#endif

	iset = 0;
	gset = 0.0;

	time_evolution = last_time;



#if FFTW_USE
	FFT_POWER_LENGTH = 0;
#endif

};

//*************************************************************************************************************
void poisson_generator(int index_neuron, vector_v &Timing_input,double Tstep_1)
// generate poisson input spikes for each neuron in each time interval!
// remember to release the dynamic space of vector Timing_input after doing all computation of each time step!
{
	// " >= " means dealing with the input spike at the starting point of the time interval!
	if (last_input[index_neuron] >= Tstep_1) // there is no poisson spike input in this timestep interval!
	{
		last_input[index_neuron] -= Tstep_1; // continue to deal with the next interval!
		// set the first value less than zero: no input spikes in this interval
		vector_initialize(Timing_input);

		return;
	}

	long *idum = (initialseed_neuron+index_neuron);
	int size = 0;
	double spiketiming_wait = last_input[index_neuron];
	vector_v vect1; // temporal vector to instore the poisson input timing in this interval!
	vector_initialize(vect1);
	vector_set_value(vect1,Maxnum_input,0.0);
	
	do 
	{ 
		spiketiming_wait += -log(RANDOM(initialseed_neuron+index_neuron,ran_iy,ran_iv,index_neuron))/Rate_input;
		vect1.vect_value[size] = spiketiming_wait;
		size++;		
	} while ( spiketiming_wait < Tstep_1 );

	if(size >= Maxnum_input) 
	{
		cout<<"There are more spikes exceeding the capacity of vector!"<<endl;
		cout<<"Please enlarge the Maximum size of vector!"<<endl;
		exit(1);
	}

	// Timing_input contains all poisson input spikes in this time interval!
	// the first value is recorded as last_input[index_neuron]
	// the last value is recorded as the (size-1)th value of vect1
	
/****************************************************************************
// why does this sentence cause trouble???!!!
//	if(Timing_input.vect_value != NULL)
//	{
//		vector_destroy(Timing_input);
//	}
// 这里注意一点：由于初始对整个poisson_input分配了totalnum个vector的空间
// 即使每个poisson_input[i]还没有具体分配空间，但是它们的地址不是NULL（而且
// 即使对poisson_input没有分配空间，每个poisson_input[i]的值也不是NULL，而是
// 传说中的野指针），因此if语句的条件判断不再有效，而进入if语句后，执行vector_destroy
// 函数将会出错，因为这时并没有对Timing_input进行动态分配空间，而执行free函数是非法的
*///**************************************************************************
	vector_set_value(Timing_input, size, last_input[index_neuron]);
	
	for (int i=0; i<(size-1); i++)
	{
		Timing_input.vect_value[i+1] = vect1.vect_value[i];
	}
	// last_input records the nearest poisson input spike waiting time beyond this time interval!
	last_input[index_neuron] = vect1.vect_value[size-1] - Tstep_1; 
    
	vector_destroy(vect1);
};

#if FFTW_USE // start of using fftw package
void powerspectrum_vot_BINrecord()
{
	int i, j;
	int totalnum = Number_Exneuron + Number_Inneuron;
	int name = (int) (1.0/Tstep);
	int catalog = (int) (Rate_input*1000);

	char *str_vol=(char *)malloc(1024*sizeof(char));
	if (str_vol == NULL)
	{
		cout<<"can not allocate space!"<<endl;
		getchar();
	}

	ofstream powervot_write;

#ifdef _WINDOWS_USE_ // use windows
#if RK4_RUN
	sprintf(str_vol,".\\RK4\\%s\\powervot_%d.dat", FILELOG, name);
#endif

#else // not using windows
#if RK4_RUN
	sprintf(str_vol,"./RK4/%s/powervot_%d.dat", FILELOG, name);
#endif

#endif // whether use windows or not

	powervot_write.open(str_vol, ios::out | ios::binary);
	if ( powervot_write.fail() )
	{
		cout<<"Error: open power spectrum of voltage file error!"<<endl;
		getchar();
		return;
	}

	// record size of loop
	/* in order to be consistent with the matlab column-dominant reading elements!
	first write the length of loop, then write the size of neurons. */
	powervot_write.write((char*)(&(FFT_DATA_LENGTH)), sizeof(int));
	int size = totalnum+1;
	powervot_write.write((char*)(&size), sizeof(int));

	// get the averaged power spectrum for voltage
	double **temp_vot = (double**)malloc(sizeof(double*)*(totalnum+1));
	for (i=0; i<=totalnum; i++)
	{
		temp_vot[i] = (double*)malloc(sizeof(double)*FFT_DATA_LENGTH);
		for (j=0; j<FFT_DATA_LENGTH; j++)
		{
			/* 
			This is dangerous when you do things like this. Because if you turn on
			the "RECORD_TAG_USE" which means saving data in the middle of program, the 
		    actural value of "POWER_SPECTRUM_VOT" will be changed, Then as the program 
			keeps running, you will get the wrong data of "POWER_SPECTRUM_VOT".	
			*/
//			POWER_SPECTRUM_VOT[i][j] = POWER_SPECTRUM_VOT[i][j]*1.0/FFT_POWER_LENGTH;
			temp_vot[i][j] = POWER_SPECTRUM_VOT[i][j]*1.0/FFT_POWER_LENGTH;
		}
	}

	for (i=0; i<=totalnum; i++)
	{
		powervot_write.write((char*)(temp_vot[i]), FFT_DATA_LENGTH*sizeof(double));
	}

	powervot_write.close();
	powervot_write.clear();

	free(str_vol);

	for (i=0; i<=totalnum; i++)
	{
		free(temp_vot[i]);
	}
	free(temp_vot);
	temp_vot = NULL;
}
#endif // end of using fftw



void data_dump()
{
	int i;
	int totalnum = Number_Exneuron + Number_Inneuron;
#if POISSON_INPUT_USE
	free(initialseed_neuron);
	initialseed_neuron = NULL;

	free(ran_iy);
	ran_iy = NULL;

	free(last_input);
	last_input = NULL;
#endif
	for( i = 0; i < totalnum; i++ ) 
	{
		neuron_destroy(neu[i]);

#if POISSON_INPUT_USE
		free(ran_iv[i]);
		vector_destroy(poisson_input[i]);
#endif


	}

#if POISSON_INPUT_USE
	free(ran_iv);
	ran_iv = NULL;

	free(poisson_input);
	poisson_input = NULL;
#endif

	free(neu);
	neu = NULL;

#if FFTW_USE // start of using FFT ***************
	for (i=0; i<=totalnum; i++)
	{
		loop_destroy(fftw_voltage[i]);
		free(POWER_SPECTRUM_VOT[i]);
	}

	free(fftw_voltage);
	fftw_voltage = NULL;

	free(POWER_SPECTRUM_VOT);
	POWER_SPECTRUM_VOT = NULL;

	fftw_destroy_plan(PLAN_FORWARD_FFT);
	fftw_destroy_plan(PLAN_BACKWARD_FFT);

	fftw_free(FFTW_IN);
	fftw_free(FFTW_OUT);
#endif // end of using FFT *********************
}
