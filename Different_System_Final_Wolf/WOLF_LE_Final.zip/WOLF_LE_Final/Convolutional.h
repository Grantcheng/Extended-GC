#ifndef _Convolutional_H_
#define _Convolutional_H_

struct array
{
float* pStart;
    int length;
};

struct array conv(array a,array b);
#endif
