#include <cstdlib>
#include <vector>
#include <string>
#include <iostream>
#include <cmath>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <stdio.h>
#include <time.h>
#include <fftw3.h>
#include "Lya_input.h"
#include "Different_System_RK4.h"
#include "HHconst.h"
#include "Duffing_Equation.h"
#include "RK4.h"
#include "SHHfunction.h"
#include "THHfunciton.h"
#include "poisson_input.h"
#include "neuron.h"
#include "loop.h"
#include "datainput.h"
#include "WhiteNoise.h"
#include "Convolutional.h"
#include "random.h"


using namespace std;

int MUL_VAR_NUM; /* number of perturbed variables, the order is: voltagei, mi,hi,ni,Gi,G1i,qi,
where the i index the i th neuron, if i==1, then the condounce term don't consider*/
vector<vector<double> > Lyapunov;
vector<vector<double> > Local_LE_Classic;
vector<vector<double> > Local_LE_Classic_Mul_Exp;
vector<vector<double> > Lp_Mul_Exp;
vector<double> Lp;//  the end value of Lp is the Omega
int name_iter=0;
vector<vector<double> > mul_lya_neu_0;//the reference trajectory;
vector<vector<double> > mul_lya_perturb_0; //perturbation trajectory;
vector<vector<double> > Af_Evolution_Value_0;//after Detal time perturbed trajectories;
vector<vector<double> > Difference_Refer_Perturb_Value_0;//The difference between each perturbed trajectory and the reference trajectory
vector<vector<double> >U ; //a set of orthonormal vectors
vector<vector<double> > V;
vector<double> T0,T1;
vector<vector<double> > Y0,Temp;
int COMP_TIME=1000000;
int COMP_TIME_SCI=50000; //5s
clock_t start_le,finish_le;
int LE_Convergence;
int N_Length;
double h_white;


void LyaHH_Poisson (vector<double> y_0, vector<double> Omega,double Dt) //Compute single neuron lyapunove exponent
 {
        double duration_le;
        double h=Dt;
        int N=10;
	cout<<N<<endl<<h<<endl;
        cout<<"The COMP_TIME is "<<COMP_TIME<<endl;
        cout<<"Now is running Choice_HH_Ori = "<<Choice_HH_Ori<<endl;
        cout<<"Autonomy_Use = "<<Autonomy_Use<<endl;
        double Detalt=N*h;
        Tstep=h;
	 cout<<"Now is running single Lyapunov exponents"<<endl;
         
	double Tstart=0;//initial time;
	vector<double> mod(HH_Poisson_MUL_NUM_LYA);
        vector<double> mod_p(HH_Poisson_MUL_NUM_LYA);

        /*
        vector<vector<double> > V_p;
        V_p.resize(1);	
         */

	// start of computing multiple lya-exponent initial  ******************
	int Dimension;
	Dimension=y_0.size();MUL_VAR_NUM=Dimension; //Dimension==MUL_VAR_NUM
	mul_lya_neu_0.resize(HH_Poisson_MUL_NUM_LYA);
	mul_lya_perturb_0.resize(HH_Poisson_MUL_NUM_LYA);
	Lyapunov.resize(HH_Poisson_MUL_NUM_LYA);
        Local_LE_Classic.resize(1);
	Lp.resize((HH_Poisson_MUL_NUM_LYA));
	Af_Evolution_Value_0.resize(HH_Poisson_MUL_NUM_LYA);
	Difference_Refer_Perturb_Value_0.resize(HH_Poisson_MUL_NUM_LYA);
	U.resize(HH_Poisson_MUL_NUM_LYA);

        cout<<"HH_Poisson_MUL_NUM_LYA = "<<HH_Poisson_MUL_NUM_LYA<<endl;

	for(int q=0;q<HH_Poisson_MUL_NUM_LYA;q++)
	{
		Difference_Refer_Perturb_Value_0[q].resize(Dimension);
		U[q].resize(MUL_VAR_NUM);
	}
	     for(int k=0;k<HH_Poisson_MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_neu_0[k].push_back(y_0[i]);	
                        }

			mul_lya_perturb_0[k].resize(Dimension);
	         }
//*********************************************************************
	for(int k=0;k<HH_Poisson_MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i];
			}
			mul_lya_perturb_0[k][k]=mul_lya_perturb_0[k][k]+SMALL_DISPLACE;
	         } //end the initial of computing lya-ex;
//*********************************************************************
int iter=1; int sum_time_evolution=1;
Y0.resize(N);
Temp.resize(N);
start_le=clock();

poisson_input_ml = (vector_v *)malloc(sizeof(vector_v)*N);

for (int ml_i=0; ml_i<N; ml_i++)
		{
			vector_initialize(poisson_input_ml[ml_i]);
		}

while(1)
	{                         
               if (Choice_HH_Ori==0)
		{
	        //Neuron_Solution(int N,double h,vector<vector<double> >&y,vector<double> y_0)		
                //Runge_Kutta4(mul_lya_neu_0[0],Omega,Tstart,N,h,Y0,T0,voltage_dt,m_dt,h_dt,n_dt,qq_dt);
                // Neuron_Solution(N,Tstep,Tstart,Omega,Y0,mul_lya_neu_0[0]);
                 Neuron_Solution_ISIjin(N,Tstep,Tstart,Omega,Y0,mul_lya_neu_0[0],0);	
		}
		else if (Choice_HH_Ori==1)
		{
			// Neuron_Solution(N,Tstep,Tstart,Omega,Y0,mul_lya_neu_0[0]);
		         Neuron_Solution_ISIjin(N,Tstep,Tstart,Omega,Y0,mul_lya_neu_0[0],0);
                 }

		for(int k=0;k<HH_Poisson_MUL_NUM_LYA;k++) //HH_Poisson_MUL_NUM_LYA ---column
		{
                        if (Choice_HH_Ori==0)
			{
			//Runge_Kutta4(mul_lya_perturb_0[k],Omega,Tstart,N,h,Temp,T1,voltage_dt,m_dt,h_dt,n_dt,qq_dt);
			 // Neuron_Solution(N,Tstep,Tstart,Omega,Temp,mul_lya_perturb_0[k]);	
			Neuron_Solution_ISIjin(N,Tstep,Tstart,Omega,Temp,mul_lya_perturb_0[k],1);
			}
			else if (Choice_HH_Ori==1)
			{
                        //Runge_Kutta4(mul_lya_perturb_0[k],Omega,Tstart,N,h,Temp,T1,voltageo_dt,mo_dt,ho_dt,no_dt,qqo_dt);
                         // Neuron_Solution(N,Tstep,Tstart,Omega,Temp,mul_lya_perturb_0[k]);
                         Neuron_Solution_ISIjin(N,Tstep,Tstart,Omega,Temp,mul_lya_perturb_0[k],1);
			}
			Af_Evolution_Value_0[k]=Temp.back();
			mul_lya_neu_0[k]=Y0.back();
                
                       for(int i_N=0;i_N<N;i_N++)
                           {    while (!Temp[i_N].empty())
				{
			             Temp[i_N].pop_back();
				}
                           }

                }

                
                for(int i_N=0;i_N<N;i_N++)
                     {    while (!Y0[i_N].empty())
				{
					Y0[i_N].pop_back();
				}
                     }
                for (int ml_i=0; ml_i<N; ml_i++)
		        {
				vector_destroy(poisson_input_ml[ml_i]);
			}
                                  
		for(int k=0;k<HH_Poisson_MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{
		Difference_Refer_Perturb_Value_0[k][i]=Af_Evolution_Value_0[k][i]-mul_lya_neu_0[k][i];

			}
		}
			V=MGS(Difference_Refer_Perturb_Value_0);
//********************************************************************test the MGS results
           /* 
                 for(int p=0;p<HH_Poisson_MUL_NUM_LYA;p++)
				for(int l=p+1;l<=HH_Poisson_MUL_NUM_LYA;l++)
				{
			{
				cout<<setprecision(16)<<scalar_product(V[p],V[l])<<endl;
			}
				}
          */
//****************************************************************************************
		for(int m=0;m<HH_Poisson_MUL_NUM_LYA;m++)
			{
				mod[m]=sqrt(scalar_product(V[m],V[m]))*SMALL_DISPLACE;
			
			}
                 //**************************
/*
                      V_p[0].resize(7);
                     for(int i_p=0;i_p<5;i_p++)
			{
                          V_p[0][i_p]=V[0][i_p];

			}	
                         V_p[0][5]=V[0][5];
                         V_p[0][6]=V[0][7];
                         mod_p[0]=sqrt(scalar_product(V_p[0],V_p[0]))*SMALL_DISPLACE;
*/
                  //**************************
		for(int m=0;m<HH_Poisson_MUL_NUM_LYA;m++) 
			{
		
			for(int n=0;n<MUL_VAR_NUM;n++)  //MUL_VAR_NUM--rows
					{
					U[m][n]=V[m][n]/mod[m];
					}
			}

		Tstart=Tstart+Detalt;


		for(int m=0;m<HH_Poisson_MUL_NUM_LYA;m++) 
		{
		       Lp[m]+=log(mod[m]/SMALL_DISPLACE)/Detalt;	
                      // Lp[m]+=log(mod_p[m]/SMALL_DISPLACE)/Detalt;

		}
                       Local_LE_Classic[0].push_back(log(mod[0]/SMALL_DISPLACE)/Detalt); // get the local lyapunov exponent
                       Local_LE_Classic[0].push_back(mul_lya_neu_0[0][0]); // get the voltage
                      // Local_LE_Classic[0].push_back(mul_lya_neu_0[0][1]); // get the m
                      // Local_LE_Classic[0].push_back(mul_lya_neu_0[0][2]); // get the h
                      // Local_LE_Classic[0].push_back(mul_lya_neu_0[0][3]); // get the n

		for(int m=0;m<HH_Poisson_MUL_NUM_LYA;m++) 
		{
			Lyapunov[m].push_back(Lp[m]/iter);
		}

		
		if (iter==COMP_TIME)// Terminal at 3s time
			break;
		iter=iter+1;

		for(int k=0;k<HH_Poisson_MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i]+SMALL_DISPLACE*U[k][i];
			}
		}

           if ((iter%100000)==0)
		{
		finish_le=clock();
		duration_le=(double)(finish_le-start_le)/CLOCKS_PER_SEC;
		
                cout<<"Computing "<< iter <<" iter of LE processing cost =  "<<duration_le<<endl;
		}

	}//end while

   for(int k=0;k<HH_Poisson_MUL_NUM_LYA;k++)
   {
	   Lp[k]=Lp[k]/iter;
           cout<<" This System Classic Layapunov Exponent "<<Lp[k]<<endl;
   }
   cout<<endl;

   Lp.push_back(Omega[0]);

   mul_lya_record(Omega);
//release memory*****************
   FREE_1(mul_lya_neu_0);
   FREE_1(mul_lya_perturb_0);
   FREE_1(Af_Evolution_Value_0);
   FREE_1(Difference_Refer_Perturb_Value_0);
   FREE_1(Temp);
   FREE_1(Y0);
   FREE_1(V);
   FREE_1(U);
   FREE_2(T0);
   FREE_2(T1);
   vector<double> LP;
   Lp.swap(LP);
   FREE_1(Local_LE_Classic);
   free(poisson_input_ml);
//*******************************
 }

//******************Poisson input LE ************************************
void  LyaHH (vector<double> y_0, vector<double> Omega) //Compute single neuron lyapunove exponent
 {
        double h=0.01;
        int N=10;
	cout<<N<<endl<<h<<endl;
        cout<<"The COMP_TIME is "<<COMP_TIME<<endl;
        cout<<"Now is running Choice_HH_Ori = "<<Choice_HH_Ori<<endl;
        double Detalt=N*h;
	cout<<"Now is running HH Model single Lyapunov exponents"<<endl;
	double Tstart=0;//initial time;
	vector<double> mod(HH_MUL_NUM_LYA);	
	// start of computing multiple lya-exponent initial  ******************
	int Dimension;
	Dimension=y_0.size();MUL_VAR_NUM=Dimension; //Dimension==MUL_VAR_NUM
	mul_lya_neu_0.resize(HH_MUL_NUM_LYA);
	mul_lya_perturb_0.resize(HH_MUL_NUM_LYA);
	Lyapunov.resize(HH_MUL_NUM_LYA);
        Local_LE_Classic.resize(1);
	Lp.resize((HH_MUL_NUM_LYA));
	Af_Evolution_Value_0.resize(HH_MUL_NUM_LYA);
	Difference_Refer_Perturb_Value_0.resize(HH_MUL_NUM_LYA);
	U.resize(HH_MUL_NUM_LYA);

	for(int q=0;q<HH_MUL_NUM_LYA;q++)
	{
		Difference_Refer_Perturb_Value_0[q].resize(Dimension);
		U[q].resize(MUL_VAR_NUM);
	}

	for(int k=0;k<HH_MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ mul_lya_neu_0[k].push_back(y_0[i]);	}

			mul_lya_perturb_0[k].resize(Dimension);
        	}
//*********************************************************************
	for(int k=0;k<HH_MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i];
			}
			mul_lya_perturb_0[k][k]=mul_lya_perturb_0[k][k]+SMALL_DISPLACE;
	} //end the initial of computing lya-ex;

	int iter=1; int sum_time_evolution=1;
while(1)
	{
                if (Choice_HH_Ori==0)
		{
			Runge_Kutta4(mul_lya_neu_0[0],Omega,Tstart,N,h,Y0,T0,voltage_dt,m_dt,h_dt,n_dt,qq_dt);
		}
		else if (Choice_HH_Ori==1)
		{
			Runge_Kutta4(mul_lya_neu_0[0],Omega,Tstart,N,h,Y0,T0,voltageo_dt,mo_dt,ho_dt,no_dt,qqo_dt);
		}

		for(int k=0;k<HH_MUL_NUM_LYA;k++) //HH_MUL_NUM_LYA ---column
		{
                        if (Choice_HH_Ori==0)
			{
			Runge_Kutta4(mul_lya_perturb_0[k],Omega,Tstart,N,h,Temp,T1,voltage_dt,m_dt,h_dt,n_dt,qq_dt);
			}
			else if (Choice_HH_Ori==1)
			{
                        Runge_Kutta4(mul_lya_perturb_0[k],Omega,Tstart,N,h,Temp,T1,voltageo_dt,mo_dt,ho_dt,no_dt,qqo_dt);
			}
			Af_Evolution_Value_0[k]=Temp.back();
			mul_lya_neu_0[k]=Y0.back();
		}
		for(int k=0;k<HH_MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{
		Difference_Refer_Perturb_Value_0[k][i]=Af_Evolution_Value_0[k][i]-mul_lya_neu_0[k][i];

			}
		}
			V=MGS(Difference_Refer_Perturb_Value_0);
//********************************************************************test the MGS results
           /* for(int p=0;p<HH_MUL_NUM_LYA;p++)
				for(int l=p+1;l<=HH_MUL_NUM_LYA;l++)
				{
			{
				cout<<setprecision(16)<<scalar_product(V[p],V[l])<<endl;
			}
				}*/
//****************************************************************************************
		for(int m=0;m<HH_MUL_NUM_LYA;m++)
			{
				mod[m]=sqrt(scalar_product(V[m],V[m]))*SMALL_DISPLACE;
			
			}
		for(int m=0;m<HH_MUL_NUM_LYA;m++) 
			{
		
			for(int n=0;n<MUL_VAR_NUM;n++)  //MUL_VAR_NUM--rows
					{
					U[m][n]=V[m][n]/mod[m];
			
					}
			}

		Tstart=Tstart+Detalt;

		for(int m=0;m<HH_MUL_NUM_LYA;m++) 
		{
			Lp[m]+=log(mod[m]/SMALL_DISPLACE)/Detalt;

		}
                       Local_LE_Classic[0].push_back(log(mod[0]/SMALL_DISPLACE)/Detalt); // get the local lyapunov exponent
                       Local_LE_Classic[0].push_back(mul_lya_neu_0[0][0]);   
                    // Local_LE_Classic[0].push_back(Af_Evolution_Value_0[0][0]); // get the voltage (以前所得到数据使用的，所得结论可能有错误)
		for(int m=0;m<HH_MUL_NUM_LYA;m++) 
		{
			Lyapunov[m].push_back(Lp[m]/iter);
		}

		if (iter==COMP_TIME)// Terminal at 3s time
			break;
		iter=iter+1;

		for(int k=0;k<HH_MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i]+SMALL_DISPLACE*U[k][i];
			}
		}

	}//end while

   for(int k=0;k<HH_MUL_NUM_LYA;k++)
   {
	   Lp[k]=Lp[k]/iter;
           cout<<" This System Classic Layapunov Exponent "<<Lp[k]<<endl;
            
   }
   cout<<endl;

     Lp.push_back(Omega[0]);

   mul_lya_record(Omega);
   //release memory*****************
   FREE_1(mul_lya_neu_0);
   FREE_1(mul_lya_perturb_0);
   FREE_1(Af_Evolution_Value_0);
   FREE_1(Difference_Refer_Perturb_Value_0);
   FREE_1(Temp);
   FREE_1(Y0);
   FREE_1(V);
   FREE_1(U);
   FREE_1(Local_LE_Classic);
   FREE_1(Lyapunov);
   FREE_2(T0);
   FREE_2(T1);
   
   vector<double> LP;
   Lp.swap(LP);
   //*******************************
 }

//*****************************************************************************************************************************************

 void Mul_LyaHH (vector<double> y_0, vector<double> Omega,vector<vector<double> >Couple,vector<double> amp) //Compute Multipy neurons lyapunove exponents
 {
   double h=0.01;int N=100;
	 cout<<N<<endl<<h<<" ";
     double Detalt=N*h;
     Tstep=h;
	 cout<<"Now is running MultiNeuron Lyapunov exponents"<<endl;
        cout<<"How many LE will compute   "<<HH_MUL_NUM_LYA<<endl;
	  double Tstart=0;//initial time;
	 vector<double> mod(HH_MUL_NUM_LYA);	
	// start of computing multiple lya-exponent initial  ******************
	int Dimension;
	Dimension=y_0.size();MUL_VAR_NUM=Dimension; //Dimension==MUL_VAR_NUM
	mul_lya_neu_0.resize(HH_MUL_NUM_LYA);
	mul_lya_perturb_0.resize(HH_MUL_NUM_LYA);
	Lyapunov.resize(HH_MUL_NUM_LYA);
	Lp.resize((HH_MUL_NUM_LYA));
	Af_Evolution_Value_0.resize(HH_MUL_NUM_LYA);
	Difference_Refer_Perturb_Value_0.resize(HH_MUL_NUM_LYA);
	U.resize(HH_MUL_NUM_LYA);
	for(int q=0;q<HH_MUL_NUM_LYA;q++)
	{
		Difference_Refer_Perturb_Value_0[q].resize(Dimension);
		U[q].resize(MUL_VAR_NUM);
	}
	for(int k=0;k<HH_MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_neu_0[k].push_back(y_0[i]);	}

			mul_lya_perturb_0[k].resize(Dimension);
	}
//*********************************************************************
	for(int k=0;k<HH_MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i];
			}
			mul_lya_perturb_0[k][k]=mul_lya_perturb_0[k][k]+SMALL_DISPLACE;
	} //end the initial of computing lya-ex;

	int iter0=1; int sum_time_evolution=1;
	cout<<"the first w= "<< Omega[0]<<endl;
cout<<"the second w= "<< Omega[1]<<endl;
while(1)
	{
               if (Choice_HH_Ori==0)
		{
			Runge_Kutta4M(mul_lya_neu_0[0],Omega,Tstart,N,h,Y0,T0,Couple,amp,voltagei_dt,mi_dt,hi_dt,ni_dt,Gi_dt,G1i_dt,qi_dt);
		}
		else if (Choice_HH_Ori==1)
		{
			Runge_Kutta4M(mul_lya_neu_0[0],Omega,Tstart,N,h,Y0,T0,Couple,amp,voltageio_dt,mio_dt,hio_dt,nio_dt,Gio_dt,G1io_dt,qio_dt);
                }

		for(int k=0;k<HH_MUL_NUM_LYA;k++) //HH_MUL_NUM_LYA ---column
		{
			
                        if (Choice_HH_Ori==0)
			{
			    Runge_Kutta4M(mul_lya_perturb_0[k],Omega,Tstart,N,h,Temp,T1,Couple,amp,voltagei_dt,mi_dt,hi_dt,ni_dt,Gi_dt,G1i_dt,qi_dt);
			}
		        else if (Choice_HH_Ori==1)
		        {
			    Runge_Kutta4M(mul_lya_perturb_0[k],Omega,Tstart,N,h,Temp,T1,Couple,amp,voltageio_dt,mio_dt,hio_dt,nio_dt,Gio_dt,G1io_dt,qio_dt);
                        }
			Af_Evolution_Value_0[k]=Temp.back();
			mul_lya_neu_0[k]=Y0.back();
		}
		for(int k=0;k<HH_MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{
		Difference_Refer_Perturb_Value_0[k][i]=Af_Evolution_Value_0[k][i]-mul_lya_neu_0[k][i];

			}
		}
			V=MGS(Difference_Refer_Perturb_Value_0);
		for(int m=0;m<HH_MUL_NUM_LYA;m++)
			{
				mod[m]=sqrt(scalar_product(V[m],V[m]))*SMALL_DISPLACE;
			
			}
		for(int m=0;m<HH_MUL_NUM_LYA;m++) 
			{
		
			for(int n=0;n<MUL_VAR_NUM;n++)  //MUL_VAR_NUM--rows
					{
					U[m][n]=V[m][n]/mod[m];
			
					}
			}

		Tstart=Tstart+Detalt;


		for(int m=0;m<HH_MUL_NUM_LYA;m++) 
		{
			Lp[m]+=log(mod[m]/SMALL_DISPLACE)/Detalt;

		}
		for(int m=0;m<HH_MUL_NUM_LYA;m++) 
		{
			Lyapunov[m].push_back(Lp[m]/iter0);
		}

		
		if (iter0==10000)// Terminal at 1s time
			break;
		iter0=iter0+1;

		for(int k=0;k<HH_MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i]+SMALL_DISPLACE*U[k][i];
			}
		}

	}//end while

   for(int k=0;k<HH_MUL_NUM_LYA;k++)
   {
	   Lp[k]=Lp[k]/iter0;
           cout<<" This System Classic Layapunov Exponent "<<Lp[k]<<endl;
   }
   
   cout<<endl;
     Lp.push_back(Omega[0]);

	 cout<<"w= "<< Omega[0]<<endl;

   mul_lya_record(Omega);
   	//release memory*****************
   FREE_1(mul_lya_neu_0);
   FREE_1(mul_lya_perturb_0);
   FREE_1(Af_Evolution_Value_0);
   FREE_1(Difference_Refer_Perturb_Value_0);
   FREE_1(Temp);
   FREE_1(Y0);
   FREE_1(V);
   FREE_1(U);
   FREE_2(T0);
   FREE_2(T1);
	vector<double> LP;
	Lp.swap(LP);
	//*******************************
 }

void Lya (vector<double> y_0, vector<double> Omega,double alpha,double beta,double gamma,double force) //Compute Duffing lyapunove exponent
 {      
         double h=0.01;int N=100;
	 cout<<N<<endl<<h<<" ";
         double Detalt=N*h;
         Tstep=h;
	 cout<<"Now is running Duffing Lyapunov exponents"<<endl;
	  double Tstart=0;//initial time;
	vector<double> mod(MUL_NUM_LYA);	
	// start of computing multiple lya-exponent initial  ******************
	int Dimension;
	Dimension=y_0.size();MUL_VAR_NUM=Dimension; //Dimension==MUL_VAR_NUM
	mul_lya_neu_0.resize(MUL_NUM_LYA);
	mul_lya_perturb_0.resize(MUL_NUM_LYA);
	Lyapunov.resize(MUL_NUM_LYA);
	Lp.resize((MUL_NUM_LYA));
	Af_Evolution_Value_0.resize(MUL_NUM_LYA);
	Difference_Refer_Perturb_Value_0.resize(MUL_NUM_LYA);
	U.resize(MUL_NUM_LYA);

	for(int q=0;q<MUL_NUM_LYA;q++)
	{
		Difference_Refer_Perturb_Value_0[q].resize(Dimension);
		U[q].resize(MUL_VAR_NUM);
	}
	for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_neu_0[k].push_back(y_0[i]);	}

			mul_lya_perturb_0[k].resize(Dimension);
	}
//*********************************************************************
	for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i];
			}
			mul_lya_perturb_0[k][k]=mul_lya_perturb_0[k][k]+SMALL_DISPLACE;
	} //end the initial of computing lya-ex;

	int iter=1; 
while(1)
	{
		//Runge_Kutta4(mul_lya_neu_0[0],Omega,Tstart,N,h,Y0,T0,voltage_dt,m_dt,h_dt,n_dt,q_dt);
                System_Duffing_RK4(mul_lya_neu_0[0],Omega,Tstart,N,h,alpha, beta, gamma, force,Y0,T0,x_dt,y_dt,q_dt);               

		for(int k=0;k<MUL_NUM_LYA;k++) //MUL_NUM_LYA ---column
		{
			//Runge_Kutta4(mul_lya_perturb_0[k],Omega,Tstart,N,h,Temp,T1,voltage_dt,m_dt,h_dt,n_dt,q_dt);
                        System_Duffing_RK4(mul_lya_perturb_0[k],Omega,Tstart,N,h,alpha, beta, gamma, force,Temp,T1,x_dt,y_dt,q_dt);   
			Af_Evolution_Value_0[k]=Temp.back();
			mul_lya_neu_0[k]=Y0.back();
		}
		for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{
		Difference_Refer_Perturb_Value_0[k][i]=Af_Evolution_Value_0[k][i]-mul_lya_neu_0[k][i];

			}
		}
			V=MGS(Difference_Refer_Perturb_Value_0);
//********************************************************************test the MGS results
          /*
                    for(int p=0;p<MUL_NUM_LYA;p++)
				for(int l=p+1;l<=MUL_NUM_LYA;l++)
				{
			{
				cout<<setprecision(16)<<scalar_product(V[p],V[l])<<endl;
			}
				}
         */
//****************************************************************************************
		for(int m=0;m<MUL_NUM_LYA;m++)
			{
				mod[m]=sqrt(scalar_product(V[m],V[m]))*SMALL_DISPLACE;
			
			}
		for(int m=0;m<MUL_NUM_LYA;m++) 
			{
		
			for(int n=0;n<MUL_VAR_NUM;n++)  //MUL_VAR_NUM--rows
					{
					U[m][n]=V[m][n]/mod[m];
			
					}
			}

		Tstart=Tstart+Detalt;


		for(int m=0;m<MUL_NUM_LYA;m++) 
		{
			Lp[m]+=log(mod[m]/SMALL_DISPLACE)/Detalt;

		}
		for(int m=0;m<MUL_NUM_LYA;m++) 
		{
			Lyapunov[m].push_back(Lp[m]/iter);
		}

		
		if (iter==200000)// Terminal at 3s time
			break;
		iter=iter+1;

		for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i]+SMALL_DISPLACE*U[k][i];
			}
		}

	}//end while

   for(int k=0;k<MUL_NUM_LYA;k++)
   {
	   Lp[k]=Lp[k]/iter;
           cout<<" This System Classic Layapunov Exponent "<<Lp[k]<<endl;
            
   }
   cout<<endl;
   Lp.push_back(Omega[0]);

  // mul_lya_record(Omega);
   	//release memory*****************
   FREE_1(mul_lya_neu_0);
   FREE_1(mul_lya_perturb_0);
   FREE_1(Af_Evolution_Value_0);
   FREE_1(Difference_Refer_Perturb_Value_0);
   FREE_1(Temp);
   FREE_1(Y0);
   FREE_1(V);
   FREE_1(U);
   FREE_2(T0);
   FREE_2(T1);
   vector<double> LP;
   Lp.swap(LP);
	//*******************************
 }


void Lya_Sys (vector<double> y_0, vector<double> Omega,int E_C) //Compute Lorenz or Rossler lyapunove exponent
 {
        double h=0.001;int N=100;
	cout<<N<<endl<<h<<endl;
        double Detalt=N*h;
        Tstep=h;
         switch(E_C)
            {
                case 2:
                cout<<"Now is running Lorenz Lyapunov exponents"<<endl;
                break;
                case 3:
                cout<<"Now is running Rossler Lyapunov exponents"<<endl;
                break;
            }
	double Tstart=0;//initial time;
	vector<double> mod(MUL_NUM_LYA);	
	// start of computing multiple lya-exponent initial  ******************
	int Dimension;
	Dimension=y_0.size();
        MUL_VAR_NUM=Dimension; //Dimension==MUL_VAR_NUM
	mul_lya_neu_0.resize(MUL_NUM_LYA);
	mul_lya_perturb_0.resize(MUL_NUM_LYA);
	Lyapunov.resize(MUL_NUM_LYA);
	Lp.resize((MUL_NUM_LYA));
        Local_LE_Classic.resize(1);
	Af_Evolution_Value_0.resize(MUL_NUM_LYA);
	Difference_Refer_Perturb_Value_0.resize(MUL_NUM_LYA);
	U.resize(MUL_NUM_LYA);

	for(int q=0;q<MUL_NUM_LYA;q++)
	{
		Difference_Refer_Perturb_Value_0[q].resize(Dimension);
		U[q].resize(MUL_VAR_NUM);
	}
	for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_neu_0[k].push_back(y_0[i]);	}

			mul_lya_perturb_0[k].resize(Dimension);
	}
//*********************************************************************
	for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i];
			}
			mul_lya_perturb_0[k][k]=mul_lya_perturb_0[k][k]+SMALL_DISPLACE;
	} //end the initial of computing lya-ex;

	int iter=1; 
while(1)
	{
              switch(E_C)
            {
                case 2:

                System_Lorenz_RK4(mul_lya_neu_0[0],Omega,Tstart,N,h,Y0,T0,Lx_dt,Ly_dt,Lz_dt);
                break;
                case 3:

                System_Rossler_RK4(mul_lya_neu_0[0],Omega,Tstart,N,h,Y0,T0,Rx_dt,Ry_dt,Rz_dt);
                break;
            }

		for(int k=0;k<MUL_NUM_LYA;k++) //MUL_NUM_LYA ---column
		{
                    switch(E_C)
                        {
                         case 2:
			   System_Lorenz_RK4(mul_lya_perturb_0[k],Omega,Tstart,N,h,Temp,T1,Lx_dt,Ly_dt,Lz_dt); 
                           break;
                         case 3:
                           System_Rossler_RK4(mul_lya_perturb_0[k],Omega,Tstart,N,h,Temp,T1,Rx_dt,Ry_dt,Rz_dt);
                           break;
                        }
			Af_Evolution_Value_0[k]=Temp.back();
			mul_lya_neu_0[k]=Y0.back();
		}
		for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{
				Difference_Refer_Perturb_Value_0[k][i]=Af_Evolution_Value_0[k][i]-mul_lya_neu_0[k][i];

			}
		}
			V=MGS(Difference_Refer_Perturb_Value_0);

		for(int m=0;m<MUL_NUM_LYA;m++)
			{
				mod[m]=sqrt(scalar_product(V[m],V[m]))*SMALL_DISPLACE;
			
			}
		for(int m=0;m<MUL_NUM_LYA;m++) 
			{
		
			for(int n=0;n<MUL_VAR_NUM;n++)  //MUL_VAR_NUM--rows
					{
					U[m][n]=V[m][n]/mod[m];
			
					}
			}
                //********************************************************************test the MGS results

              /*
                 cout<<"test MGS results"<<endl;
                  for(int p=0;p<MUL_NUM_LYA;p++)
				for(int l=p+1;l<=MUL_NUM_LYA;l++)
				{
			{
				cout<<setprecision(16)<<scalar_product(U[p],U[l])*pow(SMALL_DISPLACE,2)<<endl;
			}
				}
               */

               //****************************************************************************************
		Tstart=Tstart+Detalt;


		for(int m=0;m<MUL_NUM_LYA;m++) 
		{
			Lp[m]+=log(mod[m]/SMALL_DISPLACE)/Detalt;

		}
                       Local_LE_Classic[0].push_back(log(mod[0]/SMALL_DISPLACE)/Detalt); // get the local lyapunov exponent
                       Local_LE_Classic[0].push_back(Af_Evolution_Value_0[0][0]); // get the voltage
		for(int m=0;m<MUL_NUM_LYA;m++) 
		{
			Lyapunov[m].push_back(Lp[m]/iter);
		}

		
		if (iter==50000)// Terminal at 3s time
			break;
		iter=iter+1;

		for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i]+SMALL_DISPLACE*U[k][i];
			}
		}

	}//end while

   for(int k=0;k<MUL_NUM_LYA;k++)
   {
	   Lp[k]=Lp[k]/iter;
           cout<<" This System Classic Layapunov Exponent "<<Lp[k]<<endl;
            
   }
   cout<<endl;
   Lp.push_back(Omega[0]);

   mul_lya_record(Omega);
   	//release memory*****************
   FREE_1(mul_lya_neu_0);
   FREE_1(mul_lya_perturb_0);
   FREE_1(Af_Evolution_Value_0);
   FREE_1(Difference_Refer_Perturb_Value_0);
   FREE_1(Temp);
   FREE_1(Y0);
   FREE_1(V);
   FREE_1(U);
   FREE_2(T0);
   FREE_2(T1);
   vector<double> LP;
   Lp.swap(LP);
	//*******************************
 }

// Morris Lecar Model
void LyaML (vector<double> y_0, vector<double> Omega) //Compute Morris Lecar model neuron lyapunove exponent
 {
        double h=0.01;int N=10;
	cout<<N<<endl<<h<<endl;
        cout<<"The Ampl= "<<amp1<<endl;
        double Detalt=N*h;
        Tstep=h;
	cout<<"Now is running Morris Lecar single neuron Lyapunov exponents"<<endl;
	double Tstart=0;//initial time;
	vector<double> mod(MUL_NUM_LYA);	
	// start of computing multiple lya-exponent initial  ******************
	int Dimension;
	Dimension=y_0.size();MUL_VAR_NUM=Dimension; //Dimension==MUL_VAR_NUM
	mul_lya_neu_0.resize(MUL_NUM_LYA);
	mul_lya_perturb_0.resize(MUL_NUM_LYA);
	Lyapunov.resize(MUL_NUM_LYA);
        Local_LE_Classic.resize(1);
	Lp.resize((MUL_NUM_LYA));
	Af_Evolution_Value_0.resize(MUL_NUM_LYA);
	Difference_Refer_Perturb_Value_0.resize(MUL_NUM_LYA);
	U.resize(MUL_NUM_LYA);

	for(int q=0;q<MUL_NUM_LYA;q++)
	{
		Difference_Refer_Perturb_Value_0[q].resize(Dimension);
		U[q].resize(MUL_VAR_NUM);
	}
	for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_neu_0[k].push_back(y_0[i]);	}

			mul_lya_perturb_0[k].resize(Dimension);
	}
//*********************************************************************
	for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i];
			}
			mul_lya_perturb_0[k][k]=mul_lya_perturb_0[k][k]+SMALL_DISPLACE;
	} //end the initial of computing lya-ex;

	int iter=1; int sum_time_evolution=1;

        cout<<"Amp = "<<amp1<<endl;
        cout<<"Current_0 = "<<Current_0<<endl;
        cout<<"Current_1 = "<<Current_1<<endl;
        cout<<"Omega = "<<Omega[0]<<endl;

while(1)
	{           
		System_Morris_Lecar_RK4(mul_lya_neu_0[0],Omega,Tstart,N,h,Y0,T0,MLv0_dt,MLw0_dt,Mqq0_dt);

		for(int k=0;k<MUL_NUM_LYA;k++) //MUL_NUM_LYA ---column
		{
			System_Morris_Lecar_RK4(mul_lya_perturb_0[k],Omega,Tstart,N,h,Temp,T1,MLv0_dt,MLw0_dt,Mqq0_dt);

			Af_Evolution_Value_0[k]=Temp.back();
			mul_lya_neu_0[k]=Y0.back();
		}
		for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{
		Difference_Refer_Perturb_Value_0[k][i]=Af_Evolution_Value_0[k][i]-mul_lya_neu_0[k][i];

			}
		}
			V=MGS(Difference_Refer_Perturb_Value_0);
//********************************************************************test the MGS results
           /* for(int p=0;p<MUL_NUM_LYA;p++)
				for(int l=p+1;l<=MUL_NUM_LYA;l++)
				{
			{
				cout<<setprecision(16)<<scalar_product(V[p],V[l])<<endl;
			}
				}*/
//****************************************************************************************
		for(int m=0;m<MUL_NUM_LYA;m++)
			{
				mod[m]=sqrt(scalar_product(V[m],V[m]))*SMALL_DISPLACE;
			
			}
		for(int m=0;m<MUL_NUM_LYA;m++) 
			{
		
			for(int n=0;n<MUL_VAR_NUM;n++)  //MUL_VAR_NUM--rows
					{
					U[m][n]=V[m][n]/mod[m];
			
					}
			}

		Tstart=Tstart+Detalt;


		for(int m=0;m<MUL_NUM_LYA;m++) 
		{
			Lp[m]+=log(mod[m]/SMALL_DISPLACE)/Detalt;

		}
                       Local_LE_Classic[0].push_back(log(mod[0]/SMALL_DISPLACE)/Detalt); // get the local lyapunov exponent
                       Local_LE_Classic[0].push_back(Af_Evolution_Value_0[0][0]); // get the voltage
		for(int m=0;m<MUL_NUM_LYA;m++) 
		{
			Lyapunov[m].push_back(Lp[m]/iter);
		}

		
		if (iter==COMP_TIME)// Terminal at 200s time
			break;
		iter=iter+1;

		for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i]+SMALL_DISPLACE*U[k][i];
			}
		}

	}//end while

   for(int k=0;k<MUL_NUM_LYA;k++)
   {
	   Lp[k]=Lp[k]/iter;
           cout<<" This System Classic Layapunov Exponent "<<Lp[k]<<endl;
            
   }
   cout<<endl;
 if (chose_current_change==0)
  {
     Lp.push_back(Omega[0]);
  }
else  if (chose_current_change==1)
  {
     Lp.push_back(Current_0);
  }
   mul_lya_record(Omega);
   	//release memory*****************
   FREE_1(mul_lya_neu_0);
   FREE_1(mul_lya_perturb_0);
   FREE_1(Af_Evolution_Value_0);
   FREE_1(Difference_Refer_Perturb_Value_0);
   FREE_1(Temp);
   FREE_1(Y0);
   FREE_1(V);
   FREE_1(U);
   FREE_2(T0);
   FREE_2(T1);
	vector<double> LP;
	Lp.swap(LP);
	//*******************************
 }

//*******************************************************************************************************************
void Mul_LyaML (vector<double> y_0, vector<double> Omega,vector<vector<double> >Couple,vector<double> amp) //Compute Multipy neurons lyapunove exponents
 {
        double h=0.01;int N=10;
        int ML_MUL_NUM_LYA=4;
	cout<<N<<endl<<h<<" ";
        double Detalt=N*h;
        
        Tstep=h;
	cout<<"Now is running Multi_ML_Neuron Lyapunov exponents"<<endl;

        cout   << "The Couple is: "<<endl; 
			for(unsigned int i=0;i<Couple.size();i++)
				{
					for (vector<double>::iterator iter=Couple[i].begin();iter !=Couple[i].end();++iter)
						{
							cout<<*iter<<" ";
						}
							cout<<endl;
				}

        cout   << "The amp is: "<<endl; 
        for (vector<double>::iterator iter=amp.begin();iter !=amp.end();++iter)
	    {
             	 cout<<*iter<<" ";
	    }
        cout<<endl;

	double Tstart=0;//initial time;
	vector<double> mod(ML_MUL_NUM_LYA);	
	// start of computing multiple lya-exponent initial  ******************
	int Dimension;
	Dimension=y_0.size();MUL_VAR_NUM=Dimension; //Dimension==MUL_VAR_NUM
	mul_lya_neu_0.resize(ML_MUL_NUM_LYA);
	mul_lya_perturb_0.resize(ML_MUL_NUM_LYA);
	Lyapunov.resize(ML_MUL_NUM_LYA);
	Lp.resize((ML_MUL_NUM_LYA));
	Af_Evolution_Value_0.resize(ML_MUL_NUM_LYA);
	Difference_Refer_Perturb_Value_0.resize(ML_MUL_NUM_LYA);
	U.resize(ML_MUL_NUM_LYA);
	for(int q=0;q<ML_MUL_NUM_LYA;q++)
	{
		Difference_Refer_Perturb_Value_0[q].resize(Dimension);
		U[q].resize(MUL_VAR_NUM);
	}
	for(int k=0;k<ML_MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_neu_0[k].push_back(y_0[i]);	}

			mul_lya_perturb_0[k].resize(Dimension);
	}
//*********************************************************************
	for(int k=0;k<ML_MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i];
			}
			mul_lya_perturb_0[k][k]=mul_lya_perturb_0[k][k]+SMALL_DISPLACE;
	} //end the initial of computing lya-ex;

	int iter0=1; int sum_time_evolution=1;

	cout<<"the first w= "<< Omega[0]<<endl;
        cout<<"the second w= "<< Omega[1]<<endl;

while(1)
	{
		MSystem_Morris_Lecar_RK4(mul_lya_neu_0[0],Omega,Tstart,N,h,Y0,T0,Couple,amp,MLv0_mdt,MLw0_mdt,Gm0_dt,Mqqm0_dt);
  
		for(int k=0;k<ML_MUL_NUM_LYA;k++) //ML_MUL_NUM_LYA ---column
		{
		       MSystem_Morris_Lecar_RK4(mul_lya_perturb_0[k],Omega,Tstart,N,h,Temp,T1,Couple,amp,MLv0_mdt,MLw0_mdt,Gm0_dt,Mqqm0_dt);
			Af_Evolution_Value_0[k]=Temp.back();
			mul_lya_neu_0[k]=Y0.back();
		}
		for(int k=0;k<ML_MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{
		Difference_Refer_Perturb_Value_0[k][i]=Af_Evolution_Value_0[k][i]-mul_lya_neu_0[k][i];

			}
		}
			V=MGS(Difference_Refer_Perturb_Value_0);
		for(int m=0;m<ML_MUL_NUM_LYA;m++)
			{
				mod[m]=sqrt(scalar_product(V[m],V[m]))*SMALL_DISPLACE;
			
			}
		for(int m=0;m<ML_MUL_NUM_LYA;m++) 
			{
		
			for(int n=0;n<MUL_VAR_NUM;n++)  //MUL_VAR_NUM--rows
					{
					U[m][n]=V[m][n]/mod[m];
			
					}
			}

		Tstart=Tstart+Detalt;


		for(int m=0;m<ML_MUL_NUM_LYA;m++) 
		{
			Lp[m]+=log(mod[m]/SMALL_DISPLACE)/Detalt;

		}
		for(int m=0;m<ML_MUL_NUM_LYA;m++) 
		{
			Lyapunov[m].push_back(Lp[m]/iter0);
		}

		
		if (iter0==300000)// Terminal at 1s time
			break;
		iter0=iter0+1;

		for(int k=0;k<ML_MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i]+SMALL_DISPLACE*U[k][i];
			}
		}

	}//end while

   for(int k=0;k<ML_MUL_NUM_LYA;k++)
   {
	   Lp[k]=Lp[k]/iter0;
           cout<<" This System Classic Layapunov Exponent "<<Lp[k]<<endl;
   }
   
   cout<<endl;
     Lp.push_back(Omega[0]);

	 cout<<"w= "<< Omega[0]<<endl;

   mul_lya_record(Omega);
   	//release memory*****************
   FREE_1(mul_lya_neu_0);
   FREE_1(mul_lya_perturb_0);
   FREE_1(Af_Evolution_Value_0);
   FREE_1(Difference_Refer_Perturb_Value_0);
   FREE_1(Temp);
   FREE_1(Y0);
   FREE_1(V);
   FREE_1(U);
   FREE_2(T0);
   FREE_2(T1);
	vector<double> LP;
	Lp.swap(LP);
	//*******************************
 }

//*******************************************************************************************************************
// Fitzhugh Nagumo Model
void LyaFN (vector<double> y_0, vector<double> Omega) //Compute Fitzhugh Nagumo Model neuron lyapunove exponent
 {
  double h=0.01;int N=10;
	 cout<<N<<endl<<h<<endl;
         cout<<"The Ampl= "<<amp1<<endl;
     double Detalt=N*h;
     Tstep=h;
	 cout<<"Now is running Fitzhugh Nagumo single neuron Lyapunov exponents"<<endl;
	  double Tstart=0;//initial time;
	vector<double> mod(MUL_NUM_LYA);	
	// start of computing multiple lya-exponent initial  ******************
	int Dimension;
	Dimension=y_0.size();MUL_VAR_NUM=Dimension; //Dimension==MUL_VAR_NUM
	mul_lya_neu_0.resize(MUL_NUM_LYA);
	mul_lya_perturb_0.resize(MUL_NUM_LYA);
	Lyapunov.resize(MUL_NUM_LYA);
        Local_LE_Classic.resize(1);
	Lp.resize((MUL_NUM_LYA));
	Af_Evolution_Value_0.resize(MUL_NUM_LYA);
	Difference_Refer_Perturb_Value_0.resize(MUL_NUM_LYA);
	U.resize(MUL_NUM_LYA);

	for(int q=0;q<MUL_NUM_LYA;q++)
	{
		Difference_Refer_Perturb_Value_0[q].resize(Dimension);
		U[q].resize(MUL_VAR_NUM);
	}
	for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_neu_0[k].push_back(y_0[i]);	}

			mul_lya_perturb_0[k].resize(Dimension);
	}
//*********************************************************************
	for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i];
			}
			mul_lya_perturb_0[k][k]=mul_lya_perturb_0[k][k]+SMALL_DISPLACE;
	} //end the initial of computing lya-ex;

	int iter=1; int sum_time_evolution=1;
while(1)
	{           
		System_Fitzhugh_Nagumo_RK4(mul_lya_neu_0[0],Omega,Tstart,N,h,Y0,T0,FNv_dt,FNw_dt,Fqq_dt);

		for(int k=0;k<MUL_NUM_LYA;k++) //MUL_NUM_LYA ---column
		{
			System_Fitzhugh_Nagumo_RK4(mul_lya_perturb_0[k],Omega,Tstart,N,h,Temp,T1,FNv_dt,FNw_dt,Fqq_dt);
			Af_Evolution_Value_0[k]=Temp.back();
			mul_lya_neu_0[k]=Y0.back();
		}
		for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{
		Difference_Refer_Perturb_Value_0[k][i]=Af_Evolution_Value_0[k][i]-mul_lya_neu_0[k][i];

			}
		}
			V=MGS(Difference_Refer_Perturb_Value_0);
//********************************************************************test the MGS results
           /* for(int p=0;p<MUL_NUM_LYA;p++)
				for(int l=p+1;l<=MUL_NUM_LYA;l++)
				{
			{
				cout<<setprecision(16)<<scalar_product(V[p],V[l])<<endl;
			}
				}*/
//****************************************************************************************
		for(int m=0;m<MUL_NUM_LYA;m++)
			{
				mod[m]=sqrt(scalar_product(V[m],V[m]))*SMALL_DISPLACE;
			
			}
		for(int m=0;m<MUL_NUM_LYA;m++) 
			{
		
			for(int n=0;n<MUL_VAR_NUM;n++)  //MUL_VAR_NUM--rows
					{
					U[m][n]=V[m][n]/mod[m];
			
					}
			}

		Tstart=Tstart+Detalt;


		for(int m=0;m<MUL_NUM_LYA;m++) 
		{
			Lp[m]+=log(mod[m]/SMALL_DISPLACE)/Detalt;

		}
                       Local_LE_Classic[0].push_back(log(mod[0]/SMALL_DISPLACE)/Detalt); // get the local lyapunov exponent
                       Local_LE_Classic[0].push_back(Af_Evolution_Value_0[0][0]); // get the voltage
		for(int m=0;m<MUL_NUM_LYA;m++) 
		{
			Lyapunov[m].push_back(Lp[m]/iter);
		}

		
		if (iter==COMP_TIME)// Terminal at 200s time
			break;
		iter=iter+1;

		for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i]+SMALL_DISPLACE*U[k][i];
			}
		}

	}//end while

   for(int k=0;k<MUL_NUM_LYA;k++)
   {
	   Lp[k]=Lp[k]/iter;
           cout<<" This System Classic Layapunov Exponent "<<Lp[k]<<endl;
            
   }
   cout<<endl;

     Lp.push_back(Omega[0]);

   mul_lya_record(Omega);
   	//release memory*****************
   FREE_1(mul_lya_neu_0);
   FREE_1(mul_lya_perturb_0);
   FREE_1(Af_Evolution_Value_0);
   FREE_1(Difference_Refer_Perturb_Value_0);
   FREE_1(Temp);
   FREE_1(Y0);
   FREE_1(V);
   FREE_1(U);
   FREE_2(T0);
   FREE_2(T1);
	vector<double> LP;
	Lp.swap(LP);
	//*******************************
 }


// HH_SCI1995 Model
void LyaHH_SCI(vector<double> y_0, vector<double> Omega,int Flage_sci_flat_white) 
 {
        fftw_plan pl;
	fftw_plan pl1;
	fftw_plan pl2;
        fftw_complex *outl;
        fftw_complex *outl1;
        fftw_complex *outl2;
	fftw_complex  *inl;
	fftw_complex  *inl1;
	fftw_complex  *inl2;
        double h=0.01;
        int N=10;
        int Total_N;
        int Frame;
	cout<<N<<endl<<h<<endl;
        cout<<"The COMP_TIME_SCI is "<<COMP_TIME_SCI<<endl;
        cout<<"The terminal time is "<<COMP_TIME_SCI/10000<<endl;
        cout<<"Now is running Choice_HH_Ori = "<<Choice_HH_Ori<<endl;
        double Detalt=N*h;
        struct array a,lbq,Lbq_WhiteNoise;
        double *Flate_Current;
        double *White_Noise;
        double *Temp_Flate_Current=(double *)malloc((N)*sizeof(double));
        double *Temp_White_Noise=(double *)malloc((N)*sizeof(double));
	double Varance;
        if(Flage_sci_flat_white==1)
        {
        	cout<<"Now is running HH_SCI Flate Current Model single Lyapunov exponents"<<endl;
	}
        else if(Flage_sci_flat_white==2)
        { 
                 cout<<"Now is running HH_SCI White Noise Model single Lyapunov exponents"<<endl;
        }
        else if(Flage_sci_flat_white==3)
        { 
                 cout<<"Now is running HH_SCI White Noise + Sine Model single Lyapunov exponents"<<endl;
        }
        double Tstart=0;//initial time;
	vector<double> mod(HH_MUL_NUM_LYA_SCI);	
	// start of computing multiple lya-exponent initial  ******************
	int Dimension;
	Dimension=y_0.size();MUL_VAR_NUM=Dimension; //Dimension==MUL_VAR_NUM
	mul_lya_neu_0.resize(HH_MUL_NUM_LYA_SCI);
	mul_lya_perturb_0.resize(HH_MUL_NUM_LYA_SCI);
	Lyapunov.resize(HH_MUL_NUM_LYA_SCI);
        Local_LE_Classic.resize(1);
	Lp.resize((HH_MUL_NUM_LYA_SCI+1));
	Af_Evolution_Value_0.resize(HH_MUL_NUM_LYA_SCI);
	Difference_Refer_Perturb_Value_0.resize(HH_MUL_NUM_LYA_SCI);
	U.resize(HH_MUL_NUM_LYA_SCI);

	for(int q=0;q<HH_MUL_NUM_LYA_SCI;q++)
	{
		Difference_Refer_Perturb_Value_0[q].resize(Dimension);
		U[q].resize(MUL_VAR_NUM);
	}

	for(int k=0;k<HH_MUL_NUM_LYA_SCI;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ mul_lya_neu_0[k].push_back(y_0[i]);	}

			mul_lya_perturb_0[k].resize(Dimension);
        	}
//*********************************************************************
	for(int k=0;k<HH_MUL_NUM_LYA_SCI;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i];
			}
			mul_lya_perturb_0[k][k]=mul_lya_perturb_0[k][k]+SMALL_DISPLACE;
	} //end the initial of computing lya-ex;

	
int iter;
int sum_time_evolution;
int sci_i;

Total_N=COMP_TIME_SCI*N;


Local_LE_Classic_Mul_Exp.resize(mul_exp_Final);
for(int sci=0;sci<mul_exp_Final;sci++)
{
  Local_LE_Classic_Mul_Exp[sci].resize(2*COMP_TIME_SCI-1);
}
Lp_Mul_Exp.resize(mul_exp_Final);
//***********************************************************************************
for(int i_i_i=0;i_i_i<mul_exp_Final;i_i_i++)
{ 
Lp_Mul_Exp[i_i_i].resize((HH_MUL_NUM_LYA_SCI));
}

      if(Multi_Experiments==2)
       {
         initial_seed=time(NULL);
         
       }
     else
      {
        initial_seed=20072007;
      }

     sum_time_evolution=1;
     if(Flage_sci_flat_white==1)
     {
        Flate_Current=(double *)malloc((2*Total_N+1)*sizeof(double));
        //N_Length=2*(Total_N-10000);
        //N_Length=2*Total_N;
        //产生Flate Current
        for (sci_i=0;sci_i<(2*Total_N+1);sci_i++)
         {
             Flate_Current[sci_i]=Mean_white;
        }
      }
      else if(Flage_sci_flat_white==2 || Flage_sci_flat_white==3)
      {
        setglobals_whitenoise();
        Frame=2*Total_N-1;
        inl=(fftw_complex *) fftw_malloc(sizeof(fftw_complex )*Frame);
        inl1=(fftw_complex *) fftw_malloc(sizeof(fftw_complex )*(Frame));
        
        outl=(fftw_complex*)fftw_malloc(sizeof(fftw_complex)*(Frame));
        outl1=(fftw_complex*)fftw_malloc(sizeof(fftw_complex)*(Frame));

        White_Noise=(double *)malloc(Total_N*sizeof(double));
        h_white=h;
        // 产生高斯白噪声
        WhilteNoise_fun(Total_N);
        // 高斯噪声通过一个滤波器 f(t)=t*exp(-t/ts)
        pl=fftw_plan_dft_1d(Frame,inl,outl,FFTW_FORWARD,FFTW_ESTIMATE);
        pl1=fftw_plan_dft_1d(Frame,inl1,outl1,FFTW_FORWARD,FFTW_ESTIMATE);

       for(int i=0;i<Total_N;i++)
        {
            inl[i][0]=WhiteNoise[i];
            inl[i][1]=0;
            inl1[i][1]=0;
            //in1[i][0]=h_white*(i*h_white)*exp(-i*h_white/tau);
            inl1[i][0]=h_white*(i*h_white)*exp(-i*h_white/tau); 
        }            
       for(int i=Total_N;i<Frame;i++)
        {
            inl[i][0]=0;
            inl[i][1]=0;
            inl1[i][1]=0;
            //in1[i][0]=h_white*(i*h_white)*exp(-i*h_white/tau);
            inl1[i][0]=0; 
        }  

        fftw_execute(pl); 
        fftw_execute(pl1); 

        inl2=(fftw_complex *) fftw_malloc(sizeof(fftw_complex )*Frame);
        outl2=(fftw_complex*)fftw_malloc(sizeof(fftw_complex)*Frame);
        pl2 = fftw_plan_dft_1d(Frame,outl2,inl2,FFTW_BACKWARD,FFTW_ESTIMATE);

        for(int i=0;i<Frame;i++)
         {
           outl2[i][0]=outl[i][0]*outl1[i][0]-outl[i][1]*outl1[i][1];
           outl2[i][1]=outl[i][0]*outl1[i][1]+outl[i][1]*outl1[i][0];
          }
        fftw_destroy_plan(pl);
        fftw_destroy_plan(pl1);
      
	fftw_free(inl);
        inl=NULL;
        fftw_free(inl1);
        inl1=NULL;
        fftw_free(outl);
        outl=NULL;
        fftw_free(outl1);
        outl1=NULL;
        fftw_execute(pl2); 

        for (sci_i=0;sci_i<Total_N+1;sci_i++)
        {
          White_Noise[sci_i]=inl2[sci_i][0]/(Frame);
        }

        Varance=F_ComputeVar(White_Noise ,Total_N+1);

       for (sci_i=0;sci_i<(Total_N+1);sci_i++)
        {
           White_Noise[sci_i]=Mean_white+(Sigma_white/sqrt(Varance))*White_Noise[sci_i];
        }

       fftw_free(outl2);
       outl2=NULL;
       fftw_free(inl2);
       inl2=NULL;
       fftw_destroy_plan(pl2);
      }


//***********************Multiple Experiments**********************************
for(int mul_ex_1=(mul_exp_Start-1); mul_ex_1<mul_exp_Final;mul_ex_1=(mul_ex_1+1))
{
iter=1; 
while(1)
	{

       if(Multi_Experiments==2)
         {
            initial_seed=time(NULL)+iter;
            cout<<"Lyapunov initial_seed = "<<initial_seed<<endl;
         }
       else
         {
            initial_seed=20072007+iter;
            cout<<"Lyapunov initial_seed = "<<initial_seed<<endl;
          }

        srand(initial_seed);
	for(int ii = 0; ii < 1; ii++ )
	{
		initialseed_neuron_w[ii] = (long) -rand();
        }
        
        WhilteNoise_fun1(N);
//*********************************************************************

if(Flage_sci_flat_white==1)
{
    for (int scii=0;scii<2*N+1;scii++)
   {
     Temp_Flate_Current[scii]=Flate_Current[scii+(iter-1)*2*N];
   }
}
else if(Flage_sci_flat_white==2 || Flage_sci_flat_white==3)
{
   for (int scii=0;scii<N;scii++)
   {
     Temp_White_Noise[scii]=White_Noise[scii+(iter-1)*N];
   }
} 
 
//*********************************************************************

            // Orignial tractory 
if(Flage_sci_flat_white==1)
    {
               HH_Sci_Flate_RK4(mul_lya_neu_0[0],Tstart,N,h,Y0,T0,Temp_Flate_Current,voltage_sci_dt,m_sci_dt,h_sci_dt,n_sci_dt);
    }
else if(Flage_sci_flat_white==2)
    {
               //HH_Sci_White_RK4(y_0,Tstart,N,h,y,T0,Lbq_WhiteNoise,voltage_sci_dt,m_sci_dt,h_sci_dt,n_sci_dt);
                HH_Sci_White_Milstein(mul_lya_neu_0[0],Tstart,N,h,Y0,T0,Temp_White_Noise,voltage_sci_dt,m_sci_dt,h_sci_dt,n_sci_dt);
    }
else if(Flage_sci_flat_white==3)
    {
                 HH_Sci_White_Sine_Milstein(mul_lya_neu_0[0],Tstart,N,h,Y0,T0,Temp_White_Noise,voltage_sci_1_dt,m_sci_dt,h_sci_dt,n_sci_dt);
    }
             //Pertube tractory
		for(int k=0;k<HH_MUL_NUM_LYA_SCI;k++) //HH_MUL_NUM_LYA_SCI ---column
		{
                       if(Flage_sci_flat_white==1)
                        {
              		 HH_Sci_Flate_RK4(mul_lya_perturb_0[k],Tstart,N,h,Temp,T1,Temp_Flate_Current,voltage_sci_dt,m_sci_dt,h_sci_dt,n_sci_dt);
                        }
		        else if(Flage_sci_flat_white==2)
   		        {
                         HH_Sci_White_Milstein(mul_lya_perturb_0[k],Tstart,N,h,Temp,T1,Temp_White_Noise,voltage_sci_dt,m_sci_dt,h_sci_dt,n_sci_dt);
                        }
		        else if(Flage_sci_flat_white==3)
   		        {
                         HH_Sci_White_Sine_Milstein(mul_lya_perturb_0[k],Tstart,N,h,Temp,T1,Temp_White_Noise,voltage_sci_1_dt,m_sci_dt,h_sci_dt,n_sci_dt);
                        }

			Af_Evolution_Value_0[k]=Temp.back();
			mul_lya_neu_0[k]=Y0.back();
		}
		for(int k=0;k<HH_MUL_NUM_LYA_SCI;k++)
		{
			for (int i=0;i<Dimension;i++)
			{
		Difference_Refer_Perturb_Value_0[k][i]=Af_Evolution_Value_0[k][i]-mul_lya_neu_0[k][i];

			}
		}
			V=MGS(Difference_Refer_Perturb_Value_0);
//********************************************************************test the MGS results
           /* for(int p=0;p<HH_MUL_NUM_LYA_SCI;p++)
				for(int l=p+1;l<=HH_MUL_NUM_LYA_SCI;l++)
				{
			{
				cout<<setprecision(16)<<scalar_product(V[p],V[l])<<endl;
			}
				}*/
//****************************************************************************************
		for(int m=0;m<HH_MUL_NUM_LYA_SCI;m++)
			{
				mod[m]=sqrt(scalar_product(V[m],V[m]))*SMALL_DISPLACE;
			
			}
		for(int m=0;m<HH_MUL_NUM_LYA_SCI;m++) 
			{
		
			for(int n=0;n<MUL_VAR_NUM;n++)  //MUL_VAR_NUM--rows
					{
					U[m][n]=V[m][n]/mod[m];
			
					}
			}

		Tstart=Tstart+Detalt;

		for(int m=0;m<HH_MUL_NUM_LYA_SCI;m++) 
		{
			//Lp[m]+=log(mod[m]/SMALL_DISPLACE)/Detalt;
                     Lp_Mul_Exp[mul_ex_1][m]+=log(mod[m]/SMALL_DISPLACE)/Detalt;

		}



                       Local_LE_Classic_Mul_Exp[mul_ex_1][2*(iter-1)]=(log(mod[0]/SMALL_DISPLACE)/Detalt);
                       Local_LE_Classic_Mul_Exp[mul_ex_1][2*(iter-1)+1]=(mul_lya_neu_0[0][0]); 

                    // Local_LE_Classic[0].push_back(Af_Evolution_Value_0[0][0]); // get the voltage (以前所得到数据使用的，所得结论可能有错误)
	   if(mul_ex_1==(mul_exp_Final-1))
	       {
                  for(int m=0;m<HH_MUL_NUM_LYA_SCI;m++) 
		    {
			//Lyapunov[m].push_back(Lp[m]/iter);
                          Lyapunov[m].push_back(Lp_Mul_Exp[mul_ex_1][m]/iter);
		    }
               }

		if (iter==COMP_TIME_SCI)// Terminal at 3s time
			{
                           
                             break;
                         }
		iter=iter+1;

		for(int k=0;k<HH_MUL_NUM_LYA_SCI;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i]+SMALL_DISPLACE*U[k][i];
			}
		}
        free(WhiteNoise_1); 
        WhiteNoise_1=NULL;
	}//end while

   for(int k=0;k<HH_MUL_NUM_LYA_SCI;k++)
   {
	   //Lp[k]=Lp[k]/iter;
           Lp_Mul_Exp[mul_ex_1][k]=Lp_Mul_Exp[mul_ex_1][k]/iter;
           //cout<<" This System Classic Layapunov Exponent "<<Lp[k]<<endl;
            
   }
   cout<<endl;
   Lp_Mul_Exp[mul_ex_1].push_back(Omega[0]);
   cout<<"Omega = "<<Omega[0];
   cout<<endl;
   Save_Local_Global_LE(Omega,mul_ex_1);
}
//*********************End Multiple Experiments***************************************

//************************************************************************************
 double temp_local_le;
 double temp_global_le;
 for(int local_i=0;local_i<Local_LE_Classic_Mul_Exp[0].size();local_i++)
 {
          temp_local_le=0;
      for(int mul_ex_1=(mul_exp_Start-1); mul_ex_1<mul_exp_Final;mul_ex_1=(mul_ex_1+1))
         {
           temp_local_le+=Local_LE_Classic_Mul_Exp[mul_ex_1][local_i];
      
         }  
        Local_LE_Classic[0].push_back(temp_local_le/mul_exp_Final); // get the local lyapunov exponent
  }

  for(int local_i=0;local_i<Lp_Mul_Exp[0].size();local_i++)
  {
      temp_global_le=0;
      for(int mul_ex_1=(mul_exp_Start-1); mul_ex_1<mul_exp_Final;mul_ex_1=(mul_ex_1+1))
         {
          temp_global_le+=Lp_Mul_Exp[mul_ex_1][local_i];
         }
      Lp[local_i]=(temp_global_le/mul_exp_Final);
  }

   for(int k=0;k<HH_MUL_NUM_LYA_SCI;k++)
   {
     cout<<" This System Classic Layapunov Exponent "<<Lp[k]<<endl;
   }
//***********************************************************************************

   mul_lya_record(Omega);
   //release memory*****************
   FREE_1(mul_lya_neu_0);
   FREE_1(mul_lya_perturb_0);
   FREE_1(Af_Evolution_Value_0);
   FREE_1(Difference_Refer_Perturb_Value_0);
   FREE_1(Temp);
   FREE_1(Y0);
   FREE_1(V);
   FREE_1(U);
   FREE_1(Local_LE_Classic);
   FREE_1(Lyapunov);
   FREE_2(T0);
   FREE_2(T1);
   FREE_1(Local_LE_Classic_Mul_Exp);
   FREE_1(Lp_Mul_Exp);
   FREE_2(Lp);

if(Flage_sci_flat_white==2)
{
 free(Temp_White_Noise);
 //free(WhiteNoise);
 free(White_Noise);
}
  else
{
 free(Temp_Flate_Current);
 }
   //*******************************
 }

vector<vector<double> > MGS(vector<vector<double> > mul_lya_perturb)  // use the stable Gram-Schmidt algorithm
 {  
	 //[m,k]=size(V); matlab
	 vector<vector<double> > Temp_lya_perturb;
	 int M;
	 M=mul_lya_perturb.size();
	 int K;
	 K=mul_lya_perturb[0].size();
	 Temp_lya_perturb.resize(M);

	 // orthonormalize the perturbation by Gram-Schmidt algorithm! ***********************
/*	
	for (int n=0; n<M; n++)
	{		
		for (int j=0; j<n; j++)
		{
		    double dot_value = scalar_product(mul_lya_perturb[n],mul_lya_perturb[j])*pow(SMALL_DISPLACE,2);
		    double dot_norm = scalar_product(mul_lya_perturb[j],mul_lya_perturb[j])*pow(SMALL_DISPLACE,2);
			for (int i=0; i<K; i++)
			{
				mul_lya_perturb[n][i]-=mul_lya_perturb[j][i]*(dot_value/dot_norm);
			}
		}
		                Temp_lya_perturb[n]=mul_lya_perturb[n];
	}
*/	

	for (int n=0; n<M; n++)
	{		
		/*
                 double dot_value_0 = scalar_product(mul_lya_perturb[n],mul_lya_perturb[n])*pow(SMALL_DISPLACE,2);

                  for (int i_i=0; i_i<K; i_i++)
			{
				mul_lya_perturb[n][i_i]=mul_lya_perturb[n][i_i]/sqrt(dot_value_0);
			}
                */
		for (int j=n+1; j<M; j++)
		{
		    double dot_value = scalar_product(mul_lya_perturb[n],mul_lya_perturb[j])*pow(SMALL_DISPLACE,2);
		    double dot_norm = scalar_product(mul_lya_perturb[n],mul_lya_perturb[n])*pow(SMALL_DISPLACE,2);
			for (int i=0; i<K; i++)
			{
				mul_lya_perturb[j][i]-=mul_lya_perturb[n][i]*(dot_value/dot_norm);
			}
		}
		                Temp_lya_perturb[n]=mul_lya_perturb[n];
	}

	// end of orthonormalizing the perturbation by Gram-Schmidt algorithm! **************
	return Temp_lya_perturb;
 }



 void mul_lya_record(vector<double> Omega)
{   
	int n;
	int name1 = 1;
	double name=3*Omega[0];
        double name_sci=Omega[0];
	char *str_eig=(char *)malloc(256*sizeof(char));
	if (str_eig == NULL)
	{
		cout<<"can not allocate space!"<<endl;
		getchar();
	}

		ofstream eig_write;

#if RK4M
		sprintf(str_eig,"Runge_Kutta4M/LE_%d_%d.txt",name1, (int)COMP_TIME);
#endif

#if RK4
		sprintf(str_eig,"Runge_Kutta4/LE_%d_%d.txt",  name1, (int)COMP_TIME);
#endif

		eig_write.open(str_eig, ios::app);

//	getchar();
		if ( eig_write.fail() )
		{
			cout<<"Error: open Lyapunov Exponent file error!"<<endl;
			getchar();
			return;
		}

		for (vector<double>::iterator iter=Lp.begin();iter !=Lp.end();++iter)
					{
						eig_write<<*iter<<" ";
	
					}
      eig_write << endl;


		eig_write.close();
		eig_write.clear();

//*****************************************************************************************

// Record the local LE
if(save_LLE_classic==1)
{
int record_hh_Local_LE;
record_hh_Local_LE=1;
if(record_hh_Local_LE==1)
{
for (n=0; n<1; n++)
	{
		ofstream Local_LE_write;
if(choose_Sine_Poisson_SciF_SciW==4)
{
#if RK4M
		sprintf(str_eig,"Runge_Kutta4M/Local_LE_%d_%f_%d.txt", n, name_sci, (int)COMP_TIME_SCI);
#endif

#if RK4
		sprintf(str_eig,"Runge_Kutta4/Local_LE_%d_%f_%d.txt", n, name_sci, (int)COMP_TIME_SCI);
#endif



}
else 
{
#if RK4M
		sprintf(str_eig,"Runge_Kutta4M/Local_LE_%d_%f_%d.txt", n, name, (int)COMP_TIME);
#endif

#if RK4
		sprintf(str_eig,"Runge_Kutta4/Local_LE_%d_%f_%d.txt", n, name, (int)COMP_TIME);
#endif
}
		Local_LE_write.open(str_eig,ios::binary | ios::out);
//	getchar();
		if ( Local_LE_write.fail() )
		{
			cout<<"Error: open Local Lyapunov Exponent file error!"<<endl;
			getchar();
			return;
		}

		for (unsigned int j=0; j< Local_LE_Classic[0].size(); j++)
			{
				Local_LE_write<<Local_LE_Classic[n][j]<<" ";
			}
				Local_LE_write<<endl;
		Local_LE_write.close();
		Local_LE_write.clear();	
	}
}
}
//******************************************************************************************
// record the lyapunov exponent at different time to see if it converges or not!
#if MUL_LYAPUNOV_EVOLUTION // start of recording multiple lyapunov exponent!
LE_Convergence=1;
if (LE_Convergence==1)
{
cout<<" Save The LE Convergence "<<endl;
	
		// for (n=0; n<MUL_NUM_LYA; n++)
	       for (n=0; n<1; n++)
	      {
		ofstream eig_evolve_write;

#if RK4M
		sprintf(str_eig,"Runge_Kutta4M/eigevolve_convergence_%d_%f_%d.txt", n, name, (int)COMP_TIME);
#endif

#if RK4
		sprintf(str_eig,"Runge_Kutta4/eigevolve_convergence_%d_%f_%d.txt", n, name, (int)COMP_TIME);
#endif
		eig_evolve_write.open(str_eig,ios::binary | ios::out);
//	getchar();
		if ( eig_evolve_write.fail() )
		{
			cout<<"Error: open eigvalue file error!"<<endl;
			getchar();
			return;
		}

		for (unsigned int j=0; j< Lyapunov[n].size(); j++)
			{
				eig_evolve_write<<Lyapunov[n][j]<<" ";
			}
				eig_evolve_write<<endl;
		eig_evolve_write.close();
		eig_evolve_write.clear();	
	     }		
  
}
#endif // end of recording evoltion of lyapunov exponent
	free(str_eig);
	//release memory*****************
	vector<vector<double> > Lya_Temp;
	Lyapunov.swap(Lya_Temp);
	//*******************************
}
double scalar_product(const vector<double>& a,const vector<double>& b)   
{  
    double scalar=0;  
    if(a.size()!=b.size())   
        return false;   
    for(unsigned int i=0;i<a.size();i++)   
        scalar+=(a[i]/(SMALL_DISPLACE))*(b[i]/(SMALL_DISPLACE));   
    return scalar;   
}  
void FREE_1(vector<vector<double> > &Initial_1)
{
	vector<vector<double> > SWAP_1;
        Initial_1.swap(SWAP_1);

}
void FREE_2(vector<double> &Initial_2)
{

	vector<double> SWAP_2;
	Initial_2.swap(SWAP_2);
}

void FREE_3(vector<string> &Initial_3)
{
	vector<string>  SWAP_3;
	Initial_3.swap(SWAP_3);
}
//***********************************************************************************
void Save_Local_Global_LE(vector<double> Omega,int multiples)
{   
	int n;
        double name_sci=Omega[0];
	char *str_eig=(char *)malloc(256*sizeof(char));
//****************************Record the Global LE of Multiple trials***********************************
	if (str_eig == NULL)
	{
		cout<<"can not allocate space!"<<endl;
		getchar();
	}

		ofstream eig_write;

#if RK4M
		sprintf(str_eig,"Runge_Kutta4M/Lp_Mul_Exp_%d_%d_%d.txt",name_sci,multiples,(int)COMP_TIME_SCI);
#endif

#if RK4
		sprintf(str_eig,"Runge_Kutta4/Lp_Mul_Exp_%d_%d_%d.txt",name_sci,multiples,(int)COMP_TIME_SCI);
#endif

		eig_write.open(str_eig, ios::app);

		if ( eig_write.fail() )
		{
			cout<<"Error: open Lyapunov Exponent file error!"<<endl;
			getchar();
			return;
		}

		for (vector<double>::iterator iter=Lp_Mul_Exp[multiples].begin();iter !=Lp_Mul_Exp[multiples].end();++iter)
					{
						eig_write<<*iter<<" ";
	
					}
                eig_write << endl;


		eig_write.close();
		eig_write.clear();

//******************************Record the Local LE of Multiple Trials***************************************
if(save_LLE_classic==1)
{
//Local_LE_Classic_Mul_Exp;
int record_hh_Local_LE;
record_hh_Local_LE=1;
if(record_hh_Local_LE==1)
{
for (n=0; n<1; n++)
	{
		ofstream Local_LE_write;
#if RK4M
		sprintf(str_eig,"Runge_Kutta4M/Local_LE_Multiple_%d_%f_%d.txt", multiples, name_sci, (int)COMP_TIME);
#endif

#if RK4
		sprintf(str_eig,"Runge_Kutta4/Local_LE_Multiple_%d_%f_%d.txt", multiples, name_sci, (int)COMP_TIME);
#endif


		Local_LE_write.open(str_eig,ios::binary | ios::out);
//	getchar();
		if ( Local_LE_write.fail() )
		{
			cout<<"Error: open Local Lyapunov Exponent file error!"<<endl;
			getchar();
			return;
		}

		for (unsigned int j=0; j< Local_LE_Classic_Mul_Exp[0].size(); j++)
			{
				Local_LE_write<<Local_LE_Classic_Mul_Exp[multiples][j]<<" ";
			}
				Local_LE_write<<endl;
		Local_LE_write.close();
		Local_LE_write.clear();	
	}
}
}
//******************************************************************************************
	free(str_eig);
}
