#ifndef _LOOP_H_
#define _LOOP_H_

// this is just vector_v structure
struct vector_v 
{
	int vect_size;  // the length of vector

	int vect_index; // the next position to save data in the vector

	double *vect_value;  // data value
};

// this is also a vector structure but with loop structure, meaning that if the
// structure is full, the next new data will be saved to the first postion in the 
// vector and overwrite the original data
struct loop 
{
	int loop_index; // the next position to write new data

	vector_v loop_vect;
};

// initial setup for vector_v 
void vector_initialize(vector_v &a);

// set data value in the vector_v
void vector_set_value(vector_v &a, int dim, double v);

// allocate space for the vector_v
void vector_allocate(vector_v &a, int dim);

// re-allocate space for the vector, this normally corresponds to the case 
// that the structure is full
void vector_reallocate(vector_v &a);

// insert one data into the vector_v
void vector_insert(vector_v &a, double v);

// destroy the vector
void vector_destroy(vector_v &a); 

// copy data value from another vector_v
void vector_copy(vector_v &des, const vector_v &src);

// compute the sum of data in the vector_v
double vector_sum(vector_v &a);

// print out the data in the vector
void vector_output(vector_v &a);

// initial setup for loop
void loop_initialize(loop &a);

// allocate space for the vector
void loop_allocate(loop &a, int dim);

// insert one data into the loop
void loop_insert(loop &a, double data);

// compute the sum of data in the loop
double loop_sum(loop &a);

// destroy the loop
void loop_destroy(loop &a);

// print out the data in the loop
void loop_output(loop &a);

#endif
