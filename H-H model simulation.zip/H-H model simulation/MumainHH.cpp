#include <cstdlib>
#include <vector>
#include <iostream>
#include<fstream>
#include <string>
#include <iomanip>
#include<cmath>
#include <time.h>
#include<sstream>
#include"HHconst.h"
#include"THHfunciton.h"
#include"Lya_input.h"
using namespace std;
void save_f(vector<double>DATA,string fname);
vector<vector<double> > ISIJin(int N, vector<double> y_0, vector<double> Omega,vector<vector<double> >Couple,vector<double> amp);
void save(vector<vector<double> > DATA,string fname);
string   double_to_str(double x) ;
void MumainHH(int argc, char** argv){
	double OmegaStart;
	double OmegaFinal;
	double duration;
	clock_t start,finish;
	vector<vector<double> >ISIout;
	vector<double>Lomega;
	vector<string>fname;
	double yy_0[]={0,0.052932485257250,0.596120753508460, 0.317676914060697,0,0,0,0,0.052932485257250,0.596120753508460, 0.317676914060697,0,0,0};
	vector<double>y_0;
	printf("please input the initial value = OmegaStart    ");
	cin>>OmegaStart;
	printf("please input the initial value = OmegaFinal    ");
	cin>>OmegaFinal;
	int Dimension=sizeof(yy_0)/sizeof(yy_0[0]);
	for (int i=0;i<Dimension;i++)
	{
		y_0.push_back(yy_0[i]);
	}
	//***************************************************************** Couple
			ifstream   infile( "Couple.txt " ); 
		if   (   !   infile   ) 
		{ 
			cerr   << "can 't   open   Couple.txt"; 
			exit(   -1   ); 
		} 
			vector<vector<double> >  Couple;
			vector<double>temp;
			string line;
			istringstream istr;
			double data;
			while(getline(infile,line))
			{
				istr.str(line);
				while(istr>>data)
			{
				temp.push_back(data);
			}
				Couple.push_back(temp);
				temp.clear();
				istr.clear();

			}
				infile.close();

			for(unsigned int i=0;i<Couple.size();i++)
				{
					for (vector<double>::iterator iter=Couple[i].begin();iter !=Couple[i].end();++iter)
						{
							cout<<*iter<<" ";
						}
							cout<<endl;
				}

//****************************************************************************************** amp
			ifstream   ampfile( "amp.txt " ); 
			if   (   !   ampfile   ) 
			{ 
				cerr   << "can 't   open   amp.txt"; 
				exit(   -1   ); 
			} 
				vector<double>amp;
				string line_amp;
				istringstream iamp;
				while(getline(ampfile,line_amp))
			{
				iamp.str(line_amp);
				while(iamp>>data)
			{
				amp.push_back(data);
			}
				iamp.clear();

			}
				ampfile.close();
	//*******************************************************************************************
	#if Convergence_Test
	double Omega2,Omega1;
	printf("please input the initial value = Omega1    ");
	cin>>Omega1;
	printf("please input the initial value = Omega2    ");
	cin>>Omega2;
		Lomega.push_back(Omega1);
		Lomega.push_back(Omega2);
	    start=clock();
	    ISIout=ISIJin(1000000,y_0,Lomega,Couple,amp);//10s time evolution
		finish=clock();
		duration=(double)(finish-start)/CLOCKS_PER_SEC;
		printf("%f seconds\n", duration);
    #else
	double Steph,Steph_1,Steph_2;
	int N;
	int ii;
	int range;//1--��ʾ��0��1����0--��ʾ����
	printf("please input the range =     ");
	cin>>range;
	if (range==1)
	{Steph=0.001/3;
	Steph_2=0.001/3;}//range[0,1],use step
     else 
	 {Steph=0.00001/3;
	Steph_2=0.00001/3;}//other range,use step

	cout<<Steph<<"   "<<Steph_2<<endl;

	OmegaStart=OmegaStart*f0;
	OmegaFinal=OmegaFinal*f0;
	string f_name;
	N=(int)((OmegaFinal-OmegaStart)/Steph+0.5);
	cout<<N<<endl;
	//***** This part is the convergence test
	
	if (Same_f==1)  // the two neuron has the same omega
	{
		
//*******************************
	vector<double>f;
	vector <vector <vector <double>   >   > ISI;
		ISI.resize(NumNeuron);
	for (int k=0;k<NumNeuron;k++)
	{ISI[k].resize(N+1);}
//*******************************
			for(int k=0;k<NumNeuron;k++)
	    {fname.push_back("ISI"+double_to_str(k)+"("+double_to_str(3*OmegaStart)+"-"+double_to_str(3*OmegaFinal)+")");}//ISI(0.34600-0.34602)}
	 	 f_name="ISI("+double_to_str(3*OmegaStart)+"-"+double_to_str(3*OmegaFinal)+")f";
			ii=0;
		 for (double Omega_1=OmegaStart;Omega_1<=OmegaFinal;Omega_1=(Omega_1+Steph))
						{ 
							cout<<"Two Neuron the same omega "<<endl;
								f.push_back(3*Omega_1);
									for (int k=0;k<NumNeuron;k++)
									   {Lomega.push_back(Omega_1);}
		
										   cout<<Omega_1*3<<endl;

												start=clock();
									ISIout=ISIJin(1000000,y_0,Lomega,Couple,amp);//10s time evolution
        
								 for (int k=0;k<NumNeuron;k++)
										 {
												  ISI[k][ii].resize(ISIout[k].size());
												  ISI[k][ii]=ISIout[k];
		
											}
								 //********************* release the capacity of the ISIout
									 FREE_1(ISIout);
								 //************************
										 // ISI[i].assign(ISIout.begin(),ISIout.end()); 
													  ii++;
												  finish=clock();
									  duration=(double)(finish-start)/CLOCKS_PER_SEC;
											  printf("%f seconds\n", duration);
													 //free the vector
											   for (int k=0;k<NumNeuron;k++)
													{Lomega.pop_back();}
							}
//********** save the ISI and f		
		for (int k=0;k<NumNeuron;k++)
		 {
			save(ISI[k],fname[k]);
		 }
			 save_f(f,f_name);
//******************************

//release memory*****************
	vector <vector <vector <double>   >   > ISI_temp;
	vector<double>f_temp;
	ISI.swap(ISI_temp);
	f.swap(f_temp);
//*******************************
	}
//********************************************************************** end the two neuron has the same omega
	else  // the two neuron has the different omega
		double Steph_1=0.001/3;
	for (double Omega_1=OmegaStart;Omega_1<OmegaFinal;Omega_1=(Omega_1+Steph_1))
	{ 
		cout<<"Two Neuron has the different omega"<<endl;
//*******************************
	vector<double>f;
	vector <vector <vector <double>   >   > ISI;
		ISI.resize(NumNeuron);
	for (int k=0;k<NumNeuron;k++)
	{ISI[k].resize(N+1);}
//*******************************
		ii=0;
			for(int k=0;k<NumNeuron;k++)
		{
		fname.push_back("ISI"+double_to_str(k)+"("+double_to_str(3*OmegaStart)+"-"+double_to_str(3*OmegaFinal)+")"+double_to_str(Omega_1));
		}//ISI(0.34600-0.34602)}

		f_name="ISI("+double_to_str(3*OmegaStart)+"-"+double_to_str(3*OmegaFinal)+")f"+double_to_str(Omega_1);
		for (double Omega_2=OmegaStart;Omega_2<OmegaFinal;Omega_2=(Omega_2+Steph_2))
		{
			f.push_back(3*Omega_2);
		
		
			Lomega.push_back(Omega_1);
			Lomega.push_back(Omega_2);
		
		cout<<setprecision(16)<<Omega_1<<"  "<<setprecision(16)<<Omega_2<<endl;

		start=clock();
	   ISIout=ISIJin(1000000,y_0,Lomega,Couple,amp);//10s time evolution
        
	   for (int k=0;k<NumNeuron;k++)
		 {
		   ISI[k][ii].resize(ISIout[k].size());
		   ISI[k][ii]=ISIout[k];
	   	 }
	  // ISI[i].assign(ISIout.begin(),ISIout.end()); 
	   ii++;
	   finish=clock();
	   duration=(double)(finish-start)/CLOCKS_PER_SEC;
	   printf("%f seconds\n", duration);
	 //free the vector
	   for (int k=0;k<NumNeuron;k++)
			 {Lomega.pop_back();}
	   //********************* release the capacity of the ISIout
			 FREE_1(ISIout);
		 //************************
		}
//********** save the ISI and f		
		for (int k=0;k<NumNeuron;k++)
		 {
			save(ISI[k],fname[k]);
		 }
			 save_f(f,f_name);
//******************************
	for (int k=0;k<NumNeuron;k++)
	{fname.pop_back();}
//release memory*****************
	vector <vector <vector <double>   >   > ISI_temp;
	vector<double>f_temp;
	ISI.swap(ISI_temp);
	f.swap(f_temp);
//*******************************
	}
//********************************************************************** end the two neuron has the different omega
//system("pause");
#endif
	  return;}




