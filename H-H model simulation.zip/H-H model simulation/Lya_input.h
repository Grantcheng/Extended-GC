#ifndef _Lya_input_H_
#define _Lya_input_H_

#include <iostream>
#include <vector>
#include <string>
using namespace std;
// compute the inner product

double scalar_product(const vector<double>& a,const vector<double>& b);   
vector<vector<double> > MGS(vector<vector<double> > mul_lya_perturb);  // use the stable Gram-Schmidt algorithm
void Lya (vector<double> y_0, vector<double> Omega);
void Mul_Lya (vector<double> y_0, vector<double> Omega,vector<vector<double> >Couple,vector<double> amp); //Compute Multipy neurons lyapunove exponents
void Mul_Lya_Q (vector<double> y_0, vector<double> Omega,vector<vector<double> >Couple,vector<double> amp,vector<int> neuron_type_list);
void mul_lya_record(vector<double> Omega);
void FREE_1(vector<vector<double> > &Initial_1);
void FREE_2(vector<double> &Initial_2);
bool complare(double a,double b);

#endif //_Lya_input_H_