#include<iostream>
#include<cmath>
#include<iomanip>
#include<fstream>
#include <stdio.h>
#include <stdlib.h>
#include <sstream>
#include<vector>
#include "HHconst.h"
#include"SHHfunction.h"
#include"THHfunciton.h"
#include "convergence.h"
#include "RK4.h"
#include "Lya_input.h"
using namespace std;
void save_solution(vector<double> DATA,string fname);
string   double_to_str(double x) ;
double OmegaStart;
double OmegaFinal;
vector<vector<double> > ISIJin(int N, vector<double> y_0, vector<double> Omega,vector<vector<double> >Couple,vector<double> amp){
double Tstart=0;
double h=0.01;
int solution_num=5;
//double h_0=pow(0.5,(14));// convergence test ,the time evolution,RK4 step
double h_0=(double)1/4096;
vector<double> SpikeTime;
vector<vector<double> > HH_solution;
vector<double> Compare_Th;
vector<double> T0;
vector<vector<double> > y;
vector<string> sloution_name;
double Time=1024;//convergence test ,the time evolution
double N_0;//convergence test ,the time evolution
N_0=Time/h_0;//convergence test ,the time evolution

#if NumNeuron1
vector<double> ISI0;
vector<vector<double> > ISI;

#if Convergence_Test_0  //Test convergence of the single neuron program
double T0_convergence;
vector<double> y_convergence;
Convergence_1(y_0,Omega,Tstart,N_0,h_0,y_convergence,T0_convergence,Time);
return ISI;
#else

#if Runmain_each_solution_range
for (int a=0;a<solution_num;a++)
{sloution_name.push_back("HH_Solution("+double_to_str(3*OmegaStart)+"-"+double_to_str(3*OmegaFinal)+")w1_"+double_to_str(a)+"_"+double_to_str(Omega[0]));}
#else
for (int a=0;a<solution_num;a++)
{sloution_name.push_back("HH_Solution_w1_"+double_to_str(3*Omega[0])+"_"+double_to_str(a));}
#endif

Runge_Kutta4(y_0,Omega,Tstart,N,h,y,T0,voltage_dt,m_dt,h_dt,n_dt,q_dt);

HH_solution.resize(solution_num);
for (int Num=0;Num<solution_num;Num++)
{
HH_solution[Num].resize(T0.size());
}

SpikeTime.resize(T0.size());
ISI.resize(1);
int i=0;
for (int k=0;k<T0.size();k++)
{
	SpikeTime[k]=y[k][0]-Threshold;
	for (int s_num=0;s_num<solution_num;s_num++)
		{
			
			HH_solution[s_num][k]=y[k][s_num];
	
	    }
}
// save each solution of the HH system equation
#if Runmain_each_solution
for (int s_num=0;s_num<solution_num;s_num++)
{save_solution(HH_solution[s_num],sloution_name[s_num]);}
#endif

while (!sloution_name.empty())
				{
					sloution_name.pop_back();
				}
				
for (int j=1;j<SpikeTime.size();j++)
{
	if (SpikeTime[j]>=0 && SpikeTime[j-1]<0)
	{
		ISI0.push_back(T0[j]);
		i++;
	}
}

for(int z=0; z<i;z++){
	if(z==0)
	{
		ISI[0].push_back(ISI0[z]);
	}
	else{
	ISI[0].push_back(ISI0[z]-ISI0[z-1]);
};}
return ISI;
#endif

#else
//-------------------------------
for(unsigned int i=0;i<Couple.size();i++)
{
for (vector<double>::iterator iter=Couple[i].begin();iter !=Couple[i].end();++iter)
{
	cout<<*iter<<" ";
}
cout<<endl;
}
//-------------------------------
#if Convergence_Test  //Test convergence of the multipe neurons program

double T0_convergence;
vector<double> y_convergence;
vector<vector<double> > ISI;
Convergence_2(y_0,Omega,Tstart,N_0,h_0,y_convergence,T0_convergence,Couple,amp,Time);
return ISI;
//
#else
for(int k=0;k<NumNeuron;k++)
{sloution_name.push_back("HH_Solution_w1_"+double_to_str(3*Omega[0])+"_w2_"+double_to_str(3*Omega[1])+"_"+double_to_str(k));}

Runge_Kutta4M(y_0,Omega,Tstart,N,h,y,T0,Couple,amp,voltagei_1_dt,mi_1_dt,hi_1_dt,ni_1_dt,Gi_1_dt,G1i_1_dt,qi_1_dt);

vector<vector<double> > SpikeTime1;
vector<vector<double> > Double_HH_Solution;
vector<vector<double> >  ISI1;
vector<vector<double> >  ISIout;
int array[NumNeuron];
Double_HH_Solution.resize(NumNeuron);
SpikeTime1.resize(NumNeuron);
ISI1.resize(NumNeuron);
ISIout.resize(NumNeuron);
for (int Num=0;Num<NumNeuron;Num++)
{
SpikeTime1[Num].resize(T0.size());
Double_HH_Solution[Num].resize(T0.size());
}

for (int Num=0;Num<NumNeuron;Num++)
{
for (unsigned int k=0;k< T0.size();k++)
{
	SpikeTime1[Num][k]=y[k][Num*7]-Threshold;
	Double_HH_Solution[Num][k]=y[k][Num*7];

}
}
//********** save HH solution	
for (int k=0;k<NumNeuron;k++)
		 {
			save_solution(Double_HH_Solution[k],sloution_name[k]);
			}
//****************************release the solution_name
				while (!sloution_name.empty())
				{
					sloution_name.pop_back();
				}
				//***********************************************************
for (int Num=0;Num<NumNeuron;Num++)
{ int i=0;
for (unsigned int j=1;j<SpikeTime1[Num].size();j++)
{
	
	if (SpikeTime1[Num][j]>=0 && SpikeTime1[Num][j-1]<0)
	{
		ISI1[Num].push_back(T0[j]);
		i++;
	}
	
}
array[Num]=i;
}

for (int Num=0;Num<NumNeuron;Num++)
{ int length=0;
	if (array[Num]!=0)
	{  length=sizeof(array[Num]);
		for(int z=0; z<array[Num];z++){
			if(z==0)
					{
							ISIout[Num].push_back(ISI1[Num][z]);
					}
			else
					{
							ISIout[Num].push_back(ISI1[Num][z]-ISI1[Num][z-1]);
					}
										}
	}
	else
	{ISIout[Num].resize(length);}
}

//************************* release the capacity
FREE_1(y);
FREE_1(SpikeTime1);
FREE_2(T0);
FREE_2(SpikeTime);
//***************************

return ISIout;
#endif
#endif

T0.clear();
}

