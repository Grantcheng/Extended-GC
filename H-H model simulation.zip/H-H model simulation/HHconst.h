#ifndef _HHconst_h_
#define _HHconst_h_
#include <cstdlib>
#include <vector>
#include <string>
#include <iostream>
#include<cmath>
#include<fstream>

using namespace std;

#define CM 1
#define amp1 10
#define e_na 50
#define e_k (-77)
#define e_l (-54.387)
#define e_vr (-65)
#define g_na_max 120
#define g_k_max 36
#define g_l 0.3
#define pi 3.141592653589793
#define Threshold 60
#define f0 1/3
#define Convergence_Test 0//if =1 convergence elseif =0 formal run
#define Convergence_Test_0 0
#define NumNeuron1 0 //0 ����Runge_Kutta4M����,1 ����Runge_Kutta4����
#define Runmainhh 0  // run one neuron HH system equation
#define Runmain_each_solution 1 // it is use to obtain each solution of system equation
#define Runmain_each_solution_range 0// index that the results is only one omega or a range of omega: 0 is one omega, 1 is range of omega
#define RunMumainHH 1 //double neuron program
#define RunMumainHH_2 0 //three neuron program
#define RunMumainHH_M 0 //Multi neuron program
#define Same_f 0 //if Same_f==0 is run the same omega; if Same_f==1 is run the different omega;
/* Follows is Compute Lyap exponents */
#define Lya_Computing_Start 1
#define Lya_Computing_Start_2 0//1 is the two neurons Lya
#define Lya_Computing_Start_3 0//1 is the three neurons Lya
#define Lya_Computing_Start_M 0//1 is the neuron neurons Lya
#define TypeNeuron 0 // 1 is the neuron have two types(excitatory and inhibitory), 0 is the neuron only excitatory type.
#define NumNeuron 2 
#define MUL_LYAPUNOV_EVOLUTION 1
#define MUL_NUM_LYA 7*NumNeuron /* number of LE you want to compute;In single neuron
there exist five possible lyap exponents; In Multiple  neurons equation, there 
exist multiple of seven */
#define Single_Neuron 0 //0 ʱ����MumainHH����,1 ����mainHH����
#define SMALL_DISPLACE (1.0e-8)
// this uses different orders of Runge-Kutta algorithm
#define RK4M 1
#define RK4 0
// the final stopping time of computation
//prevent the status of alpham1,alphan1
#define Epsilon (1.0e-16)
//
#define COMP_TIME  10000000
extern int MUL_VAR_NUM; /* number of perturbed variables, the order is: voltagei, mi,hi,ni,Gi,G1i,qi,
where the i index the i th neuron*/
extern double Tstep;
extern vector<vector<double> > Lyapunov;
extern vector<double> Lp;
extern vector<string> sloution_name;
extern vector<string> sloution_Vmhn_name;
extern double OmegaStart;
extern double OmegaFinal;
#endif // _HHconst_h_