#include <cstdlib>
#include <vector>
#include <string>
#include <iostream>
#include<cmath>
#include<fstream>
#include <sstream>
#include<iomanip>
#include<algorithm>
#include <stdio.h>
#include "HHconst.h"
#include"SHHfunction.h"
#include"THHfunciton.h"
#include"Lya_input.h"
#include"RK4.h"
using namespace std;

int MUL_VAR_NUM; /* number of perturbed variables, the order is: voltagei, mi,hi,ni,Gi,G1i,qi,
where the i index the i th neuron, if i==1, then the condounce term don't consider*/
double Tstep;
vector<vector<double> > Lyapunov;
vector<double> Lp;//  the end value of Lp is the Omega
vector<double> Lp_sort;//  the end value of Lp is the Omega
int name_iter=0;
vector<vector<double> > mul_lya_neu_0;//the reference trajectory;
vector<vector<double> > mul_lya_perturb_0; //perturbation trajectory;
vector<vector<double> > Af_Evolution_Value_0;//after Detal time perturbed trajectories;
vector<vector<double> > Difference_Refer_Perturb_Value_0;//The difference between each perturbed trajectory and the reference trajectory
vector<vector<double> >U ; //a set of orthonormal vectors
vector<vector<double> > V;
vector<double> T0,T1;
vector<vector<double> > Y0,Temp;
double h=0.01;int N=100;

void Lya (vector<double> y_0, vector<double> Omega) //Compute single neuron lyapunove exponent
 {
	 cout<<N<<endl<<h<<" ";
     double Detalt=N*h;
     Tstep=h;
	 cout<<"Now is running single Lyapunov exponents"<<endl;
	  double Tstart=0;//initial time;
	vector<double> mod(MUL_NUM_LYA);	
	// start of computing multiple lya-exponent initial  ******************
	int Dimension;
	Dimension=y_0.size();MUL_VAR_NUM=Dimension; //Dimension==MUL_VAR_NUM
	mul_lya_neu_0.resize(MUL_NUM_LYA);
	mul_lya_perturb_0.resize(MUL_NUM_LYA);
	Lyapunov.resize(MUL_NUM_LYA);
	Lp.resize((MUL_NUM_LYA));
	Af_Evolution_Value_0.resize(MUL_NUM_LYA);
	Difference_Refer_Perturb_Value_0.resize(MUL_NUM_LYA);
	U.resize(MUL_NUM_LYA);

	for(int q=0;q<MUL_NUM_LYA;q++)
	{
		Difference_Refer_Perturb_Value_0[q].resize(Dimension);
		U[q].resize(MUL_VAR_NUM);
	}
	for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_neu_0[k].push_back(y_0[i]);	
			}
			mul_lya_perturb_0[k].resize(Dimension);
	}
//*********************************************************************
	for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i];
			}
			mul_lya_perturb_0[k][k]=mul_lya_perturb_0[k][k]+SMALL_DISPLACE;
	} //end the initial of computing lya-ex;

	int iter=1; int sum_time_evolution=1;
while(1)
	{
		Runge_Kutta4(mul_lya_neu_0[0],Omega,Tstart,N,h,Y0,T0,voltage_dt,m_dt,h_dt,n_dt,q_dt);

		for(int k=0;k<MUL_NUM_LYA;k++) //MUL_NUM_LYA ---column
		{
			Runge_Kutta4(mul_lya_perturb_0[k],Omega,Tstart,N,h,Temp,T1,voltage_dt,m_dt,h_dt,n_dt,q_dt);
			Af_Evolution_Value_0[k]=Temp.back();
			mul_lya_neu_0[k]=Y0.back();
		}
		for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{
		Difference_Refer_Perturb_Value_0[k][i]=Af_Evolution_Value_0[k][i]-mul_lya_neu_0[k][i];

			}
		}
			V=MGS(Difference_Refer_Perturb_Value_0);
//********************************************************************test the MGS results
           /* for(int p=0;p<MUL_NUM_LYA;p++)
				for(int l=p+1;l<=MUL_NUM_LYA;l++)
				{
			{
				cout<<setprecision(16)<<scalar_product(V[p],V[l])<<endl;
			}
				}*/
//****************************************************************************************
		for(int m=0;m<MUL_NUM_LYA;m++)
			{
				mod[m]=sqrt(scalar_product(V[m],V[m]))*SMALL_DISPLACE;
			
			}
		for(int m=0;m<MUL_NUM_LYA;m++) 
			{
		
			for(int n=0;n<MUL_VAR_NUM;n++)  //MUL_VAR_NUM--rows
					{
					U[m][n]=V[m][n]/mod[m];
			
					}
			}

		Tstart=Tstart+Detalt;


		for(int m=0;m<MUL_NUM_LYA;m++) 
		{
			Lp[m]+=log(mod[m]/SMALL_DISPLACE)/Detalt;

		}
		for(int m=0;m<MUL_NUM_LYA;m++) 
		{
			Lyapunov[m].push_back(Lp[m]/iter);
		}

		
		if (iter==10000)// Terminal at 3s time
			break;
		iter=iter+1;

		for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i]+SMALL_DISPLACE*U[k][i];
			}
		}

	}//end while

   for(int k=0;k<MUL_NUM_LYA;k++)
   {
	   Lp[k]=Lp[k]/iter;
   }

     Lp.push_back(Omega[0]);

   mul_lya_record(Omega);
   	//release memory*****************
   FREE_1(mul_lya_neu_0);
   FREE_1(mul_lya_perturb_0);
   FREE_1(Af_Evolution_Value_0);
   FREE_1(Difference_Refer_Perturb_Value_0);
   FREE_1(Temp);
   FREE_1(Y0);
   FREE_1(V);
   FREE_1(U);
   FREE_2(T0);
   FREE_2(T1);
	vector<double> LP;
	Lp.swap(LP);
	//*******************************
 }


 void Mul_Lya (vector<double> y_0, vector<double> Omega,vector<vector<double> >Couple,vector<double> amp) //Compute Multipy neurons lyapunove exponents
 {
	 cout<<N<<endl<<h<<" ";
     double Detalt=N*h;
	 int number_neuron;
	 number_neuron=NumNeuron;
     Tstep=h;
	 cout<<"Now is running MultiNeuron Lyapunov exponents"<<endl;
	  double Tstart=0;//initial time;
	 vector<double> mod(MUL_NUM_LYA);	
	// start of computing multiple lya-exponent initial  ******************
	int Dimension;
	Dimension=y_0.size();MUL_VAR_NUM=Dimension; //Dimension==MUL_VAR_NUM
	mul_lya_neu_0.resize(MUL_NUM_LYA);
	mul_lya_perturb_0.resize(MUL_NUM_LYA);
	Lyapunov.resize(MUL_NUM_LYA);
	Lp.resize((MUL_NUM_LYA));
	Af_Evolution_Value_0.resize(MUL_NUM_LYA);
	Difference_Refer_Perturb_Value_0.resize(MUL_NUM_LYA);
	U.resize(MUL_NUM_LYA);
	for(int q=0;q<MUL_NUM_LYA;q++)
	{
		Difference_Refer_Perturb_Value_0[q].resize(Dimension);
		U[q].resize(MUL_VAR_NUM);
	}
	for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_neu_0[k].push_back(y_0[i]);	}

			mul_lya_perturb_0[k].resize(Dimension);
	}
//*********************************************************************
	for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i];
			}
			mul_lya_perturb_0[k][k]=mul_lya_perturb_0[k][k]+SMALL_DISPLACE;
	} //end the initial of computing lya-ex;

	int iter0=1; int sum_time_evolution=1;
	cout<<"the first w= "<< Omega[0]<<endl;
    cout<<"the second w= "<< Omega[1]<<endl;
while(1)
	{
		if (number_neuron==1)
		{
			Runge_Kutta4M(mul_lya_neu_0[0],Omega,Tstart,N,h,Y0,T0,Couple,amp,voltagei_dt,mi_dt,hi_dt,ni_dt,Gi_dt,G1i_dt,qi_dt);
		}
		else if(number_neuron==2)
		{
			Runge_Kutta4M(mul_lya_neu_0[0],Omega,Tstart,N,h,Y0,T0,Couple,amp,voltagei_1_dt,mi_1_dt,hi_1_dt,ni_1_dt,Gi_1_dt,G1i_1_dt,qi_1_dt);
		}
		else 
		{
		     Runge_Kutta4M(mul_lya_neu_0[0],Omega,Tstart,N,h,Y0,T0,Couple,amp,voltagei_3_dt,mi_3_dt,hi_3_dt,ni_3_dt,Gi_3_dt,G1i_3_dt,qi_3_dt);
		}
		for(int k=0;k<MUL_NUM_LYA;k++) //MUL_NUM_LYA ---column
		{
			//Runge_Kutta4M(mul_lya_perturb_0[k],Omega,Tstart,N,h,Temp,T1,Couple,amp,voltagei_dt,mi_dt,hi_dt,ni_dt,Gi_dt,G1i_dt,qi_dt);
			
			//Runge_Kutta4M(mul_lya_perturb_0[k],Omega,Tstart,N,h,Temp,T1,Couple,amp,voltagei_1_dt,mi_1_dt,hi_1_dt,ni_1_dt,Gi_1_dt,G1i_1_dt,qi_1_dt);
			
			Runge_Kutta4M(mul_lya_perturb_0[k],Omega,Tstart,N,h,Temp,T1,Couple,amp,voltagei_3_dt,mi_3_dt,hi_3_dt,ni_3_dt,Gi_3_dt,G1i_3_dt,qi_3_dt);

			Af_Evolution_Value_0[k]=Temp.back();
			mul_lya_neu_0[k]=Y0.back();
		}
		for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{
		Difference_Refer_Perturb_Value_0[k][i]=Af_Evolution_Value_0[k][i]-mul_lya_neu_0[k][i];

			}
		}
			V=MGS(Difference_Refer_Perturb_Value_0);
		for(int m=0;m<MUL_NUM_LYA;m++)
			{
				mod[m]=sqrt(scalar_product(V[m],V[m]))*SMALL_DISPLACE;
			
			}
		for(int m=0;m<MUL_NUM_LYA;m++) 
			{
		
			for(int n=0;n<MUL_VAR_NUM;n++)  //MUL_VAR_NUM--rows
					{
					U[m][n]=V[m][n]/mod[m];
			
					}
			}

		Tstart=Tstart+Detalt;


		for(int m=0;m<MUL_NUM_LYA;m++) 
		{
			Lp[m]+=log(mod[m]/SMALL_DISPLACE)/Detalt;

		}
		for(int m=0;m<MUL_NUM_LYA;m++) 
		{
			Lyapunov[m].push_back(Lp[m]/iter0);
		}

		
		if (iter0==10000)// Terminal at 1s time
			break;
		iter0=iter0+1;
		//cout<<"the iter= "<< iter0<<endl;

		for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i]+SMALL_DISPLACE*U[k][i];
			}
		}

	}//end while

   for(int k=0;k<MUL_NUM_LYA;k++)
   {
	   Lp[k]=Lp[k]/iter0;
   }

     Lp.push_back(Omega[0]);

	 cout<<"w= "<< Omega[0]<<endl;

   mul_lya_record(Omega);
   	//release memory*****************
   FREE_1(mul_lya_neu_0);
   FREE_1(mul_lya_perturb_0);
   FREE_1(Af_Evolution_Value_0);
   FREE_1(Difference_Refer_Perturb_Value_0);
   FREE_1(Temp);
   FREE_1(Y0);
   FREE_1(V);
   FREE_1(U);
   FREE_2(T0);
   FREE_2(T1);
	vector<double> LP;
	Lp.swap(LP);
	//*******************************
 }

 //**********************************************************************
 void Mul_Lya_Q (vector<double> y_0, vector<double> Omega,vector<vector<double> >Couple,vector<double> amp,vector<int> neuron_type_list) //Compute Multipy neurons lyapunove exponents
 {
	 cout<<N<<endl<<h<<" ";
     double Detalt=N*h;
	 int number_neuron;
	 number_neuron=NumNeuron;
     Tstep=h;
	 cout<<"Now is running Neuronal Type MultiNeuron Lyapunov exponents"<<endl;
	  double Tstart=0;//initial time;
	 vector<double> mod(MUL_NUM_LYA);	
	// start of computing multiple lya-exponent initial  ******************
	int Dimension;
	Dimension=y_0.size();MUL_VAR_NUM=Dimension; //Dimension==MUL_VAR_NUM
	mul_lya_neu_0.resize(MUL_NUM_LYA);
	mul_lya_perturb_0.resize(MUL_NUM_LYA);
	Lyapunov.resize(MUL_NUM_LYA);
	Lp.resize((MUL_NUM_LYA));
	Af_Evolution_Value_0.resize(MUL_NUM_LYA);
	Difference_Refer_Perturb_Value_0.resize(MUL_NUM_LYA);
	U.resize(MUL_NUM_LYA);
	for(int q=0;q<MUL_NUM_LYA;q++)
	{
		Difference_Refer_Perturb_Value_0[q].resize(Dimension);
		U[q].resize(MUL_VAR_NUM);
	}
	for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_neu_0[k].push_back(y_0[i]);	}

			mul_lya_perturb_0[k].resize(Dimension);
	}
//*********************************************************************
	for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i];
			}
			mul_lya_perturb_0[k][k]=mul_lya_perturb_0[k][k]+SMALL_DISPLACE;
	} //end the initial of computing lya-ex;

	int iter0=1; int sum_time_evolution=1;
	cout<<"the first w= "<< Omega[0]<<endl;
    cout<<"the second w= "<< Omega[1]<<endl;
	cout<<"the third w= "<< Omega[2]<<endl;
	if (number_neuron>3)
	{
	cout<<"the fourth w= "<< Omega[3]<<endl;
	}
while(1)
	{
		if (number_neuron==1)
		{
			Runge_Kutta4M(mul_lya_neu_0[0],Omega,Tstart,N,h,Y0,T0,Couple,amp,voltagei_dt,mi_dt,hi_dt,ni_dt,Gi_dt,G1i_dt,qi_dt);
		}
		else if(number_neuron==2)
		{
			Runge_Kutta4M(mul_lya_neu_0[0],Omega,Tstart,N,h,Y0,T0,Couple,amp,voltagei_1_dt,mi_1_dt,hi_1_dt,ni_1_dt,Gi_1_dt,G1i_1_dt,qi_1_dt);
		}
		else if(number_neuron==3)
		{
			Runge_Kutta4MQ(mul_lya_neu_0[0],Omega,Tstart,N,h,Y0,T0,Couple,amp,neuron_type_list,voltagei_3Q_dt,mi_3Q_dt,hi_3Q_dt,ni_3Q_dt,Gi_3Q_dt,G1i_3Q_dt,qi_3Q_dt); 
		}
		else
		{
			Runge_Kutta4MQ(mul_lya_neu_0[0],Omega,Tstart,N,h,Y0,T0,Couple,amp,neuron_type_list,voltagei_3mQ_dt,mi_3mQ_dt,hi_3mQ_dt,ni_3mQ_dt,Gi_3mQ_dt,G1i_3mQ_dt,qi_3mQ_dt); 
		}
		for(int k=0;k<MUL_NUM_LYA;k++) //MUL_NUM_LYA ---column
		{
			if (number_neuron==3)
			{
				Runge_Kutta4MQ(mul_lya_perturb_0[k],Omega,Tstart,N,h,Temp,T1,Couple,amp,neuron_type_list,voltagei_3Q_dt,mi_3Q_dt,hi_3Q_dt,ni_3Q_dt,Gi_3Q_dt,G1i_3Q_dt,qi_3Q_dt);
			}
			else
			{
				Runge_Kutta4MQ(mul_lya_perturb_0[k],Omega,Tstart,N,h,Temp,T1,Couple,amp,neuron_type_list,voltagei_3mQ_dt,mi_3mQ_dt,hi_3mQ_dt,ni_3mQ_dt,Gi_3mQ_dt,G1i_3mQ_dt,qi_3mQ_dt);
			}
			Af_Evolution_Value_0[k]=Temp.back();
			mul_lya_neu_0[k]=Y0.back();
		}
		for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{
		Difference_Refer_Perturb_Value_0[k][i]=Af_Evolution_Value_0[k][i]-mul_lya_neu_0[k][i];

			}
		}
			V=MGS(Difference_Refer_Perturb_Value_0);
		for(int m=0;m<MUL_NUM_LYA;m++)
			{
				mod[m]=sqrt(scalar_product(V[m],V[m]))*SMALL_DISPLACE;
			
			}
		for(int m=0;m<MUL_NUM_LYA;m++) 
			{
		
			for(int n=0;n<MUL_VAR_NUM;n++)  //MUL_VAR_NUM--rows
					{
					U[m][n]=V[m][n]/mod[m];
			
					}
			}

		Tstart=Tstart+Detalt;


		for(int m=0;m<MUL_NUM_LYA;m++) 
		{
			Lp[m]+=log(mod[m]/SMALL_DISPLACE)/Detalt;

		}
		for(int m=0;m<MUL_NUM_LYA;m++) 
		{
			Lyapunov[m].push_back(Lp[m]/iter0);
		}

		
		if (iter0==10000)// Terminal at 1s time
			break;
		iter0=iter0+1;
		//cout<<"the iter= "<< iter0<<endl;

		for(int k=0;k<MUL_NUM_LYA;k++)
		{
			for (int i=0;i<Dimension;i++)
			{ 
				mul_lya_perturb_0[k][i]=mul_lya_neu_0[k][i]+SMALL_DISPLACE*U[k][i];
			}
		}

	}//end while

   for(int k=0;k<MUL_NUM_LYA;k++)
   {
	   Lp[k]=Lp[k]/iter0;
   }
#if Lya_Computing_Start_M
     sort(Lp.begin(),Lp.end(),complare);
#endif
     Lp.push_back(Omega[0]);

	 cout<<"w= "<< Omega[0]<<endl;

   mul_lya_record(Omega);
   	//release memory*****************
   FREE_1(mul_lya_neu_0);
   FREE_1(mul_lya_perturb_0);
   FREE_1(Af_Evolution_Value_0);
   FREE_1(Difference_Refer_Perturb_Value_0);
   FREE_1(Temp);
   FREE_1(Y0);
   FREE_1(V);
   FREE_1(U);
   FREE_2(T0);
   FREE_2(T1);
	vector<double> LP;
	Lp.swap(LP);
	//*******************************
 }
//************************************************************************
 vector<vector<double> > MGS(vector<vector<double> > mul_lya_perturb)  // use the stable Gram-Schmidt algorithm
 {
	 //[m,k]=size(V); matlab
	 vector<vector<double> > Temp_lya_perturb;
	 int M;
	 M=mul_lya_perturb.size();
	 int K;
	 K=mul_lya_perturb[0].size();
	 Temp_lya_perturb.resize(M);
	 Temp_lya_perturb[0]=mul_lya_perturb[0];
	 // orthonormalize the perturbation by Gram-Schmidt algorithm! ***********************
	for (int n=1; n<M; n++)
	{		
		for (int j=0; j<n; j++)
		{
			double dot_value = scalar_product(mul_lya_perturb[n],mul_lya_perturb[j])*pow(SMALL_DISPLACE,2);
		    double dot_norm = scalar_product(mul_lya_perturb[j],mul_lya_perturb[j])*pow(SMALL_DISPLACE,2);
			for (int i=0; i<K; i++)
			{
				mul_lya_perturb[n][i] -=mul_lya_perturb[j][i]*(dot_value/dot_norm);
			}
		}
		Temp_lya_perturb[n]=mul_lya_perturb[n];
		
	}
	// end of orthonormalizing the perturbation by Gram-Schmidt algorithm! **************
	return 
		Temp_lya_perturb;
 }



 void mul_lya_record(vector<double> Omega)
{   
	int n;
	int name1 = 21;
	double name=3*Omega[0];
	char *str_eig=(char *)malloc(256*sizeof(char));
	if (str_eig == NULL)
	{
		cout<<"can not allocate space!"<<endl;
		getchar();
	}

		ofstream eig_write;

#if RK4M
		sprintf(str_eig,"Runge_Kutta4M/eig_%d_%d.txt",name1, (int)COMP_TIME);
#endif

#if RK4
		sprintf(str_eig,"Runge_Kutta4/eig_%d_%d.txt",  name1, (int)COMP_TIME);
#endif

		eig_write.open(str_eig, ios::app);
//	getchar();
		if ( eig_write.fail() )
		{
			cout<<"Error: open eigvalue file error!"<<endl;
			getchar();
			return;
		}

		for (vector<double>::iterator iter=Lp.begin();iter !=Lp.end();++iter)
					{
						eig_write<<*iter<<" ";
	
					}
      eig_write << endl;


		eig_write.close();
		eig_write.clear();

//*****************************************************************************************
// record the lyapunov exponent at different time to see if it converges or not!
#if MUL_LYAPUNOV_EVOLUTION // start of recording multiple lyapunov exponent!
	name_iter=name_iter+1;
		if(name_iter==2)
		{
		for (n=0; n<MUL_NUM_LYA; n++)
	{
		ofstream eig_evolve_write;

#if RK4M
		sprintf(str_eig,"Runge_Kutta4M/eigevolve_%d_%f_%f.txt", n, name, (int)COMP_TIME);
#endif

#if RK4
		sprintf(str_eig,"Runge_Kutta4/eigevolve_%d_%f_%d.txt", n, name, (int)COMP_TIME);
#endif
		eig_evolve_write.open(str_eig,ios::binary | ios::out);
//	getchar();
		if ( eig_evolve_write.fail() )
		{
			cout<<"Error: open eigvalue file error!"<<endl;
			getchar();
			return;
		}

		for (unsigned int j=0; j< Lyapunov[n].size(); j++)
			{
				eig_evolve_write<<Lyapunov[n][j]<<" ";
			}
				eig_evolve_write<<endl;
		eig_evolve_write.close();
		eig_evolve_write.clear();	
	}
		}
#endif // end of recording evoltion of lyapunov exponent
	free(str_eig);
	//release memory*****************
	vector<vector<double> > Lya_Temp;
	Lyapunov.swap(Lya_Temp);
	//*******************************
}
double scalar_product(const vector<double>& a,const vector<double>& b)   
{  
    double scalar=0;  
    if(a.size()!=b.size())   
        return false;   
    for(unsigned int i=0;i<a.size();i++)   
        scalar+=(a[i]/(SMALL_DISPLACE))*(b[i]/(SMALL_DISPLACE));   
    return scalar;   
}  
void FREE_1(vector<vector<double> > &Initial_1)
{
	vector<vector<double> > SWAP_1;
    Initial_1.swap(SWAP_1);

}
void FREE_2(vector<double> &Initial_2)
{

	vector<double> SWAP_2;
	Initial_2.swap(SWAP_2);
}

bool complare(double a,double b)
{
    return a>b;
}