#ifndef _SHHfunction_h_
#define _SHHfunction_h_
#include <iostream>
#include <vector>
#include <string>
using namespace std;

    void voltage_dt(double t,vector<double> y,double &dv_dt);
    void m_dt(double t,double y_0,double y, double &dm_dt);
	void h_dt(double t,double y_0,double y,double &dh_dt);
	void n_dt(double t,double y_0,double y, double &dn_dt);
	void q_dt(double t,double Omega,double &dq_dt);
	vector<double> ISIJin(int N, vector<double> y_0,double Omega);
	

#endif // _SHHfunction_h_
