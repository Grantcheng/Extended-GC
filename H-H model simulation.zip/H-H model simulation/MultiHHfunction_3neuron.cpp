#include <cstdlib>
#include <vector>
#include <string>
#include <iostream>
#include<cmath>
#include"HHconst.h"
#include"THHfunciton.h"
using namespace std;
double v_3;
double alphan_3,betan_3,alpham_3,betam_3,alphah_3,betah_3;
double SUM_2(double x, double y);
/*double vectordoubleSum(vector<double>::iterator first, vector<double>::size_type size);vector ���*/

void voltagei_3_dt(double t,vector<double> y,vector<double> amp,vector<double> &dv_dt)
{
	dv_dt[0]=(amp[0]+sin(2*pi*y[6]))-(g_na_max*(pow(y[1],3))*y[2]*(y[0]-115) + g_k_max*(pow(y[3],4))*(y[0]+12) + g_l*(-10.6+y[0]))-y[4]*(y[0]+65);
	dv_dt[1]=(amp[1]+sin(2*pi*y[13]))-(g_na_max*(pow(y[8],3))*y[9]*(y[7]-115) + g_k_max*(pow(y[10],4))*(y[7]+12) + g_l*(-10.6+y[7]))-y[11]*(y[7]+65);
	dv_dt[2]=(amp[2]+sin(2*pi*y[20]))-(g_na_max*(pow(y[15],3))*y[16]*(y[14]-115) + g_k_max*(pow(y[17],4))*(y[14]+12) + g_l*(-10.6+y[14]))-y[18]*(y[14]+65);

}
    void mi_3_dt(double t,vector<double> y, vector<double> &dm_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
	      int y1=1+7*(NumNeuronth-1);
	      v_3=y[7*(NumNeuronth-1)];
	      //m channel
	      alpham_3=0.1*(25-v_3)/(exp((25-v_3)/10)-1);
	      betam_3=4*exp(-v_3/18);
	      dm_dt[NumNeuronth-1]=(alpham_3-(alpham_3+betam_3)*y[y1]);
	}
}
	void hi_3_dt(double t,vector<double> y,vector<double> &dh_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
	      int y2=2+7*(NumNeuronth-1);
	      v_3=y[7*(NumNeuronth-1)];
	      //h channel
	      alphah_3=0.07*exp(-v_3/20);
	      betah_3=1/(exp((30-v_3)/10)+1);
	      dh_dt[NumNeuronth-1]=(alphah_3-(alphah_3+betah_3)*y[y2]);
	}
}
	void ni_3_dt(double t,vector<double> y, vector<double> &dn_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
	      int y3=3+7*(NumNeuronth-1);
	      v_3=y[7*(NumNeuronth-1)];
	      //n channel
	      alphan_3=0.01*(10-v_3)/(exp((10-v_3)/10)-1);
	      betan_3=0.125*exp(-v_3/80);
	      dn_dt[NumNeuronth-1]=(alphan_3-(alphan_3+betan_3)*y[y3]);
	}
}
	void Gi_3_dt(double t,vector<double> y,vector<double> &G_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{  
		int y4=4+7*(NumNeuronth-1);
		int y5=5+7*(NumNeuronth-1);
		G_dt[NumNeuronth-1]=y[y5]-y[y4]*2;
	}

}
	void G1i_3_dt(double t,vector<double> y,vector<vector<double> >  Couple,vector<double> &G_dt)
{
	
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
		double sum=0;
		int y5=5+7*(NumNeuronth-1);
		for(int PreNeuron=0;PreNeuron<NumNeuron;PreNeuron++)
		{
		int y7=7*(PreNeuron);
		
		sum=SUM_2(Couple[NumNeuronth-1][PreNeuron]*(1/(1+exp(-(y[y7]-20)/2))),sum);
		}
		G_dt[NumNeuronth-1]= -(y[y5]/3)+sum;
	}
	}
	void qi_3_dt(double t,vector<double> Omega,vector<double> &dq_dt)
{
	for (int NumNeuronth=1;NumNeuronth<(NumNeuron+1);NumNeuronth++)
	{
	   dq_dt[NumNeuronth-1]=Omega[NumNeuronth-1];
	}
}
	double SUM_2(double x, double y)
	{
		return (x+y);
	}