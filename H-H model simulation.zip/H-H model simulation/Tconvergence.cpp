#include<iostream>
#include<cmath>
#include<iomanip>
#include<fstream>
#include <stdio.h>
#include <stdlib.h>
#include <sstream>
#include<vector>
#include "HHconst.h"
#include"SHHfunction.h"
#include"THHfunciton.h"
#include "RK4.h"
using namespace std;
void save(vector<vector<double> > DATA,string fname);
string   double_to_str(double x) ;



void Convergence_1(vector<double> y_0,vector<double> Omega,double Tstart,double N_0,double h_0,vector<double> &y_convergence,
	double &T0_convergence,double Time)
{
	vector<vector<double> >Y_C ; //save the convergence value at Time=1024ms; 
//Convergence test

ModfyRunge_Kutta4(y_0,Omega,Tstart,N_0,h_0,y_convergence,T0_convergence,voltage_dt,m_dt,h_dt,n_dt,q_dt);
cout<<"The reference value"<<endl;
cout<<setprecision(16)<<y_convergence[0]<<endl;
Y_C.resize(1);
Y_C[0].push_back(y_convergence[0]);
cout<<"The y value"<<endl;
long double H=pow(256.00,(-1));
for (int lm=1;lm<6;lm++)
{    
  double h=pow(2.0,(lm-1))*H;
  long double N_1=Time/h;
  cout<<N_1<<endl;
ModfyRunge_Kutta4(y_0,Omega,Tstart,N_1,h,y_convergence,T0_convergence,voltage_dt,m_dt,h_dt,n_dt,q_dt);
cout<<setprecision(16)<<T0_convergence<<endl;
cout<<setprecision(16)<<y_convergence[0]<<endl;
Y_C[0].push_back(y_convergence[0]);
}
string fname="convergence1test";     //
save(Y_C,fname);

}


void Convergence_2(vector<double> y_0,vector<double> Omega,double Tstart,double N_0,double h_0,vector<double> &y_convergence,
	double &T0_convergence,	vector<vector<double> >Couple,vector<double> amp,double Time)
{
vector<vector<double> >Y_C ; //save the convergence value at Time=1024ms;
//Convergence test
 ModfyRunge_Kutta4M(y_0,Omega,Tstart,N_0,h_0,y_convergence,T0_convergence,Couple,amp,voltagei_dt,mi_dt,hi_dt,ni_dt,Gi_dt,G1i_dt,qi_dt);
 //ModfyRunge_Kutta4M(y_0,Omega,Tstart,N_0,h_0,y_convergence,T0_convergence,Couple,amp,voltagei_1_dt,mi_1_dt,hi_1_dt,ni_1_dt,Gi_1_dt,G1i_1_dt,qi_1_dt);
cout<<"The reference value "<<endl;
cout<<setprecision(16)<<y_convergence[0]<<endl<<setprecision(16)<<y_convergence[7]<<endl;
Y_C.resize(2);
Y_C[0].push_back(y_convergence[0]);
Y_C[1].push_back(y_convergence[7]);
cout<<"The y value"<<endl;
long double H=(double)1/2048;
for (int l=1;l<6;l++)
{    y_convergence.clear();
    T0_convergence=0;
  double h=pow(2.0,(l-1))*H;
  long double N_1=Time/h;
ModfyRunge_Kutta4M(y_0,Omega,Tstart,N_1,h,y_convergence,T0_convergence,Couple,amp,voltagei_dt,mi_dt,hi_dt,ni_dt,Gi_dt,G1i_dt,qi_dt);
//ModfyRunge_Kutta4M(y_0,Omega,Tstart,N_1,h,y_convergence,T0_convergence,Couple,amp,voltagei_1_dt,mi_1_dt,hi_1_dt,ni_1_dt,Gi_1_dt,G1i_1_dt,qi_1_dt);
cout<<T0_convergence<<endl;
cout<<setprecision(16)<<y_convergence[0]<<endl<<setprecision(16)<<y_convergence[7]<<endl;
Y_C[0].push_back(y_convergence[0]);
Y_C[1].push_back(y_convergence[7]);
}
string fname="convergence2test";     //
save(Y_C,fname);
}