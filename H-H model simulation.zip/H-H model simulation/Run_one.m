fname_1='E:\research\Brain Neuron\H-H model C++\X64\H-H model simulation\H-H model simulation\RK4\ISI(0-1)\ISI(0-1)';
fname_f='E:\research\Brain Neuron\H-H model C++\X64\H-H model simulation\H-H model simulation\RK4\ISI(0-1)\ISI(0-1)f_1';
f=Dadaread(fname_f);
f=f{1}';
ISI0=Dadaread(fname_1);
i=size(ISI0,2);
F=zeros(i,1);ISIms2={};
m=0;
 for j=1:i-1
    ISIms1=ISI0{j}'; 
    subplot(2,1,1);
    plot(f(j,1),ISIms1(300:end),'k.','MarkerSize',3)
    hold on;
end
xlabel('f '),ylabel('ISI(ms)');