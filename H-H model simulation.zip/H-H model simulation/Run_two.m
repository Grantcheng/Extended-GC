clear;clc;
%% 
% fname_1='C:\Users\IBM\Documents\My Dropbox\Graduate thesis\H-H (two neuron)modify\hh\Results\New Results\detalt=0.5 detaltd=3\Dynamical\(0-1)\s12=0.9 s21=0\ISI0(0-1)_1\ISI0(0-1)_1';
% fname_2='C:\Users\IBM\Documents\My Dropbox\Graduate thesis\H-H (two neuron)modify\hh\Results\New Results\detalt=0.5 detaltd=3\Dynamical\(0-1)\s12=0.9 s21=0\ISI1(0-1)_1\ISI1(0-1)_1';
% fname_f='C:\Users\IBM\Documents\My Dropbox\Graduate thesis\H-H (two neuron)modify\hh\Results\New Results\detalt=0.5 detaltd=3\Dynamical\(0-1)\s12=0.9 s21=0\ISI(0-1)f_1\ISI(0-1)f_1';
% fname_1='/media/My Passport/RESEARCH/Brain Neuron/Final HH model C++/H-H model C++/X64/H-H model simulation/H-H model simulation/RK4/ISI0(0-1)_1/ISI0(0-1)_1';
% fname_2='/media/My Passport/RESEARCH/Brain Neuron/Final HH model C++/H-H model C++/X64/H-H model simulation/H-H model simulation/RK4/ISI1(0-1)_1/ISI1(0-1)_1';
% fname_f='/media/My Passport/RESEARCH/Brain Neuron/Final HH model C++/H-H model C++/X64/H-H model simulation/H-H model simulation/RK4/ISI(0-1)f_1/ISI(0-1)f_1';

fname_1='M:\RESEARCH\Brain Neuron\Final HH model C++\H-H model C++\X64\H-H model simulation\H-H model simulation\RK4\ISI0(0-1)_1\ISI0(0-1)_1';
fname_2='M:\RESEARCH\Brain Neuron\Final HH model C++\H-H model C++\X64\H-H model simulation\H-H model simulation\RK4\ISI1(0-1)_1\ISI1(0-1)_1';
fname_f='M:\RESEARCH\Brain Neuron\Final HH model C++\H-H model C++\X64\H-H model simulation\H-H model simulation\RK4\ISI(0-1)f_1\ISI(0-1)f_1';
%% --------------
f=Dadaread(fname_f);
f=f{1}';
ISI0=Dadaread(fname_1);
ISI1=Dadaread(fname_2);
i=size(ISI0,2);
F=zeros(i,1);ISIms2={};
m=0;
%% ISI
figure;
 for j=1:2:i-1
    ISIms1=ISI0{j}'; 
%     subplot(1,1,1);
    plot(f(j,1),ISIms1(100:end),'k.','MarkerSize',2)
    hold on;
end
xlabel('f '),ylabel('First Neuron ISI(ms)');
% title('S_1_2=0.55');
% title('S_1_2=0.9 S_2_1=0');
for j=1:i-1
    if(~isempty(ISI1{j})&&length(ISI1{j})>150)
        m=m+1;
        F(m)=f(j);
        ISIms2{m}=ISI1{j}';
    end
end

figure;
if (m==0)
    subplot(1,1,1);
else    
for j=1:2:m
subplot(1,1,1)
plot(F(j,1),ISIms2{j}(149:end),'b.','MarkerSize',2)
hold on;
end
end
xlabel('f '),ylabel('Second Neuron ISI(ms)');  
axis([0 1 0 150])
% title('S_1_2=0.55');
% title('S_1_2=0.9  S_2_1=0')
%% fire ratefigure;
figure;
 for j=1:i-1
    ISIms1=length(ISI0{j});
subplot(1,1,1);
plot(f(j,1),ISIms1/10,'k.','Markersize',4.5)
hold on;
 end
xlabel('f '),ylabel('Fire rate( s) ');
% title('S_1_2=0.55');
% title('S_1_2=0.9  S_2_1=0')

figure;
for j=1:i-1
        ISIms2=length(ISI1{j});
     subplot(1,1,1);
     plot(f(j,1),ISIms2/10,'k.','Markersize',4.5)
     hold on;
end
xlabel('f '),ylabel('Fire rate( s) ');
% title('S_1_2=0.55');
% title('S_1_2=0.9  S_2_1=0')