#ifndef _Lyap_h_
#define _Lyap_h_
#include <iostream>
#include <vector>
#include <string>
#include <cmath>;
using namespace std;

   vector<double> MGS(vector<double>v1,vector<double>v2);//Gram-Schmidt algorithm

   double Lya (int argc, char** argv);

#endif // _Lyap_h_
