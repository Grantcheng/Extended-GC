/*
MultiHHfuntion.cpp and MumainHH_1.cpp: it is mainly used to compute Two Neuron HH model, which it is special to two neuron state
*/
#include <cstdlib>
#include <vector>
#include <iostream>
#include<fstream>
#include <string>
#include<cmath>
#include <time.h>
#include<sstream>
#include"HHconst.h"
#include"SHHfunction.h"
#include"THHfunciton.h"
using namespace std;

void mainHH(int argc, char** argv);
void MumainHH(int argc, char** argv);
void MumainHH_1(int argc, char** argv);
void MumainHH_2(int argc, char** argv);
void MumainHH_MNeuron(int argc, char** argv);
int main(int argc, char** argv)
{
	double f2=1;
	int number_neu;
	number_neu=NumNeuron;

    #if Single_Neuron
	double time = clock();
		mainHH(argc, argv);

	#else
	if (number_neu==2)
	{
	double time = clock();
	if (f2==1)
	MumainHH_1(argc,argv);
	else
	MumainHH(argc,argv);
	}
	else if (number_neu==3)
	{
       MumainHH_2(argc,argv);
	}
	else
	{
       MumainHH_MNeuron(argc,argv);
	}

	//cout<<"time consuming: "<<(clock()-time)/CLOCKS_PER_SEC<<"seconds"<<endl;

#endif
	
	system("pause");
	return 0;

}