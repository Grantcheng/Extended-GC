#include <cstdlib>
#include <vector>
#include <iostream>
#include<fstream>
#include <string>
#include<cmath>
#include <time.h>
#include<sstream>
#include"HHconst.h"
#include"SHHfunction.h"
#include "Lya_input.h"

using namespace std;

vector<vector<double> > ISIJin(int N, vector<double> y_0, vector<double> Omega,vector<vector<double> >Couple,vector<double> amp);
vector<vector<double> > ISIJin_3_Neuron(int N, vector<double> y_0, vector<double> Omega,vector<vector<double> >Couple,vector<double> amp);
void save(vector<vector<double> > DATA,string fname);
string   double_to_str(double x) ;


void mainHH(int argc, char** argv)
{	double duration;
	int ii=0;
	clock_t start,finish;
	vector<vector<double> >Couple;
	vector<double> amp;
	vector<vector<double> >ISIout;
	vector<double>Lomega(1);
	vector<vector<double> > ISI;
	double yy_0[]={0,0.05293248500000000,0.59612075400000000,0.31767691400000000,0.00001};
	
	vector<double>y_0;

	for (int i=0;i<5;i++)
	{
		y_0.push_back(yy_0[i]);
	}

	//convergence test program
#if Convergence_Test_0
	start=clock();
	double Convergnce_Omega;
	printf("please input the initial value = Convergnce Omega    ");
	cin>>Convergnce_Omega;
	Lomega[0]=Convergnce_Omega*f0;
	cout<<Lomega[0]<<endl;
	    ISIout=ISIJin(1000000,y_0,Lomega,Couple,amp);//10s time evolution
		finish=clock();
	   duration=(double)(finish-start)/CLOCKS_PER_SEC;
	   printf("%f seconds\n", duration);
	//******************************end convergence test
#else

	#if Runmain_each_solution // obtain each solution of HH system equation
	double Omega;
	printf("please input the initial value = OmegaStart    ");
	cin>>Omega;
	Lomega[0]=Omega*f0;
	cout<<"Now is run Single Neuron Solution "<<endl;
	cout<<"Omega=  "<<Lomega[0]<<endl;
	start=clock();
	ISIout=ISIJin(1000000,y_0,Lomega,Couple,amp);//10s time evolution N=1000000
	#if Lya_Computing_Start
	Lya(y_0,Lomega); //compute the Lyapunove exponents
	finish=clock();
	duration=(double)(finish-start)/CLOCKS_PER_SEC;
	printf("%f seconds\n", duration);
	#endif		
#else

	double OmegaStart;
	double OmegaFinal;
	int N;int range;//1--��ʾ��0��1����0--��ʾ����
	double Steph;
		printf("please input the initial value = OmegaStart    ");
	cin>>OmegaStart;
	printf("please input the initial value = OmegaFinal    ");
	cin>>OmegaFinal;
		printf("please input the range =     ");
	cin>>range;
	if (range==1)
	{Steph=0.001/3;}//range[0,1],use step
     else 
	 {Steph=0.00001/3;}//other range,use step
	OmegaStart=OmegaStart*f0;
	OmegaFinal=OmegaFinal*f0;
	string fname="ISI("+double_to_str(3*OmegaStart)+"-"+double_to_str(3*OmegaFinal)+")";     //ISI(0.34600-0.34602)
	N=(int)((OmegaFinal-OmegaStart)/Steph+0.5);
	ISI.resize(N+1);
	for (double Omega=OmegaStart;Omega<=OmegaFinal;Omega=(Omega+Steph))
	{   
		Lomega[0]=Omega;
	   start=clock();

	   #if Lya_Computing_Start
	   Lya(y_0,Lomega); //compute the Lyapunove exponents
	   finish=clock();
	   duration=(double)(finish-start)/CLOCKS_PER_SEC;
	   printf("%f seconds\n", duration);
	   #endif		

		#if Runmainhh
	   cout<<"Now is run Single Neuron Solution and ISI   "<<endl;
	    ISIout=ISIJin(1000000,y_0,Lomega,Couple,amp);//10s time evolution N=1000000
	   ISI[ii].resize(ISIout[0].size());
	   ISI[ii]=ISIout[0];
	  // ISI[i].assign(ISIout.begin(),ISIout.end()); 
	   ii++;
	   finish=clock();
	   duration=(double)(finish-start)/CLOCKS_PER_SEC;
	   printf("%f seconds\n", duration);
	  #endif
 	}
		#if Runmainhh
			 save(ISI,fname);
		#endif
#endif
#endif

	 }