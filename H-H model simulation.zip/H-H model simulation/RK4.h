#ifndef _RK4_H_
#define _RK4_H_
#include <iostream>
#include <vector>
#include <string>
using namespace std;
void Runge_Kutta4(vector<double> y0,vector<double> Omega,double t0,int iter,double h,vector<vector<double> >  &y,
	vector<double>  &t,	void (*dvdt)(double t,vector<double> y,double &dv_dt),
	void (*dmdt)(double t,double y_0, double y_1, double &dm_dt),
	void (*dhdt)(double t,double y_0, double y_2, double &dh_dt),
	void (*dndt)(double t,double y_0, double y_3,double &dn_dt),
	void (*dqdt)(double t,double Omega, double &dq_dt));

void ModfyRunge_Kutta4(vector<double> y0,vector<double> Omega,double t0,long double iter,double h,vector<double> &y,
	double &t,	void (*dvdt)(double t,vector<double> y,double &dv_dt),
	void (*dmdt)(double t,double y_0, double y_1, double &dm_dt),
	void (*dhdt)(double t,double y_0, double y_2, double &dh_dt),
	void (*dndt)(double t,double y_0, double y_3,double &dn_dt),
	void (*dqdt)(double t,double Omega, double &dq_dt));

void Runge_Kutta4M(vector<double> y0,vector<double> Omega,double t0,int iter,double h,vector<vector<double> > &y,
	vector<double>  &t,	vector<vector<double> >Couple,vector<double> amp,
	void (*dvdt)(double t,vector<double> y,vector<double> amp,vector<double>  &dvi_dt),
	void (*dmdt)(double t,vector<double> y, vector<double>  &dmi_dt),
	void (*dhdt)(double t,vector<double> y,vector<double>  &dhi_dt),
	void (*dndt)(double t,vector<double> y, vector<double>  &dni_dt),
	void (*Gidt)(double t,vector<double> y,vector<double>  &Gi_dt),
	void (*G1idt)(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt),
	void (*dqdt)(double t,vector<double> Omega,vector<double>  &dqi_dt));

void ModfyRunge_Kutta4M(vector<double> y0,vector<double> Omega,double t0,long double iter,double h,vector<double> &y,
	double &t,	vector<vector<double> >Couple,vector<double> amp,
	void (*dvdt)(double t,vector<double> y,vector<double> amp,vector<double>  &dvi_dt),
	void (*dmdt)(double t,vector<double> y, vector<double>  &dmi_dt),
	void (*dhdt)(double t,vector<double> y,vector<double>  &dhi_dt),
	void (*dndt)(double t,vector<double> y, vector<double>  &dni_dt),
	void (*Gidt)(double t,vector<double> y,vector<double>  &Gi_dt),
	void (*G1idt)(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt),
	void (*dqdt)(double t,vector<double> Omega,vector<double>  &dqi_dt));

void Runge_Kutta4MQ(vector<double> y0,vector<double> Omega,double t0,int iter,double h,vector<vector<double> > &y,
	vector<double>  &t,	vector<vector<double> >Couple,vector<double> amp,vector<int> neuron_type_list,
	void (*dvdt)(double t,vector<double> y,vector<double> amp,vector<double>  &dvi_dt,vector<int> neuron_type_list),
	void (*dmdt)(double t,vector<double> y, vector<double>  &dmi_dt),
	void (*dhdt)(double t,vector<double> y,vector<double>  &dhi_dt),
	void (*dndt)(double t,vector<double> y, vector<double>  &dni_dt),
	void (*Gidt)(double t,vector<double> y,vector<double>  &Gi_dt,vector<int> neuron_type_list),
	void (*G1idt)(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt,vector<int> neuron_type_list),
	void (*dqdt)(double t,vector<double> Omega,vector<double>  &dqi_dt));

#endif