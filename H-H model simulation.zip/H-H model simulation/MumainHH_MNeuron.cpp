#include <cstdlib>
#include <vector>
#include <iostream>
#include<fstream>
#include <string>
#include <iomanip>
#include<cmath>
#include <time.h>
#include<sstream>
#include"HHconst.h"
#include"THHfunciton.h"
#include "Lya_input.h"

using namespace std;
void save_f(vector<double>DATA,string fname);
vector<vector<double> > ISIJin_3_Neuron(int N, vector<double> y_0, vector<double> Omega,vector<vector<double> >Couple,vector<double> amp);
vector<vector<double> > ISIJin_3Q_Neuron(int N, vector<double> y_0, vector<double> Omega,vector<vector<double> >Couple,vector<double> amp,vector<int> neuron_type_list);
vector<vector<double> > ISIJin_3mQ_Neuron(int N, vector<double> y_0, vector<double> Omega,vector<vector<double> >Couple,vector<double> amp,vector<int> neuron_type_list);

void save(vector<vector<double> > DATA,string fname);
string   double_to_str(double x) ;
void MumainHH_MNeuron(int argc, char** argv){
	double duration;
	clock_t start,finish;
	vector<vector<double> >ISIout;
	vector<string>fname;
	vector<string> sloution_name;
	int Dimension=7*NumNeuron;
	// The initial state
	vector<vector<double> >yy_0;
	yy_0.resize(NumNeuron);
	for (int k=0;k<NumNeuron;k++)
	{yy_0[k].resize(Dimension);}

	double yy_initial_0[]={0,0.052932485257250,0.596120753508460, 0.317676914060697,0,0,0};
	//double yy_0[]={0,0.052932485257250,0.596120753508460, 0.317676914060697,0,0,0,0,0.052932485257250,0.596120753508460, 0.317676914060697,0,0,0,0,0.052932485257250,0.596120753508460, 0.317676914060697,0,0,0};
	
	for (int NumNeuron_index=0;NumNeuron_index<NumNeuron;NumNeuron_index++)
	{  
		for (int Dimension_k=0;Dimension_k<7;Dimension_k++)
	    {
             yy_0[NumNeuron_index][Dimension_k]=yy_initial_0[Dimension_k];
	    }
	
	}
	vector<double>y_0;
	//int Dimension=sizeof(yy_0)/sizeof(yy_0[0]);
	for (int NumNeuron_index=0;NumNeuron_index<NumNeuron;NumNeuron_index++)
	{
	     for (int i=0;i<7;i++)
	      {
		    y_0.push_back(yy_0[NumNeuron_index][i]);
	      }
	}

	//******************************** Couple
			ifstream   infile( "Couple.txt " ); 
		if   (   !   infile   ) 
		{ 
			cerr   << "can 't   open   Couple.txt"; 
			exit(   -1   ); 
		} 
			vector<vector<double> >  Couple;
			vector<double>temp;
			string line;
			istringstream istr;
			double data;
			while(getline(infile,line))
			{
				istr.str(line);
				while(istr>>data)
			{
				temp.push_back(data);
			}
				Couple.push_back(temp);
				temp.clear();
				istr.clear();

			}
				infile.close();
				cout<<"The Couple of neuron network set is:  "<<endl;
			for(unsigned int i=0;i<Couple.size();i++)
				{
					for (vector<double>::iterator iter=Couple[i].begin();iter !=Couple[i].end();++iter)
						{
							cout<<*iter<<" ";
						}
							cout<<endl;
				}

//************************************************************* amp
			ifstream   ampfile( "amp.txt " ); 
			if   (   !   ampfile   ) 
			{ 
				cerr   << "can 't   open   amp.txt"; 
				exit(   -1   ); 
			} 
				vector<double>amp;
				string line_amp;
				istringstream iamp;
				while(getline(ampfile,line_amp))
			{
				iamp.str(line_amp);
				while(iamp>>data)
			{
				amp.push_back(data);
			}
				iamp.clear();

			}
				ampfile.close();

				cout<<"The Amp of neuron network set is:  "<<endl;
					for (vector<double>::iterator iter=amp.begin();iter !=amp.end();++iter)
						{
							cout<<*iter<<" ";
						}
							cout<<endl;
				
					//******************************** Neuron Type
							#if TypeNeuron
		ifstream   neutypefile( "neutype.txt " ); 
			if   (   !   neutypefile   ) 
			{ 
				cerr   << "can 't   open   neutype.txt"; 
				exit(   -1   ); 
			} 
				vector<int> neuron_type_list;// 1 is excitory type, 0 is inhibatory type.
				string line_neuron_type_list;
				istringstream ineuron_type_list;
				while(getline(neutypefile,line_neuron_type_list))
			{
				ineuron_type_list.str(line_neuron_type_list);
				while(ineuron_type_list>>data)
			{
				neuron_type_list.push_back(data);
			}
				ineuron_type_list.clear();

			}
				neutypefile.close();
				cout<<"The neutype of neuron network set is:  "<<endl;
					for (vector<int>::iterator iter=neuron_type_list.begin();iter !=neuron_type_list.end();++iter)
						{
							cout<<*iter<<" ";
						}
							cout<<endl;
	#endif 

	//******************************** Neuron frequency
	ifstream   MNFfile( "MNfrequency.txt " ); 
			if   (   !   MNFfile   ) 
			{ 
				cerr   << "can 't   open   MNfrequency.txt"; 
				exit(   -1   ); 
			} 
				
				vector<double>Lomega;
				string line_MNf;
				istringstream iMNf;
				while(getline(MNFfile,line_MNf))
			{
				iMNf.str(line_MNf);
				while(iMNf>>data)
			{
				Lomega.push_back(data*f0);
			}
				iMNf.clear();

			}
				MNFfile.close();

				cout<<"The stimulus frequency of neuron network set is:  "<<endl;
					for (vector<double>::iterator iter=Lomega.begin();iter !=Lomega.end();++iter)
						{
							cout<<*iter<<" ";
						}
							cout<<endl;
					
	//*********************************************************************	
	int N;
	int ii;
    double OmegaStart;
	double OmegaFinal;
	double Steph;
	int range;//1--��ʾ��0��1����0--��ʾ����
	range=1;
	if (range==1)
	{Steph=0.001/3;
	}//range[0,1],use step
     else 
	 {Steph=0.00001/3;
	}//other range,use step

	cout<<"The Step Length is : "<<Steph<<"   "<<endl;
	
	OmegaStart=Lomega[0];
	OmegaFinal=Lomega[0];

	string f_name;
	
	N=(int)((OmegaFinal-OmegaStart)/Steph+0.5);
	cout<<"The Whole Length is : "<<N<<endl;
	//***** This part is the convergence test
//*******************************
	vector<double>f;
	vector <vector <vector <double>   >   > ISI;
		ISI.resize(NumNeuron);
	for (int k=0;k<NumNeuron;k++)
	{ISI[k].resize(N+1);}
//*******************************
			for(int k=0;k<NumNeuron;k++)
	    {
			fname.push_back("ISI"+double_to_str(k)+"("+double_to_str(3*OmegaStart)+"-"+double_to_str(3*OmegaFinal)+")_1");
		 
			}//ISI(0.34600-0.34602)}
	 	 f_name="ISI("+double_to_str(3*OmegaStart)+"-"+double_to_str(3*OmegaFinal)+")f_1";
			ii=0;

		 for (double Omega_1=OmegaStart;Omega_1<=OmegaFinal;Omega_1=(Omega_1+Steph))
						{ 
								f.push_back(3*Omega_1);
								start=clock();
								for (int k=0;k<NumNeuron;k++)
								{
									printf("The %d Neuron Lomega\n", k);
									cout<<"The Lomega:  "<<Lomega[k]*3<<endl;
								}
												
			#if Lya_Computing_Start_M	// Compute the Lyapunove exponents of three neurons network
			    #if TypeNeuron
                Mul_Lya_Q(y_0,Lomega,Couple,amp,neuron_type_list);
                #else
				Mul_Lya(y_0,Lomega,Couple,amp); //compute the Lyapunove exponents
				#endif
				finish=clock();
				duration=(double)(finish-start)/CLOCKS_PER_SEC;
				printf("%f seconds\n", duration);
			#endif
				
				#if RunMumainHH_M // run the three neurons program

				#if TypeNeuron
				    cout<<"The code to computing TypeNeuron "<<endl;
					ISIout=ISIJin_3mQ_Neuron(1000000,y_0,Lomega,Couple,amp,neuron_type_list);//10s time evolution N=1000000
					#else
					ISIout=ISIJin_3_Neuron(1000000,y_0,Lomega,Couple,amp);//10s time evolution N=1000000
                #endif
					for (int k=0;k<NumNeuron;k++)
						{
						    ISI[k][ii].resize(ISIout[k].size());
							ISI[k][ii]=ISIout[k];
												}
					//********************* release the capacity of the ISIout
					     FREE_1(ISIout);
						 //************************
										 // ISI[i].assign(ISIout.begin(),ISIout.end()); 
													  ii++;
												  finish=clock();
									  duration=(double)(finish-start)/CLOCKS_PER_SEC;
											  printf("%f seconds\n", duration);
													 //free the vector
											   while (!Lomega.empty())
				                                  {
				                                    	Lomega.pop_back();
			                                      }
							#endif
		 }
	 #if RunMumainHH_M
//********** save the ISI and f		
		for (int k=0;k<NumNeuron;k++)
		 {
			save(ISI[k],fname[k]);
			}
			 save_f(f,f_name);
//******************************

//release memory*****************
	vector <vector <vector <double>   >   > ISI_temp;
	vector<double>f_temp;
	ISI.swap(ISI_temp);
	f.swap(f_temp);
	
//*******************************
#endif
return;}