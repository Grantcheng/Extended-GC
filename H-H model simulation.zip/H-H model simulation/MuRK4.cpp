#include<iostream>
#include<math.h>
#include<cmath>
#include<iomanip>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include"SHHfunction.h"
#include"THHfunciton.h"
#include"HHconst.h"
#include"Lya_input.h"
using namespace std;

void Runge_Kutta4MQ(vector<double> y0,vector<double> Omega,double t0,int iter,double h,vector<vector<double> > &y,
	vector<double>  &t,	vector<vector<double> >Couple,vector<double> amp,vector<int> neuron_type_list,
	void (*dvdt)(double t,vector<double> y,vector<double> amp,vector<double>  &dvi_dt,vector<int> neuron_type_list),
	void (*dmdt)(double t,vector<double> y, vector<double>  &dmi_dt),
	void (*dhdt)(double t,vector<double> y,vector<double>  &dhi_dt),
	void (*dndt)(double t,vector<double> y, vector<double>  &dni_dt),
	void (*Gidt)(double t,vector<double> y,vector<double>  &Gi_dt,vector<int> neuron_type_list),
	void (*G1idt)(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt,vector<int> neuron_type_list),
	void (*dqdt)(double t,vector<double> Omega,vector<double>  &dqi_dt))
{   int Dimension;
    Dimension=y0.size();
	vector<double>  temp(Dimension);
	vector<double>  k1(Dimension); 
	vector<double>  k2(Dimension); 
	vector<double>  k3(Dimension); 
	vector<double>  k4(Dimension); 
	vector<double> m11, m21, m31, m41;
	vector<double> m12, m22, m32, m42;
	vector<double> m13, m23, m33, m43;
	vector<double> m14, m24, m34, m44;
	vector<double> m15, m25, m35, m45;
	vector<double> m16, m26, m36, m46;
	vector<double> m17, m27, m37, m47;
	m11.resize(NumNeuron);m21.resize(NumNeuron); m31.resize(NumNeuron); m41.resize(NumNeuron);
	m12.resize(NumNeuron);m22.resize(NumNeuron); m32.resize(NumNeuron); m42.resize(NumNeuron);
	m13.resize(NumNeuron);m23.resize(NumNeuron); m33.resize(NumNeuron); m43.resize(NumNeuron);
	m14.resize(NumNeuron);m24.resize(NumNeuron); m34.resize(NumNeuron); m44.resize(NumNeuron);
	m15.resize(NumNeuron);m25.resize(NumNeuron); m35.resize(NumNeuron); m45.resize(NumNeuron);
	m16.resize(NumNeuron);m26.resize(NumNeuron); m36.resize(NumNeuron); m46.resize(NumNeuron);
	m17.resize(NumNeuron);m27.resize(NumNeuron); m37.resize(NumNeuron); m47.resize(NumNeuron);

	t.resize(iter+1);
	y.resize(iter+1);// 7*NumNeuron solutions

	t[0]=t0;
	for (int j=1;j<iter+1;j++)
		{
			y[j].resize(Dimension);
		}

	y[0]=y0;// input the initial values y0 to the y

		for (int i=0; i<iter; i++)
		{   
			for (int NumNeuronth=1;NumNeuronth<=NumNeuron;NumNeuronth++)
				{
					int y6=7*NumNeuronth-1;
					y[i][y6]=fmod(y[i][y6],1);
				}
			// k1 = f(t(n), y(n))
			(*dvdt)(t[i],y[i],amp,m11,neuron_type_list);
			//(*dvdt)(double t,vector<double> y,vector<double> amp,vector<double> &dv_dt);
			(*dmdt)(t[i],y[i],m12);
			//void (*dmdt)mi_dt(double t,vector<double> y, vector<double>  &dmi_dt)
	        (*dhdt)(t[i],y[i],m13);
			//(*dhdt)(double t,vector<double> y,vector<double>  &dhi_dt)
			(*dndt)(t[i],y[i],m14);
			//(*dndt)(double t,vector<double> y, vector<double>  &dni_dt)
			(*Gidt)(t[i],y[i],m15,neuron_type_list);
			//(*Gidt)(double t,vector<double> y,vector<double>  &Gi_dt)
	        (*G1idt)(t[i],y[i],Couple,m16,neuron_type_list);
			//(*G1idt)(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt)
	        (*dqdt)(t[i],Omega, m17);
			//(*qi_dt)(double t,vector<double> Omega,vector<double>  &dqi_dt)
			//assign the m11,m12,m13,m14 to k1
			
				for(int j=0;j<NumNeuron;j++)
				{
					k1[7*j]=m11[j];
			        k1[7*j+1]=m12[j];
			        k1[7*j+2]=m13[j];
			        k1[7*j+3]=m14[j];
			        k1[7*j+4]=m15[j];
					k1[7*j+5]=m16[j];
					k1[7*j+6]=m17[j];
				}
			

			// k2 = f(t(n)+h/2, y(n)+k1*h/2)
		
				for (int j=0;j<Dimension;j++)
				{

					temp[j]=0.5*h*k1[j]+y[i][j];
				}
				for (int NumNeuronth=1;NumNeuronth<=NumNeuron;NumNeuronth++)
					{
						int y6=7*NumNeuronth-1;
						temp[y6]=fmod(temp[y6],1);
					}
            (*dvdt)((t[i]+0.5*h),temp,amp,m21,neuron_type_list);
			(*dmdt)((t[i]+0.5*h),temp,m22);
	        (*dhdt)((t[i]+0.5*h),temp,m23);
			(*dndt)((t[i]+0.5*h),temp,m24);
			(*Gidt)((t[i]+0.5*h),temp,m25,neuron_type_list);
			(*G1idt)((t[i]+0.5*h),temp,Couple,m26,neuron_type_list);
	        (*dqdt)((t[i]+0.5*h),Omega, m27);


			for(int j=0;j<NumNeuron;j++)
				{
					k2[7*j]=m21[j];
			        k2[7*j+1]=m22[j];
			        k2[7*j+2]=m23[j];
			        k2[7*j+3]=m24[j];
			        k2[7*j+4]=m25[j];
					k2[7*j+5]=m26[j];
					k2[7*j+6]=m27[j];

				}


			// k3 = f(t(n)+h/2, y(n)+k2*h/2)

			for (int j=0;j<Dimension;j++)
				{

					temp[j]=0.5*h*k2[j]+y[i][j];
				}
			for (int NumNeuronth=1;NumNeuronth<=NumNeuron;NumNeuronth++)
					{
						int y6=7*NumNeuronth-1;
						temp[y6]=fmod(temp[y6],1);
					}
			(*dvdt)((t[i]+0.5*h),temp,amp,m31,neuron_type_list);
			//(*dvdt)(double t,vector<double> y,vector<double> amp,vector<double> &dv_dt);
			(*dmdt)((t[i]+0.5*h),temp,m32);
			//void (*dmdt)mi_dt(double t,vector<double> y, vector<double>  &dmi_dt)
	        (*dhdt)((t[i]+0.5*h),temp,m33);
			//(*dhdt)(double t,vector<double> y,vector<double>  &dhi_dt)
			(*dndt)((t[i]+0.5*h),temp,m34);
			//(*dndt)(double t,vector<double> y, vector<double>  &dni_dt)
			(*Gidt)((t[i]+0.5*h),temp,m35,neuron_type_list);
			//(*Gidt)(double t,vector<double> y,vector<double>  &Gi_dt)
	        (*G1idt)((t[i]+0.5*h),temp,Couple,m36,neuron_type_list);
			//(*G1idt)(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt)
	        (*dqdt)((t[i]+0.5*h),Omega, m37);
			//(*qi_dt)(double t,vector<double> Omega,vector<double>  &dqi_dt)




			for(int j=0;j<NumNeuron;j++)
				{
					k3[7*j]=m31[j];
			        k3[7*j+1]=m32[j];
			        k3[7*j+2]=m33[j];
			        k3[7*j+3]=m34[j];
			        k3[7*j+4]=m35[j];
					k3[7*j+5]=m36[j];
					k3[7*j+6]=m37[j];

				}
			

			// k4 = f(t(n)+h, y(n)+k3*h)


			for (int j=0;j<Dimension;j++)
				{

					temp[j]=h*k3[j]+y[i][j];
				}
			for (int NumNeuronth=1;NumNeuronth<=NumNeuron;NumNeuronth++)
					{
						int y6=7*NumNeuronth-1;
						temp[y6]=fmod(temp[y6],1);
					}
		    (*dvdt)((t[i]+h),temp,amp,m41,neuron_type_list);
			(*dmdt)((t[i]+h),temp,m42);
	        (*dhdt)((t[i]+h),temp,m43);
			(*dndt)((t[i]+h),temp,m44);
			(*Gidt)(t[i]+h,temp,m45,neuron_type_list);
			(*G1idt)(t[i]+h,temp,Couple,m46,neuron_type_list);
	        (*dqdt)((t[i]+h),Omega, m47);
			
			for(int j=0;j<NumNeuron;j++)
				{
					k4[7*j]=m41[j];
			        k4[7*j+1]=m42[j];
			        k4[7*j+2]=m43[j];
			        k4[7*j+3]=m44[j];
			        k4[7*j+4]=m45[j];
					k4[7*j+5]=m46[j];
					k4[7*j+6]=m47[j];

				}
			
			//The solution value

			//y[i+1].push_back(y[i][0]+(h/6)*(k1[0]+2*k2[0]+2*k3[0]+k4[0]));
			//y[i+1].push_back(y[i][1]+(h/6)*(k1[1]+2*k2[1]+2*k3[1]+k4[1]));
			//y[i+1].push_back(y[i][2]+(h/6)*(k1[2]+2*k2[2]+2*k3[2]+k4[2]));
			//y[i+1].push_back(y[i][3]+(h/6)*(k1[3]+2*k2[3]+2*k3[3]+k4[3]));
			//y[i+1].push_back(y[i][4]+(h/6)*(k1[4]+2*k2[4]+2*k3[4]+k4[4]));
			
			for(int j=0;j<Dimension;j++)
			{
				y[i+1][j]=y[i][j]+(h/6)*(k1[j]+2*k2[j]+2*k3[j]+k4[j]);

			}
			

			//updata t
            t[i+1]=t[i]+h;
		}
}



void Runge_Kutta4M(vector<double> y0,vector<double> Omega,double t0,int iter,double h,vector<vector<double> > &y,
	vector<double>  &t,	vector<vector<double> >Couple,vector<double> amp,
	void (*dvdt)(double t,vector<double> y,vector<double> amp,vector<double>  &dvi_dt),
	void (*dmdt)(double t,vector<double> y, vector<double>  &dmi_dt),
	void (*dhdt)(double t,vector<double> y,vector<double>  &dhi_dt),
	void (*dndt)(double t,vector<double> y, vector<double>  &dni_dt),
	void (*Gidt)(double t,vector<double> y,vector<double>  &Gi_dt),
	void (*G1idt)(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt),
	void (*dqdt)(double t,vector<double> Omega,vector<double>  &dqi_dt))
{      int Dimension;
    Dimension=y0.size();
	vector<double>  temp(Dimension);
	vector<double>  k1(Dimension); 
	vector<double>  k2(Dimension); 
	vector<double>  k3(Dimension); 
	vector<double>  k4(Dimension); 
	vector<double> m11, m21, m31, m41;
	vector<double> m12, m22, m32, m42;
	vector<double> m13, m23, m33, m43;
	vector<double> m14, m24, m34, m44;
	vector<double> m15, m25, m35, m45;
	vector<double> m16, m26, m36, m46;
	vector<double> m17, m27, m37, m47;
	m11.resize(NumNeuron);m21.resize(NumNeuron); m31.resize(NumNeuron); m41.resize(NumNeuron);
	m12.resize(NumNeuron);m22.resize(NumNeuron); m32.resize(NumNeuron); m42.resize(NumNeuron);
	m13.resize(NumNeuron);m23.resize(NumNeuron); m33.resize(NumNeuron); m43.resize(NumNeuron);
	m14.resize(NumNeuron);m24.resize(NumNeuron); m34.resize(NumNeuron); m44.resize(NumNeuron);
	m15.resize(NumNeuron);m25.resize(NumNeuron); m35.resize(NumNeuron); m45.resize(NumNeuron);
	m16.resize(NumNeuron);m26.resize(NumNeuron); m36.resize(NumNeuron); m46.resize(NumNeuron);
	m17.resize(NumNeuron);m27.resize(NumNeuron); m37.resize(NumNeuron); m47.resize(NumNeuron);

	t.resize(iter+1);
	y.resize(iter+1);// 7*NumNeuron solutions

	t[0]=t0;
	for (int j=1;j<iter+1;j++)
		{
			y[j].resize(Dimension);
		}

	y[0]=y0;// input the initial values y0 to the y

		for (int i=0; i<iter; i++)
		{   
			for (int NumNeuronth=1;NumNeuronth<=NumNeuron;NumNeuronth++)
				{
					int y6=7*NumNeuronth-1;
					y[i][y6]=fmod(y[i][y6],1);
				}
			// k1 = f(t(n), y(n))
			(*dvdt)(t[i],y[i],amp,m11);
			//(*dvdt)(double t,vector<double> y,vector<double> amp,vector<double> &dv_dt);
			(*dmdt)(t[i],y[i],m12);
			//void (*dmdt)mi_dt(double t,vector<double> y, vector<double>  &dmi_dt)
	        (*dhdt)(t[i],y[i],m13);
			//(*dhdt)(double t,vector<double> y,vector<double>  &dhi_dt)
			(*dndt)(t[i],y[i],m14);
			//(*dndt)(double t,vector<double> y, vector<double>  &dni_dt)
			(*Gidt)(t[i],y[i],m15);
			//(*Gidt)(double t,vector<double> y,vector<double>  &Gi_dt)
	        (*G1idt)(t[i],y[i],Couple,m16);
			//(*G1idt)(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt)
	        (*dqdt)(t[i],Omega, m17);
			//(*qi_dt)(double t,vector<double> Omega,vector<double>  &dqi_dt)
			//assign the m11,m12,m13,m14 to k1
			
				for(int j=0;j<NumNeuron;j++)
				{
					k1[7*j]=m11[j];
			        k1[7*j+1]=m12[j];
			        k1[7*j+2]=m13[j];
			        k1[7*j+3]=m14[j];
			        k1[7*j+4]=m15[j];
					k1[7*j+5]=m16[j];
					k1[7*j+6]=m17[j];
				}
			

			// k2 = f(t(n)+h/2, y(n)+k1*h/2)
		
				for (int j=0;j<Dimension;j++)
				{

					temp[j]=0.5*h*k1[j]+y[i][j];
				}
				for (int NumNeuronth=1;NumNeuronth<=NumNeuron;NumNeuronth++)
					{
						int y6=7*NumNeuronth-1;
						temp[y6]=fmod(temp[y6],1);
					}
            (*dvdt)((t[i]+0.5*h),temp,amp,m21);
			(*dmdt)((t[i]+0.5*h),temp,m22);
	        (*dhdt)((t[i]+0.5*h),temp,m23);
			(*dndt)((t[i]+0.5*h),temp,m24);
			(*Gidt)((t[i]+0.5*h),temp,m25);
			(*G1idt)((t[i]+0.5*h),temp,Couple,m26);
	        (*dqdt)((t[i]+0.5*h),Omega, m27);


			for(int j=0;j<NumNeuron;j++)
				{
					k2[7*j]=m21[j];
			        k2[7*j+1]=m22[j];
			        k2[7*j+2]=m23[j];
			        k2[7*j+3]=m24[j];
			        k2[7*j+4]=m25[j];
					k2[7*j+5]=m26[j];
					k2[7*j+6]=m27[j];

				}


			// k3 = f(t(n)+h/2, y(n)+k2*h/2)

			for (int j=0;j<Dimension;j++)
				{

					temp[j]=0.5*h*k2[j]+y[i][j];
				}
			for (int NumNeuronth=1;NumNeuronth<=NumNeuron;NumNeuronth++)
					{
						int y6=7*NumNeuronth-1;
						temp[y6]=fmod(temp[y6],1);
					}
			(*dvdt)((t[i]+0.5*h),temp,amp,m31);
			//(*dvdt)(double t,vector<double> y,vector<double> amp,vector<double> &dv_dt);
			(*dmdt)((t[i]+0.5*h),temp,m32);
			//void (*dmdt)mi_dt(double t,vector<double> y, vector<double>  &dmi_dt)
	        (*dhdt)((t[i]+0.5*h),temp,m33);
			//(*dhdt)(double t,vector<double> y,vector<double>  &dhi_dt)
			(*dndt)((t[i]+0.5*h),temp,m34);
			//(*dndt)(double t,vector<double> y, vector<double>  &dni_dt)
			(*Gidt)((t[i]+0.5*h),temp,m35);
			//(*Gidt)(double t,vector<double> y,vector<double>  &Gi_dt)
	        (*G1idt)((t[i]+0.5*h),temp,Couple,m36);
			//(*G1idt)(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt)
	        (*dqdt)((t[i]+0.5*h),Omega, m37);
			//(*qi_dt)(double t,vector<double> Omega,vector<double>  &dqi_dt)




			for(int j=0;j<NumNeuron;j++)
				{
					k3[7*j]=m31[j];
			        k3[7*j+1]=m32[j];
			        k3[7*j+2]=m33[j];
			        k3[7*j+3]=m34[j];
			        k3[7*j+4]=m35[j];
					k3[7*j+5]=m36[j];
					k3[7*j+6]=m37[j];

				}
			

			// k4 = f(t(n)+h, y(n)+k3*h)


			for (int j=0;j<Dimension;j++)
				{

					temp[j]=h*k3[j]+y[i][j];
				}
			for (int NumNeuronth=1;NumNeuronth<=NumNeuron;NumNeuronth++)
					{
						int y6=7*NumNeuronth-1;
						temp[y6]=fmod(temp[y6],1);
					}
		    (*dvdt)((t[i]+h),temp,amp,m41);
			(*dmdt)((t[i]+h),temp,m42);
	        (*dhdt)((t[i]+h),temp,m43);
			(*dndt)((t[i]+h),temp,m44);
			(*Gidt)(t[i]+h,temp,m45);
			(*G1idt)(t[i]+h,temp,Couple,m46);
	        (*dqdt)((t[i]+h),Omega, m47);
			
			for(int j=0;j<NumNeuron;j++)
				{
					k4[7*j]=m41[j];
			        k4[7*j+1]=m42[j];
			        k4[7*j+2]=m43[j];
			        k4[7*j+3]=m44[j];
			        k4[7*j+4]=m45[j];
					k4[7*j+5]=m46[j];
					k4[7*j+6]=m47[j];

				}
			
			//The solution value

			//y[i+1].push_back(y[i][0]+(h/6)*(k1[0]+2*k2[0]+2*k3[0]+k4[0]));
			//y[i+1].push_back(y[i][1]+(h/6)*(k1[1]+2*k2[1]+2*k3[1]+k4[1]));
			//y[i+1].push_back(y[i][2]+(h/6)*(k1[2]+2*k2[2]+2*k3[2]+k4[2]));
			//y[i+1].push_back(y[i][3]+(h/6)*(k1[3]+2*k2[3]+2*k3[3]+k4[3]));
			//y[i+1].push_back(y[i][4]+(h/6)*(k1[4]+2*k2[4]+2*k3[4]+k4[4]));
			
			for(int j=0;j<Dimension;j++)
			{
				y[i+1][j]=y[i][j]+(h/6)*(k1[j]+2*k2[j]+2*k3[j]+k4[j]);

			}
			

			//updata t
            t[i+1]=t[i]+h;
		}
}


void ModfyRunge_Kutta4M(vector<double> y0,vector<double> Omega,double t0,long double iter,double h,vector<double> &y,
	double &t,	vector<vector<double> >Couple,vector<double> amp,
	void (*dvdt)(double t,vector<double> y,vector<double> amp,vector<double>  &dvi_dt),
	void (*dmdt)(double t,vector<double> y, vector<double>  &dmi_dt),
	void (*dhdt)(double t,vector<double> y,vector<double>  &dhi_dt),
	void (*dndt)(double t,vector<double> y, vector<double>  &dni_dt),
	void (*Gidt)(double t,vector<double> y,vector<double>  &Gi_dt),
	void (*G1idt)(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt),
	void (*dqdt)(double t,vector<double> Omega,vector<double>  &dqi_dt))
{      int Dimension;
	Dimension=y0.size();
	vector<double>  temp(Dimension);
	vector<double>  k1(Dimension); 
	vector<double>  k2(Dimension); 
	vector<double>  k3(Dimension); 
	vector<double>  k4(Dimension); 
	vector<double> m11, m21, m31, m41;
	vector<double> m12, m22, m32, m42;
	vector<double> m13, m23, m33, m43;
	vector<double> m14, m24, m34, m44;
	vector<double> m15, m25, m35, m45;
	vector<double> m16, m26, m36, m46;
	vector<double> m17, m27, m37, m47;
	m11.resize(NumNeuron);m21.resize(NumNeuron); m31.resize(NumNeuron); m41.resize(NumNeuron);
	m12.resize(NumNeuron);m22.resize(NumNeuron); m32.resize(NumNeuron); m42.resize(NumNeuron);
	m13.resize(NumNeuron);m23.resize(NumNeuron); m33.resize(NumNeuron); m43.resize(NumNeuron);
	m14.resize(NumNeuron);m24.resize(NumNeuron); m34.resize(NumNeuron); m44.resize(NumNeuron);
	m15.resize(NumNeuron);m25.resize(NumNeuron); m35.resize(NumNeuron); m45.resize(NumNeuron);
	m16.resize(NumNeuron);m26.resize(NumNeuron); m36.resize(NumNeuron); m46.resize(NumNeuron);
	m17.resize(NumNeuron);m27.resize(NumNeuron); m37.resize(NumNeuron); m47.resize(NumNeuron);

	FREE_2(y);
	y.resize(Dimension);// 7*NumNeuron solutions
	t=t0;
	y=y0;// input the initial values y0 to the y

		for (int i=0; i<iter; i++)
		{   
			for (int NumNeuronth=1;NumNeuronth<=NumNeuron;NumNeuronth++)
			{
					int y6=7*NumNeuronth-1;
					y[y6]=fmod(y[y6],1);
			}
			// k1 = f(t(n), y(n))
			(*dvdt)(t,y,amp,m11);
			//(*dvdt)(double t,vector<double> y,vector<double> amp,vector<double> &dv_dt);
			(*dmdt)(t,y,m12);
			//void (*dmdt)mi_dt(double t,vector<double> y, vector<double>  &dmi_dt)
	        (*dhdt)(t,y,m13);
			//(*dhdt)(double t,vector<double> y,vector<double>  &dhi_dt)
			(*dndt)(t,y,m14);
			//(*dndt)(double t,vector<double> y, vector<double>  &dni_dt)
			(*Gidt)(t,y,m15);
			//(*Gidt)(double t,vector<double> y,vector<double>  &Gi_dt)
	        (*G1idt)(t,y,Couple,m16);
			//(*G1idt)(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt)
	        (*dqdt)(t,Omega, m17);
			//(*qi_dt)(double t,vector<double> Omega,vector<double>  &dqi_dt)
			//assign the m11,m12,m13,m14 to k1
			
				for(int j=0;j<NumNeuron;j++)
				{
					k1[7*j]=m11[j];
			        k1[7*j+1]=m12[j];
			        k1[7*j+2]=m13[j];
			        k1[7*j+3]=m14[j];
			        k1[7*j+4]=m15[j];
					k1[7*j+5]=m16[j];
					k1[7*j+6]=m17[j];

				}
			

			// k2 = f(t(n)+h/2, y(n)+k1*h/2)
		
				for (int j=0;j<Dimension;j++)
				{

					temp[j]=0.5*h*k1[j]+y[j];
				}
				for (int NumNeuronth=1;NumNeuronth<=NumNeuron;NumNeuronth++)
				{
					int y6=7*NumNeuronth-1;
					temp[y6]=fmod(temp[y6],1);
				}
            (*dvdt)((t+0.5*h),temp,amp,m21);
			(*dmdt)((t+0.5*h),temp,m22);
	        (*dhdt)((t+0.5*h),temp,m23);
			(*dndt)((t+0.5*h),temp,m24);
			(*Gidt)((t+0.5*h),temp,m25);
			(*G1idt)((t+0.5*h),temp,Couple,m26);
	        (*dqdt)((t+0.5*h),Omega, m27);


			for(int j=0;j<NumNeuron;j++)
				{
					k2[7*j]=m21[j];
			        k2[7*j+1]=m22[j];
			        k2[7*j+2]=m23[j];
			        k2[7*j+3]=m24[j];
			        k2[7*j+4]=m25[j];
					k2[7*j+5]=m26[j];
					k2[7*j+6]=m27[j];

				}


			// k3 = f(t(n)+h/2, y(n)+k2*h/2)

			for (int j=0;j<Dimension;j++)
				{

					temp[j]=0.5*h*k2[j]+y[j];
				}
				for (int NumNeuronth=1;NumNeuronth<=NumNeuron;NumNeuronth++)
				{
					int y6=7*NumNeuronth-1;
					temp[y6]=fmod(temp[y6],1);
				}
			(*dvdt)((t+0.5*h),temp,amp,m31);
			//(*dvdt)(double t,vector<double> y,vector<double> amp,vector<double> &dv_dt);
			(*dmdt)((t+0.5*h),temp,m32);
			//void (*dmdt)mi_dt(double t,vector<double> y, vector<double>  &dmi_dt)
	        (*dhdt)((t+0.5*h),temp,m33);
			//(*dhdt)(double t,vector<double> y,vector<double>  &dhi_dt)
			(*dndt)((t+0.5*h),temp,m34);
			//(*dndt)(double t,vector<double> y, vector<double>  &dni_dt)
			(*Gidt)((t+0.5*h),temp,m35);
			//(*Gidt)(double t,vector<double> y,vector<double>  &Gi_dt)
	        (*G1idt)((t+0.5*h),temp,Couple,m36);
			//(*G1idt)(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt)
	        (*dqdt)((t+0.5*h),Omega, m37);
			//(*qi_dt)(double t,vector<double> Omega,vector<double>  &dqi_dt)




			for(int j=0;j<NumNeuron;j++)
				{
					k3[7*j]=m31[j];
			        k3[7*j+1]=m32[j];
			        k3[7*j+2]=m33[j];
			        k3[7*j+3]=m34[j];
			        k3[7*j+4]=m35[j];
					k3[7*j+5]=m36[j];
					k3[7*j+6]=m37[j];

				}
			

			// k4 = f(t(n)+h, y(n)+k3*h)


			for (int j=0;j<Dimension;j++)
				{

					temp[j]=h*k3[j]+y[j];
				}
			for (int NumNeuronth=1;NumNeuronth<=NumNeuron;NumNeuronth++)
				{
					int y6=7*NumNeuronth-1;
					temp[y6]=fmod(temp[y6],1);
				}
		    (*dvdt)((t+h),temp,amp,m41);
			(*dmdt)((t+h),temp,m42);
	        (*dhdt)((t+h),temp,m43);
			(*dndt)((t+h),temp,m44);
			(*Gidt)((t+h),temp,m45);
			(*G1idt)((t+h),temp,Couple,m46);
	        (*dqdt)((t+h),Omega, m47);
			
			for(int j=0;j<NumNeuron;j++)
				{
					k4[7*j]=m41[j];
			        k4[7*j+1]=m42[j];
			        k4[7*j+2]=m43[j];
			        k4[7*j+3]=m44[j];
			        k4[7*j+4]=m45[j];
					k4[7*j+5]=m46[j];
					k4[7*j+6]=m47[j];

				}
			
			//The solution value

			//y[i+1].push_back(y[i][0]+(h/6)*(k1[0]+2*k2[0]+2*k3[0]+k4[0]));
			//y[i+1].push_back(y[i][1]+(h/6)*(k1[1]+2*k2[1]+2*k3[1]+k4[1]));
			//y[i+1].push_back(y[i][2]+(h/6)*(k1[2]+2*k2[2]+2*k3[2]+k4[2]));
			//y[i+1].push_back(y[i][3]+(h/6)*(k1[3]+2*k2[3]+2*k3[3]+k4[3]));
			//y[i+1].push_back(y[i][4]+(h/6)*(k1[4]+2*k2[4]+2*k3[4]+k4[4]));
			
			for(int j=0;j<Dimension;j++)
			{
				y[j]=y[j]+(h/6)*(k1[j]+2*k2[j]+2*k3[j]+k4[j]);

			}
			

			//updata t
            t=t+h;
		}
}