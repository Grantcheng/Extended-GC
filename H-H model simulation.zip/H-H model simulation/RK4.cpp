#include<iostream>
#include<math.h>
#include<cmath>
#include<iomanip>
#include <stdio.h>
#include <stdlib.h>
#include<vector>
#include"SHHfunction.h"

using namespace std;

void Runge_Kutta4(vector<double> y0,vector<double> Omega,double t0,int iter,double h,vector<vector<double> >  &y,
	vector<double>  &t,	void (*dvdt)(double t,vector<double> y,double &dv_dt),
	void (*dmdt)(double t,double y_0, double y_1, double &dm_dt),
	void (*dhdt)(double t,double y_0, double y_2, double &dh_dt),
	void (*dndt)(double t,double y_0, double y_3,double &dn_dt),
	void (*dqdt)(double t,double Omega, double &dq_dt))
{      
	vector<double>  temp(5);
	vector<double>  k1(5); 
	vector<double>  k2(5); 
	vector<double>  k3(5); 
	vector<double>  k4(5); 
	double m11, m21, m31, m41;
	double m12, m22, m32, m42;
	double m13, m23, m33, m43;
	double m14, m24, m34, m44;
	double m15, m25, m35, m45;
	
	t.resize(iter+1);
	y.resize(iter+1);
	t[0]=t0;
	for (int j=1;j<iter+1;j++)
		{
			y[j].resize(5);// five solutions:v,m,n,h,q
		}

	y[0]=y0;// input the initial values y0 to the y

		for (int i=0; i<iter; i++)
		{   
			if (y[i][4]>1)
			y[i][4]=fmod(y[i][4],1);
			// k1 = f(t(n), y(n))
			//(*voltage_dt)(double t,vector<double> y,double &dv_dt)
			(*dvdt)(t[i],y[i],m11);
			//(*dmdt)(double t,double y_0, double y_1, double &dm_dt)
			(*dmdt)(t[i],y[i][0],y[i][1],m12);
			//void (*dhdt)(double t,double y_0, double y_2, double &dh_dt)
	        (*dhdt)(t[i],y[i][0],y[i][2],m13);
			//(*dndt)(double t,double y_0, double y_3,double &dn_dt)
			(*dndt)(t[i],y[i][0],y[i][3],m14);
			//(*dqdt)(double t,double Omega, double &dq_dt)
	        (*dqdt)(t[i],Omega[0], m15);
			//assign the m11,m12,m13,m14 to k1
			k1[0]=m11;
			k1[1]=m12;
			k1[2]=m13;
			k1[3]=m14;
			k1[4]=m15;

			// k2 = f(t(n)+h/2, y(n)+k1*h/2)
		

			temp[0]=0.5*h*k1[0]+y[i][0];
			temp[1]=0.5*h*k1[1]+y[i][1];
			temp[2]=0.5*h*k1[2]+y[i][2];
			temp[3]=0.5*h*k1[3]+y[i][3];
			temp[4]=0.5*h*k1[4]+y[i][4];

            (*dvdt)((t[i]+0.5*h),temp,m21);
			(*dmdt)((t[i]+0.5*h),temp[0],temp[1],m22);
	        (*dhdt)((t[i]+0.5*h),temp[0],temp[2],m23);
			(*dndt)((t[i]+0.5*h),temp[0],temp[3],m24);
	        (*dqdt)((t[i]+0.5*h),Omega[0], m25);
			k2[0]=m21;
			k2[1]=m22;
			k2[2]=m23;
			k2[3]=m24;
			k2[4]=m25;
			// k3 = f(t(n)+h/2, y(n)+k2*h/2)
			temp[0]=0.5*h*k2[0]+y[i][0];
			temp[1]=0.5*h*k2[1]+y[i][1];
			temp[2]=0.5*h*k2[2]+y[i][2];
			temp[3]=0.5*h*k2[3]+y[i][3];
			temp[4]=0.5*h*k2[4]+y[i][4];

			(*dvdt)((t[i]+0.5*h),temp,m31);
			(*dmdt)((t[i]+0.5*h),temp[0],temp[1],m32);
	        (*dhdt)((t[i]+0.5*h),temp[0],temp[2],m33);
			(*dndt)((t[i]+0.5*h),temp[0],temp[3],m34);
	        (*dqdt)((t[i]+0.5*h),Omega[0], m35);
			k3[0]=m31;
			k3[1]=m32;
			k3[2]=m33;
			k3[3]=m34;
			k3[4]=m35;

			// k4 = f(t(n)+h, y(n)+k3*h)

			temp[0]=h*k3[0]+y[i][0];
			temp[1]=h*k3[1]+y[i][1];
			temp[2]=h*k3[2]+y[i][2];
			temp[3]=h*k3[3]+y[i][3];
			temp[4]=h*k3[4]+y[i][4];

			(*dvdt)((t[i]+h),temp,m41);
			(*dmdt)((t[i]+h),temp[0],temp[1],m42);
	        (*dhdt)((t[i]+h),temp[0],temp[2],m43);
			(*dndt)((t[i]+h),temp[0],temp[3],m44);
	        (*dqdt)((t[i]+h),Omega[0], m45);
			k4[0]=m41;
			k4[1]=m42;
			k4[2]=m43;
			k4[3]=m44;
			k4[4]=m45;
			//The solution value

			//y[i+1].push_back(y[i][0]+(h/6)*(k1[0]+2*k2[0]+2*k3[0]+k4[0]));
			//y[i+1].push_back(y[i][1]+(h/6)*(k1[1]+2*k2[1]+2*k3[1]+k4[1]));
			//y[i+1].push_back(y[i][2]+(h/6)*(k1[2]+2*k2[2]+2*k3[2]+k4[2]));
			//y[i+1].push_back(y[i][3]+(h/6)*(k1[3]+2*k2[3]+2*k3[3]+k4[3]));
			//y[i+1].push_back(y[i][4]+(h/6)*(k1[4]+2*k2[4]+2*k3[4]+k4[4]));
			
			y[i+1][0]=y[i][0]+(h/6)*(k1[0]+2*k2[0]+2*k3[0]+k4[0]);
			y[i+1][1]=y[i][1]+(h/6)*(k1[1]+2*k2[1]+2*k3[1]+k4[1]);
			y[i+1][2]=y[i][2]+(h/6)*(k1[2]+2*k2[2]+2*k3[2]+k4[2]);
			y[i+1][3]=y[i][3]+(h/6)*(k1[3]+2*k2[3]+2*k3[3]+k4[3]);
			y[i+1][4]=y[i][4]+(h/6)*(k1[4]+2*k2[4]+2*k3[4]+k4[4]);
			//updata t
            t[i+1]=t[i]+h;
		}
}

void ModfyRunge_Kutta4(vector<double> y0,vector<double> Omega,double t0,long double iter,double h,vector<double> &y,
	double &t,	void (*dvdt)(double t,vector<double> y,double &dv_dt),void (*dmdt)(double t,double y_0, double y_1, double &dm_dt),
	void (*dhdt)(double t,double y_0, double y_2, double &dh_dt),void (*dndt)(double t,double y_0, double y_3,double &dn_dt),
	void (*dqdt)(double t,double Omega, double &dq_dt))
{      
	vector<double>  temp(5);
	vector<double>  k1(5); 
	vector<double>  k2(5); 
	vector<double>  k3(5); 
	vector<double>  k4(5); 
	double m11, m21, m31, m41;
	double m12, m22, m32, m42;
	double m13, m23, m33, m43;
	double m14, m24, m34, m44;
	double m15, m25, m35, m45;
	

	t=t0;
	y.resize(5);// five solutions:v,m,n,h,q
	y=y0;// input the initial values y0 to the y
		for (int i=0; i<iter; i++)
		{   // k1 = f(t(n), y(n))
			if (y[4]>1)
			y[4]=fmod(y[4],1);
			//(*voltage_dt)(double t,vector<double> y,double &dv_dt)
			(*dvdt)(t,y,m11);
			//(*dmdt)(double t,double y_0, double y_1, double &dm_dt)
			(*dmdt)(t,y[0],y[1],m12);
			//void (*dhdt)(double t,double y_0, double y_2, double &dh_dt)
	        (*dhdt)(t,y[0],y[2],m13);
			//(*dndt)(double t,double y_0, double y_3,double &dn_dt)
			(*dndt)(t,y[0],y[3],m14);
			//(*dqdt)(double t,double Omega, double &dq_dt)
	        (*dqdt)(t,Omega[0], m15);
			//assign the m11,m12,m13,m14 to k1

			k1[0]=m11;
			k1[1]=m12;
			k1[2]=m13;
			k1[3]=m14;
			k1[4]=m15;

			// k2 = f(t(n)+h/2, y(n)+k1*h/2)
		

			for(int a=0;a<5;a++)
			{
				temp[a]=0.5*h*k1[a]+y[a];
			}
			
            (*dvdt)((t+0.5*h),temp,m21);
			(*dmdt)((t+0.5*h),temp[0],temp[1],m22);
	        (*dhdt)((t+0.5*h),temp[0],temp[2],m23);
			(*dndt)((t+0.5*h),temp[0],temp[3],m24);
	        (*dqdt)((t+0.5*h),Omega[0], m25);

			k2[0]=m21;
			k2[1]=m22;
			k2[2]=m23;
			k2[3]=m24;
			k2[4]=m25;
			// k3 = f(t(n)+h/2, y(n)+k2*h/2)
			for(int a=0;a<5;a++)
			{
				temp[a]=0.5*h*k2[a]+y[a];
			}

			(*dvdt)((t+0.5*h),temp,m31);
			(*dmdt)((t+0.5*h),temp[0],temp[1],m32);
	        (*dhdt)((t+0.5*h),temp[0],temp[2],m33);
			(*dndt)((t+0.5*h),temp[0],temp[3],m34);
	        (*dqdt)((t+0.5*h),Omega[0], m35);

			k3[0]=m31;
			k3[1]=m32;
			k3[2]=m33;
			k3[3]=m34;
			k3[4]=m35;

			// k4 = f(t(n)+h, y(n)+k3*h)
			for(int a=0;a<5;a++)
			{
				temp[a]=h*k3[a]+y[a];
			}

			(*dvdt)((t+h),temp,m41);
			(*dmdt)((t+h),temp[0],temp[1],m42);
	        (*dhdt)((t+h),temp[0],temp[2],m43);
			(*dndt)((t+h),temp[0],temp[3],m44);
	        (*dqdt)((t+h),Omega[0], m45);

			k4[0]=m41;
			k4[1]=m42;
			k4[2]=m43;
			k4[3]=m44;
			k4[4]=m45;
			//The solution value

			//y[i+1].push_back(y[i][0]+(h/6)*(k1[0]+2*k2[0]+2*k3[0]+k4[0]));
			//y[i+1].push_back(y[i][1]+(h/6)*(k1[1]+2*k2[1]+2*k3[1]+k4[1]));
			//y[i+1].push_back(y[i][2]+(h/6)*(k1[2]+2*k2[2]+2*k3[2]+k4[2]));
			//y[i+1].push_back(y[i][3]+(h/6)*(k1[3]+2*k2[3]+2*k3[3]+k4[3]));
			//y[i+1].push_back(y[i][4]+(h/6)*(k1[4]+2*k2[4]+2*k3[4]+k4[4]));
			
			for(int i=0;i<5;i++)
			{
				y[i]=y[i]+(h/6)*(k1[i]+2*k2[i]+2*k3[i]+k4[i]);
			}
			/*y[0]=y[0]+(h/6)*(k1[0]+2*k2[0]+2*k3[0]+k4[0]);
			y[1]=y[1]+(h/6)*(k1[1]+2*k2[1]+2*k3[1]+k4[1]);
			y[2]=y[2]+(h/6)*(k1[2]+2*k2[2]+2*k3[2]+k4[2]);
			y[3]=y[3]+(h/6)*(k1[3]+2*k2[3]+2*k3[3]+k4[3]);
			y[4]=y[4]+(h/6)*(k1[4]+2*k2[4]+2*k3[4]+k4[4]);*/
			//updata t
            t=t+h;
		}
}
