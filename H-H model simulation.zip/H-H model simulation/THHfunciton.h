#ifndef _THHfunciton_h_
#define _THHfunciton_h_
#include <iostream>
#include <vector>
#include <string>
using namespace std;

/*class MHH
{
public:
	MHH();*/
	void voltagei_dt(double t,vector<double> y,vector<double> amp,vector<double> &dv_dt);
    void mi_dt(double t,vector<double> y, vector<double>  &dmi_dt);
	void hi_dt(double t,vector<double> y,vector<double>  &dhi_dt);
	void ni_dt(double t,vector<double> y, vector<double>  &dni_dt);
	void Gi_dt(double t,vector<double> y,vector<double>  &Gi_dt);
	void G1i_dt(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt);
	void qi_dt(double t,vector<double> Omega,vector<double>  &dqi_dt);
	//********** Two Neurons
	void voltagei_1_dt(double t,vector<double> y,vector<double> amp,vector<double> &dv_dt);
    void mi_1_dt(double t,vector<double> y, vector<double>  &dmi_dt);
	void hi_1_dt(double t,vector<double> y,vector<double>  &dhi_dt);
	void ni_1_dt(double t,vector<double> y, vector<double>  &dni_dt);
	void Gi_1_dt(double t,vector<double> y,vector<double>  &Gi_dt);
	void G1i_1_dt(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt);
	void qi_1_dt(double t,vector<double> Omega,vector<double>  &dqi_dt);
	//********** Three Neurons 	
	void voltagei_3_dt(double t,vector<double> y,vector<double> amp,vector<double> &dv_dt);
    void mi_3_dt(double t,vector<double> y, vector<double>  &dmi_dt);
	void hi_3_dt(double t,vector<double> y,vector<double>  &dhi_dt);
	void ni_3_dt(double t,vector<double> y, vector<double>  &dni_dt);
	void Gi_3_dt(double t,vector<double> y,vector<double>  &Gi_dt);
	void G1i_3_dt(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt);
	void qi_3_dt(double t,vector<double> Omega,vector<double>  &dqi_dt);
		//********** Three Neurons 	types
	void voltagei_3Q_dt(double t,vector<double> y,vector<double> amp,vector<double> &dv_dt,vector<int> neuron_type_list);
    void mi_3Q_dt(double t,vector<double> y, vector<double>  &dmi_dt);
	void hi_3Q_dt(double t,vector<double> y,vector<double>  &dhi_dt);
	void ni_3Q_dt(double t,vector<double> y, vector<double>  &dni_dt);
	void Gi_3Q_dt(double t,vector<double> y,vector<double>  &Gi_dt,vector<int> neuron_type_list);
	void G1i_3Q_dt(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt,vector<int> neuron_type_lists);
	void qi_3Q_dt(double t,vector<double> Omega,vector<double>  &dqi_dt);
	//********** Multi Neurons 	types
	void voltagei_3mQ_dt(double t,vector<double> y,vector<double> amp,vector<double> &dv_dt,vector<int> neuron_type_list);
    void mi_3mQ_dt(double t,vector<double> y, vector<double>  &dmi_dt);
	void hi_3mQ_dt(double t,vector<double> y,vector<double>  &dhi_dt);
	void ni_3mQ_dt(double t,vector<double> y, vector<double>  &dni_dt);
	void Gi_3mQ_dt(double t,vector<double> y,vector<double>  &Gi_dt,vector<int> neuron_type_list);
	void G1i_3mQ_dt(double t,vector<double> y,vector<vector<double> >  Couple,vector<double>  &G1i_dt,vector<int> neuron_type_lists);
	void qi_3mQ_dt(double t,vector<double> Omega,vector<double>  &dqi_dt);
//}

#endif // _THHfunciton_h_